/* Graph Builder — AI 自動分析
   掃描資料的所有欄位組合，做實質的統計檢定（相關/變異數分析/卡方/線性趨勢/自我相關/偏態…），
   把「有統計依據、而且画出來好看」的組合排成圖表牆。全部在本機算，不送任何資料到網路。 */
(function (global) {
  "use strict";

  const S = global.Stats || {};

  const KINDS = {
    flow: { label: "流量結構" },
    correlation: { label: "相關" },
    groupdiff: { label: "組間差異" },
    trend: { label: "趨勢" },
    seasonal: { label: "循環/季節" },
    association: { label: "類別關聯" },
    distribution: { label: "分布形態" },
    density: { label: "點密度" },
    panel: { label: "多頁面板" },
    bubble: { label: "三變數" },
    composition: { label: "組成佔比" },
    map: { label: "地理分布" }
  };

  const QUOTA = {
    flow: 1, map: 1, correlation: 2, groupdiff: 2, trend: 2, seasonal: 1,
    association: 2, distribution: 2, density: 1, panel: 1, bubble: 1, composition: 1
  };

  const MAX_CARDS = 8;
  const MAX_SCAN_ROWS = 20000;
  const MAX_MEASURES = 14;
  const MAX_LOESS_PAIRS = 20;

  // ==================================================================
  // 1) 分配函數與檢定（不依賴任何外部套件）
  // ==================================================================
  function logGamma(x) {
    const g = [76.18009172947146, -86.50532032941677, 24.01409824083091,
      -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    let y = x, tmp = x + 5.5;
    tmp -= (x + 0.5) * Math.log(tmp);
    let ser = 1.000000000190015;
    for (let j = 0; j < 6; j++) ser += g[j] / ++y;
    return -tmp + Math.log(2.5066282746310005 * ser / x);
  }
  function gser(a, x) {                 // 正規化下不完全伽瑪 P(a,x)（級數）
    const ITMAX = 300, EPS = 3e-9;
    let ap = a, sum = 1 / a, del = sum;
    for (let n = 0; n < ITMAX; n++) {
      ap++; del *= x / ap; sum += del;
      if (Math.abs(del) < Math.abs(sum) * EPS) break;
    }
    return sum * Math.exp(-x + a * Math.log(x) - logGamma(a));
  }
  function gcf(a, x) {                  // 正規化上不完全伽瑪 Q(a,x)（連分數）
    const ITMAX = 300, EPS = 3e-9, FPMIN = 1e-300;
    let b = x + 1 - a, c = 1 / FPMIN, d = 1 / b, h = d;
    for (let i = 1; i <= ITMAX; i++) {
      const an = -i * (i - a);
      b += 2; d = an * d + b; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = b + an / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; const del = d * c; h *= del;
      if (Math.abs(del - 1) < EPS) break;
    }
    return Math.exp(-x + a * Math.log(x) - logGamma(a)) * h;
  }
  function chi2sf(x, df) {              // χ² 右尾機率
    if (!(x > 0) || !(df > 0)) return 1;
    return gcf(df / 2, x / 2);
  }
  function betacf(a, b, x) {
    const MAXIT = 300, EPS = 3e-9, FPMIN = 1e-300;
    const qab = a + b, qap = a + 1, qam = a - 1;
    let c = 1, d = 1 - qab * x / qap;
    if (Math.abs(d) < FPMIN) d = FPMIN;
    d = 1 / d; let h = d;
    for (let m = 1; m <= MAXIT; m++) {
      const m2 = 2 * m;
      let aa = m * (b - m) * x / ((qam + m2) * (a + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; h *= d * c;
      aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
      d = 1 + aa * d; if (Math.abs(d) < FPMIN) d = FPMIN;
      c = 1 + aa / c; if (Math.abs(c) < FPMIN) c = FPMIN;
      d = 1 / d; const del = d * c; h *= del;
      if (Math.abs(del - 1) < EPS) break;
    }
    return h;
  }
  function betai(a, b, x) {             // 正規化不完全貝他 I_x(a,b)
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const bt = Math.exp(logGamma(a + b) - logGamma(a) - logGamma(b) + a * Math.log(x) + b * Math.log(1 - x));
    return x < (a + 1) / (a + b + 2) ? bt * betacf(a, b, x) / a : 1 - bt * betacf(b, a, 1 - x) / b;
  }
  function tTwoSided(t, df) {           // t 分配雙尾 p
    if (!isFinite(t) || !(df > 0)) return 1;
    return betai(df / 2, 0.5, df / (df + t * t));
  }
  function fSf(F, d1, d2) {             // F 分配右尾 p
    if (!(F > 0) || !(d1 > 0) || !(d2 > 0)) return 1;
    return betai(d2 / 2, d1 / 2, d2 / (d2 + d1 * F));
  }

  // ==================================================================
  // 2) 小工具
  // ==================================================================
  function isNum(v) { return typeof v === "number" && isFinite(v); }
  function num(v) { if (v instanceof Date) return +v; return typeof v === "number" && isFinite(v) ? v : null; }
  function catOf(v) { return v == null || v === "" ? "(缺失)" : (v instanceof Date ? String(+v) : String(v)); }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function scale01(v, lo, hi) { return clamp((v - lo) / (hi - lo || 1), 0, 1); }

  function fnum(v) {
    if (v == null || !isFinite(+v)) return "—";
    const n = +v, a = Math.abs(n);
    if (a >= 1e9) return (n / 1e9).toFixed(2) + "B";
    if (a >= 1e6) return (n / 1e6).toFixed(2) + "M";
    if (a >= 1e4) return Math.round(n).toLocaleString("en-US");
    if (a >= 1000) return String(Math.round(n));
    if (a >= 100) return n.toFixed(1);
    if (a >= 1) return String(Math.round(n * 100) / 100);
    if (a >= 0.001) return String(Math.round(n * 1000) / 1000);
    return n.toExponential(1);
  }
  const fpct = (v, d) => (v * 100).toFixed(d == null ? 1 : d) + "%";
  const fst = (v) => (v == null || !isFinite(v) ? "—" : (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(2)));
  function fmtP(p) {
    if (p == null || !isFinite(p)) return "p —";
    if (p < 0.0005) return "p < 0.001";
    if (p < 0.005) return "p < 0.01";
    if (p < 0.05) return "p = " + p.toFixed(3);
    return "p = " + p.toFixed(2);
  }
  function dateText(ms) {
    const d = new Date(ms);
    const p = (x) => String(x).padStart(2, "0");
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
  }

  // ==================================================================
  // 3) 欄位剖析
  // ==================================================================
  function profileColumn(col, idxs, weightOf) {
    const p = { key: col.key, col, type: col.type, role: col.role, isTime: !!col.hasDate && col.type === "continuous" };
    if (col.type === "continuous") {
      const v = [], w = [], idx = [];
      let missing = 0;
      for (let k = 0; k < idxs.length; k++) {
        const i = idxs[k], x = num(col.values[i]);
        if (x == null) { missing++; continue; }
        v.push(x); idx.push(i); w.push(weightOf(i));
      }
      p.missing = missing; p.n = v.length; p.values = v; p.ws = w; p.idx = idx;
      p.distinct = new Set(v).size;
      const W = w.reduce((a, b) => a + b, 0);
      p.weight = W;
      if (p.n >= 2 && p.distinct > 1) {
        p.mean = S.wmean(v, w);
        const vr = S.wvariance(v, w);
        p.sd = vr.sd;
        p.min = v.reduce((a, b) => (b < a ? b : a), Infinity);
        p.max = v.reduce((a, b) => (b > a ? b : a), -Infinity);
        p.q1 = S.wquantile(v, w, 0.25);
        p.median = S.wquantile(v, w, 0.5);
        p.q3 = S.wquantile(v, w, 0.75);
        p.iqr = p.q3 - p.q1;
        const mo = moments(v, w, p.mean);
        p.skew = mo.skew; p.kurt = mo.kurt;
        const ne = p.n;
        p.bc = (mo.skew * mo.skew + 1) / (mo.kurt + 3 * Math.pow(ne - 1, 2) / ((ne - 2) * (ne - 3) || 1));
        const fLo = p.q1 - 1.5 * p.iqr, fHi = p.q3 + 1.5 * p.iqr;
        p.fenceLo = fLo; p.fenceHi = fHi;
        p.outliers = v.filter((x) => x < fLo || x > fHi);
        p.outlierShare = p.outliers.length / p.n;
        p.cv = p.mean ? Math.abs(p.sd / p.mean) : null;
        p.lookup = new Map();
        for (let k = 0; k < idx.length; k++) p.lookup.set(idx[k], k);
      }
    } else {
      const map = new Map();
      let n = 0, missing = 0;
      for (let k = 0; k < idxs.length; k++) {
        const i = idxs[k], key = catOf(col.values[i]);
        if (key === "(缺失)") missing++;
        const cur = map.get(key) || { k: key, n: 0, w: 0 };
        cur.n++; cur.w += weightOf(i);
        map.set(key, cur); n++;
      }
      p.missing = missing; p.n = n; p.weight = Array.from(map.values()).reduce((a, b) => a + b.w, 0);
      let cats = Array.from(map.values()).sort((a, b) => (b.w - a.w) || a.k.localeCompare(b.k, "zh"));
      const tot = cats.reduce((a, c) => a + c.w, 0) || 1;
      cats.forEach((c) => { c.share = c.w / tot; });
      p.cats = cats; p.levels = cats.length;
      p.topShare = cats.length ? cats[0].share : 0;
      p.top2 = cats.length > 1 ? cats[0].share + cats[1].share : p.topShare;
      p.hhi = cats.reduce((a, c) => a + c.share * c.share, 0);
      // 平衡度：0＝全在一類、1＝平均分給各類
      p.balance = cats.length > 1 ? (1 - p.hhi) / (1 - 1 / cats.length) : 0;
      p.smallLevels = cats.filter((c) => c.n < 3).map((c) => c.k);
    }
    return p;
  }

  function moments(v, w, mean) {
    let W = 0, s2 = 0, s3 = 0, s4 = 0;
    for (let i = 0; i < v.length; i++) {
      const d = v[i] - (mean == null ? 0 : mean), ww = w[i];
      const d2 = d * d;
      W += ww; s2 += ww * d2; s3 += ww * d2 * d; s4 += ww * d2 * d2;
    }
    const vp = W > 0 ? s2 / W : 0;
    return {
      skew: vp > 0 ? (s3 / W) / Math.pow(vp, 1.5) : 0,
      kurt: vp > 0 ? (s4 / W) / (vp * vp) - 3 : 0
    };
  }

  // ==================================================================
  // 4) 統計核心
  // ==================================================================
  function pearson(xs, ys, ws) {
    let n = 0, mx = 0, my = 0;
    for (let i = 0; i < xs.length; i++) { const w = ws[i]; n += w; mx += w * xs[i]; my += w * ys[i]; }
    if (n < 3) return null;
    mx /= n; my /= n;
    let sxx = 0, syy = 0, sxy = 0;
    for (let i = 0; i < xs.length; i++) {
      const w = ws[i], dx = xs[i] - mx, dy = ys[i] - my;
      sxx += w * dx * dx; syy += w * dy * dy; sxy += w * dx * dy;
    }
    if (sxx <= 0 || syy <= 0) return null;
    const r = sxy / Math.sqrt(sxx * syy);
    const df = Math.max(1, Math.round(n) - 2);
    const t = r * Math.sqrt(df / Math.max(1e-12, 1 - r * r));
    return { r, n, p: tTwoSided(t, df), t };
  }
  function ranks(arr) {
    const idx = arr.map((v, i) => i).sort((a, b) => arr[a] - arr[b]);
    const out = new Array(arr.length);
    let i = 0;
    while (i < idx.length) {
      let j = i;
      while (j + 1 < idx.length && arr[idx[j + 1]] === arr[idx[i]]) j++;
      const rk = (i + j) / 2 + 1;
      for (let k = i; k <= j; k++) out[idx[k]] = rk;
      i = j + 1;
    }
    return out;
  }
  function spearman(xs, ys, ws) {
    if (xs.length < 6) return null;
    return pearson(ranks(xs), ranks(ys), ws);
  }

  // 依分組 key 做加權單因子變異數分析
  function groupAnova(vals, weights, keys) {
    const g = new Map();
    for (let i = 0; i < vals.length; i++) {
      const k = keys[i], w = weights[i], y = vals[i];
      const e = g.get(k) || { k, sw: 0, sy: 0, syy: 0, n: 0 };
      e.sw += w; e.sy += w * y; e.syy += w * y * y; e.n++;
      g.set(k, e);
    }
    const groups = Array.from(g.values()).filter((e) => e.n >= 3 && e.sw > 0);
    if (groups.length < 2) return null;
    let W = 0, SY = 0;
    groups.forEach((e) => { e.mean = e.sy / e.sw; W += e.sw; SY += e.sy; });
    const gm = SY / W;
    let ssb = 0, ssw = 0;
    for (let i = 0; i < vals.length; i++) {
      const e = g.get(keys[i]);
      if (!e || e.n < 3) continue;
      ssb += weights[i] * (e.mean - gm) * (e.mean - gm);
      ssw += weights[i] * (vals[i] - e.mean) * (vals[i] - e.mean);
    }
    const df1 = groups.length - 1, df2 = Math.max(1, Math.round(W) - groups.length);
    const F = (ssb / df1) / Math.max(1e-12, ssw / df2);
    return {
      groups: groups.sort((a, b) => b.mean - a.mean), gm, F, df1, df2,
      p: fSf(F, df1, df2), eta2: ssb / (ssb + ssw || 1),
      dropped: Array.from(g.values()).filter((e) => e.n < 3).length
    };
  }
  function welchT(a, b) {              // a/b = {vals, ws}
    const ma = S.wmean(a.vals, a.ws), mb = S.wmean(b.vals, b.ws);
    const va = S.wvariance(a.vals, a.ws), vb = S.wvariance(b.vals, b.ws);
    if (ma == null || mb == null || va.var == null || vb.var == null) return null;
    const na = va.n, nb = vb.n;
    const se = Math.sqrt(va.var / na + vb.var / nb);
    if (!(se > 0)) return null;
    const t = (ma - mb) / se;
    const df = Math.pow(va.var / na + vb.var / nb, 2) /
      (Math.pow(va.var / na, 2) / (na - 1) + Math.pow(vb.var / nb, 2) / (nb - 1));
    return { t, df: Math.max(1, df), p: tTwoSided(t, Math.max(1, df)), diff: ma - mb, ma, mb };
  }

  // 配對／隨機區塊設計（Randomized block）：先把區塊（例如月份）的變異扣掉再比組間
  function blockedAnova(vals, ws, keys, blocks) {
    const n = vals.length;
    if (n < 12) return null;
    const g = new Map(), b = new Map(), cell = new Map();
    let W = 0, SY = 0;
    for (let i = 0; i < n; i++) {
      const w = ws[i], y = vals[i], k = keys[i], bk = blocks[i];
      const ge = g.get(k) || { k, w: 0, s: 0, n: 0 };
      ge.w += w; ge.s += w * y; ge.n++; g.set(k, ge);
      const be = b.get(bk) || { k: bk, w: 0, s: 0, n: 0 };
      be.w += w; be.s += w * y; be.n++; b.set(bk, be);
      cell.set(k + "\u0001" + bk, (() => { const e2 = cell.get(k + "\u0001" + bk) || { n: 0, s: 0, w: 0 }; e2.n++; e2.s += y * w; e2.w += w; return e2; })());
      W += w; SY += w * y;
    }
    const k = g.size, m = b.size;
    if (k < 2 || m < 3 || cell.size !== k * m || W < 12) return null;
    const gm = SY / W;
    let ssTotal = 0;
    for (let i = 0; i < n; i++) ssTotal += ws[i] * Math.pow(vals[i] - gm, 2);
    let ssG = 0, ssB = 0;
    g.forEach((e) => { e.mean = e.s / e.w; ssG += e.w * Math.pow(e.mean - gm, 2); });
    b.forEach((e) => { e.mean = e.s / e.w; ssB += e.w * Math.pow(e.mean - gm, 2); });
    const ssE = ssTotal - ssG - ssB;
    const dfG = k - 1, dfE = (k - 1) * (m - 1);
    if (!(ssE > 1e-9) || dfE < 3) return null;
    const F = (ssG / dfG) / (ssE / dfE);
    return {
      groups: Array.from(g.values()).sort((a, b2) => b2.mean - a.mean), blocks: m, k, F, dfG, dfE,
      p: fSf(F, dfG, dfE), eta2: ssG / (ssG + ssE), gm,
      consistent: (() => {           // 各區塊內第一名是否都是同一組（順序穩定度）
        const bestByBlock = new Map();
        cell.forEach((v, key) => {
          const ix = key.lastIndexOf("\u0001");
          const gk = key.slice(0, ix), bk = key.slice(ix + 1);
          const mean = v.s / v.w;
          const cur = bestByBlock.get(bk);
          if (!cur || mean > cur.mean) bestByBlock.set(bk, { k: gk, mean });
        });
        const tally = new Map();
        bestByBlock.forEach((v) => tally.set(v.k, (tally.get(v.k) || 0) + 1));
        const top = Array.from(tally, ([kk, vv]) => ({ k: kk, n: vv })).sort((a, c) => c.n - a.n)[0];
        return top ? { top: top.k, share: top.n / m } : null;
      })()
    };
  }

  function chiSquare(pa, pb, idxs, weightOf, maxLevels) {
    if (pa.levels < 2 || pb.levels < 2) return null;
    if (pa.levels > maxLevels || pb.levels > maxLevels) return null;
    const rowKeys = pa.cats.map((c) => c.k), colKeys = pb.cats.map((c) => c.k);
    const ri = new Map(rowKeys.map((k, i) => [k, i])), ci = new Map(colKeys.map((k, i) => [k, i]));
    const t = rowKeys.map(() => colKeys.map(() => 0));
    let grand = 0, cells = 0;
    for (let k = 0; k < idxs.length; k++) {
      const i = idxs[k];
      const a = ri.get(catOf(pa.col.values[i])), b = ci.get(catOf(pb.col.values[i]));
      if (a == null || b == null) continue;
      const w = weightOf(i);
      t[a][b] += w; grand += w; cells++;
    }
    if (grand < 20 || cells < 4) return null;
    const rt = t.map((r) => r.reduce((x, y) => x + y, 0));
    const ct = colKeys.map((_, j) => t.reduce((s, r) => s + r[j], 0));
    let x2 = 0, bad = 0, nz = 0, best = null;
    for (let i = 0; i < rowKeys.length; i++) {
      for (let j = 0; j < colKeys.length; j++) {
        const e = rt[i] * ct[j] / grand;
        if (e <= 0) continue;
        nz++; if (e < 5) bad++;
        const o = t[i][j];
        x2 += (o - e) * (o - e) / e;
        const z = (o - e) / Math.sqrt(e);
        if (!best || Math.abs(z) > Math.abs(best.z)) best = { i, j, o, e, z };
      }
    }
    const df = (rowKeys.length - 1) * (colKeys.length - 1);
    if (df < 1 || nz < 4) return null;
    const nEff = Math.round(grand);
    const V = Math.sqrt(x2 / (nEff * (Math.min(rowKeys.length, colKeys.length) - 1)));
    return {
      x2, df, p: chi2sf(x2, df), V, table: t, rowKeys, colKeys, rt, ct, grand,
      smallExpected: bad / nz, best,
      rowShare: (i, j) => t[i][j] / (rt[i] || 1),
      colShare: (j, i) => t[i][j] / (ct[j] || 1)
    };
  }

  // 時間趨勢：y = a + b·t（t 以「人類易懂的單位」表示）
  function trendFit(times, vals, ws) {
    const n = times.length;
    if (n < 8) return null;
    const t0 = times.reduce((a, b) => (b < a ? b : a), Infinity);
    const span = times.reduce((a, b) => (b > a ? b : a), -Infinity) - t0;
    const days = span / 864e5;
    let unit, per;
    if (days > 500) { unit = 365.25 * 864e5; per = "年"; }
    else if (days > 70) { unit = 30.44 * 864e5; per = "月"; }
    else if (days > 14) { unit = 7 * 864e5; per = "週"; }
    else { unit = 864e5; per = "天"; }
    const xs = times.map((t) => (t - t0) / unit);
    const fit = S.linreg(xs, vals, ws);
    if (!fit || !isFinite(fit.r2)) return null;
    const t = fit.seSlope > 0 ? fit.slope / fit.seSlope : null;
    const mean = S.wmean(vals, ws);
    const sd = S.wvariance(vals, ws).sd;
    return {
      slope: fit.slope, intercept: fit.intercept, r2: fit.r2, n: fit.n,
      p: t == null ? 1 : tTwoSided(t, Math.max(1, fit.n - 2)), t,
      per, total: fit.slope * (xs[xs.length - 1] || 1),
      t0, t1: t0 + span, spanDays: days, mean, sd
    };
  }

  // 自我相關（去趨勢後的序列）
  function acfPeaks(series, maxLag) {
    const y = series.slice();
    const n = y.length;
    if (n < 10) return null;
    const idx = y.map((_, i) => i);
    const fit = S.linreg(idx, y, null);
    const det = fit ? y.map((v, i) => v - (fit.intercept + fit.slope * i)) : y.map((v) => v - S.wmean(y, null));
    const m = S.wmean(det, null) || 0;
    const d = det.map((v) => v - m);
    const denom = d.reduce((a, b) => a + b * b, 0);
    if (!(denom > 0)) return null;
    let best = null;
    for (let k = 3; k <= Math.min(maxLag, Math.floor(n / 2.5)); k++) {
      let s = 0;
      for (let i = 0; i + k < n; i++) s += d[i] * d[i + k];
      const a1 = s / denom;
      let half = 0, cnt = 0;
      const hk = Math.max(1, Math.round(k / 2));
      for (let i = 0; i + hk < n; i++) { half += d[i] * d[i + hk]; cnt++; }
      const a2 = cnt ? half / denom : 0;
      if (a1 >= 0.65 && a2 < 0.3 && (!best || a1 > best.value)) best = { lag: k, value: a1 };
    }
    return best;
  }

  // 平滑器 vs 直線：用 5 折交叉驗證比較「對沒看過的點」的預測誤差（避免 LOESS 自己擬合自己）
  function fitCompare(xs, ys, ws) {
    const n = xs.length;
    if (n < 24) return null;
    let idx = xs.map((_, i) => i);
    if (n > 300) {                       // 大資料等距抽樣再做 CV
      const keep = [];
      const step = n / 300;
      for (let k = 0; k < 300; k++) keep.push(Math.floor(k * step));
      idx = keep;
    }
    const m = idx.length;
    const order = idx.slice().sort((a, b) => xs[a] - xs[b]);
    const K = 5, fold = new Map();
    order.forEach((i, k) => fold.set(i, k % K));
    const meanAll = S.wmean(idx.map((i) => ys[i]), idx.map((i) => ws[i]));
    if (meanAll == null) return null;
    let sst = 0, sseL = 0, sseS = 0, ok = true;
    for (let f = 0; f < K; f++) {
      const tr = [], te = [];
      idx.forEach((i) => (fold.get(i) === f ? te : tr).push(i));
      if (te.length < 3 || tr.length < 12) { ok = false; break; }
      const lin = S.linreg(tr.map((i) => xs[i]), tr.map((i) => ys[i]), tr.map((i) => ws[i]));
      if (!lin) { ok = false; break; }
      const lo = S.loess(tr.map((i) => xs[i]), tr.map((i) => ys[i]), tr.map((i) => ws[i]), 0.5, 1, te.map((i) => xs[i]));
      if (!lo || lo.length !== te.length) { ok = false; break; }
      te.forEach((i, k) => {
        const y = ys[i], w = ws[i];
        sst += w * (y - meanAll) * (y - meanAll);
        sseL += w * Math.pow(y - (lin.intercept + lin.slope * xs[i]), 2);
        sseS += w * Math.pow(y - lo[k].y, 2);
      });
    }
    if (!ok || !(sst > 0)) return null;
    const lin = S.linreg(xs, ys, ws);
    return {
      lin, r2Lin: 1 - sseL / sst, r2Smooth: 1 - sseS / sst,
      gain: (sseL - sseS) / (sseL || 1), folds: K, n: m
    };
  }

  function alignPair(A, B) {
    const xs = [], ys = [], ws = [], idx = [];
    const m = A.lookup || new Map(A.idx.map((i, k) => [i, k]));
    for (let k = 0; k < B.idx.length; k++) {
      const i = B.idx[k], a = m.get(i);
      if (a === undefined) continue;
      const xv = A.values[a];
      if (!isNum(xv)) continue;
      xs.push(xv); ys.push(B.values[k]); ws.push(B.ws[k]); idx.push(i);
    }
    return { xs, ys, ws, idx };
  }

  // ==================================================================
  // 5) 卡片規格
  // ==================================================================
  const EMPTY_ZONES = ["X", "Y", "Group X", "Group Y", "Wrap", "Color", "Overlay", "Freq", "Size", "Shape"];
  function mkSpec(zones, elements, opts) {
    const o = opts || {};
    const z = {};
    EMPTY_ZONES.forEach((k) => (z[k] = []));
    Object.keys(zones || {}).forEach((k) => { z[k] = [].concat(zones[k]).filter(Boolean); });
    const els = {};
    Object.keys(elements || {}).forEach((k) => (els[k] = Object.assign({ on: true, alpha: 1 }, elements[k])));
    return {
      zones: z, elements: els,
      paintOrder: Object.keys(elements || {}),           // 由下而上
      freq: o.freq || z.Freq[0] || null,
      grouping: o.grouping || "side",
      legend: o.legend !== false,
      height: o.height || 236,
      title: o.title || shortTitle(z, els)
    };
  }
  // 卡片裡的圖用精簡標題（完整的結論已經在卡片標題上了）
  function shortTitle(z, els) {
    const keys = Object.keys(els);
    const x = (z.X || [])[0], y = (z.Y || []), c = (z.Color || [])[0];
    const suffix = c ? " · " + c : "";
    if (keys.indexOf("sankey") >= 0) return `${x || "來源"} → ${(y[0] || "目標")}${(y.length > 1) ? " 等 " + y.length + " 欄" : ""}`;
    if (keys.indexOf("map") >= 0) return "互動式地理圖" + suffix;
    if (keys.indexOf("pie") >= 0) return `${y[0] ? y[0] + " 總和：" : ""}${x || c || "類別"}`;
    if (keys.indexOf("histogram") >= 0 && keys.length === 1) return `${x || y[0]} 的分布` + suffix;
    if (y.length > 1) {
      const full = `${y.join(" & ")} 對 ${x || "變數"}` + suffix;
      return full.length > 26 ? `${y[0]} 等 ${y.length} 個 Y 對 ${x || "變數"}` + suffix : full;
    }
    if (x && y[0]) return `${y[0]} 對 ${x}` + suffix;
    return (y[0] || x || "");
  }

  function card(kind, score, o) {
    const c = {
      kind, score: clamp(score, 0, 1),
      title: o.title, detail: o.detail || "", method: o.method || "",
      tags: o.tags || [], vars: o.vars || [], spec: o.spec
    };
    Object.keys(o).forEach((k) => { if (!(k in c)) c[k] = o[k]; });   // 保留 eta2 / factor / measure 等附註
    return c;
  }

  // ==================================================================
  // 6) 偵測器
  // ==================================================================
  function isMeasure(p) {
    return p.type === "continuous" && !p.isTime && p.n >= 10 && p.distinct >= 4 &&
      p.role !== "freq" && p.role !== "lat" && p.role !== "lon";
  }
  function isFactor(p, minLevels, maxLevels, allBig) {
    if (p.type === "continuous") return false;
    if (p.levels < (minLevels || 2) || p.levels > (maxLevels || 12)) return false;
    if (p.n < 12) return false;
    if (allBig && p.smallLevels.length) return false;
    if (p.role === "label" && p.levels >= p.n * 0.8) return false;   // 名稱/ID 欄
    if (p.balance < 0.12 && p.levels > 4) return false;             // 幾乎全擠在一類
    return true;
  }

  // ---- 相關（含非線性偵測與分群著色建議）----
  function detectCorrelation(ctx) {
    const out = [];
    const ms = ctx.measures.slice(0, MAX_MEASURES);
    let loessRuns = 0;
    for (let i = 0; i < ms.length; i++) {
      for (let j = i + 1; j < ms.length; j++) {
        const A = ms[i], B = ms[j];
        if (A.n < 8 || B.n < 8) continue;
        const pa = alignPair(A, B);
        if (pa.xs.length < 8) continue;
        const pr = pearson(pa.xs, pa.ys, pa.ws);
        if (!pr || pr.p >= 0.05) continue;
        let rho = spearman(pa.xs, pa.ys, pa.ws);
        let strength = Math.abs(pr.r), useRho = false;
        if (rho && Math.abs(rho.r) > strength) { strength = Math.abs(rho.r); useRho = true; }
        if (strength < 0.3) continue;
        let cmp = null;
        if (strength >= 0.3 && pa.xs.length >= 24 && loessRuns < MAX_LOESS_PAIRS) { loessRuns++; cmp = fitCompare(pa.xs, pa.ys, pa.ws); }
        const nonlinear = !!(cmp && cmp.gain >= 0.15 && cmp.r2Smooth >= cmp.r2Lin + 0.03);

        // 找出「能把這團點分開」的類別變數
        let colorHint = null, etaRes = 0;
        const lin = S.linreg(pa.xs, pa.ys, pa.ws);
        if (lin) {
          const res = pa.ys.map((y, k) => y - (lin.intercept + lin.slope * pa.xs[k]));
          for (const f of ctx.factors) {
            if (f.levels < 2 || f.levels > 6 || f.n < 12) continue;
            const keys = pa.idx.map((row) => catOf(f.col.values[row]));
            const an = groupAnova(res, pa.ws, keys);
            if (an && an.p < 0.01 && an.eta2 > etaRes) { etaRes = an.eta2; colorHint = f; }
          }
        }

        const dir = (useRho ? rho.r : pr.r) > 0 ? "正" : "負";
        const word = strength >= 0.7 ? "高度" + dir + "相關" : strength >= 0.45 ? "中度" + dir + "相關" : "輕度" + dir + "相關";
        const rTxt = useRho ? "Spearman ρ = " + fst(rho.r) : "Pearson r = " + fst(pr.r);
        const slopeTxt = lin ? `「${A.key} 每增加 1 單位，${B.key} 約 ${lin.slope >= 0 ? "增加 " : "減少 "}${fnum(Math.abs(lin.slope))}」` : "";
        const tags = [rTxt, fmtP(useRho ? rho.p : pr.p), "n = " + pa.xs.length];
        if (cmp) tags.push((nonlinear ? "LOESS R² = " : "R² = ") + fst(nonlinear ? cmp.r2Smooth : cmp.r2Lin));

        const spec = nonlinear
          ? mkSpec(Object.assign({ X: [A.key], Y: [B.key] }, colorHint ? { Color: [colorHint.key] } : {}),
            { points: { alpha: 0.75, size: 3.4 }, smoother: { method: "loess", lambda: 0.3, band: false, showEquation: false } },
            { freq: ctx.freqKey })
          : mkSpec(Object.assign({ X: [A.key], Y: [B.key] }, colorHint ? { Color: [colorHint.key] } : {}),
            { points: { alpha: 0.72, size: 3.4 }, smoother: { method: "linear", band: true, showEquation: true } },
            { freq: ctx.freqKey });

        out.push(card("correlation", scale01(strength, 0.3, 0.9) * 0.55 + scale01(pa.xs.length, 10, 200) * 0.15 + (nonlinear ? 0.12 : 0) + (colorHint ? 0.08 : 0), {
          title: nonlinear
            ? `${A.key} 與 ${B.key} 的關係是彎的：平滑器比直線準（${useRho ? "ρ" : "r"} = ${fst(strength * (dir === "負" ? -1 : 1))}）`
            : `${A.key} 與 ${B.key} ${word}（${useRho ? "ρ" : "r"} = ${fst(strength * (dir === "負" ? -1 : 1))}）`,
          detail: `${slopeTxt}。${nonlinear ? `5 折交叉驗證：直線只能到 R² = ${fst(cmp.r2Lin)}，換成 LOESS 平滑器到 R² = ${fst(cmp.r2Smooth)}（對未看過的點的預測誤差再降 ${fpct(cmp.gain, 0)}），所以這條線真的是彎的而不只是雜訊。` : `直線擬合 R² = ${fst(cmp ? cmp.r2Lin : (pr.r * pr.r))}${cmp ? "" : "（由 r² 推得，樣本太少無法做交叉驗證）"}，用直線擬合就夠。`}${colorHint ? ` 再用 <b>${colorHint.key}</b> 著色後，殘差的組間差異 η² = ${fst(etaRes)}（不同 ${colorHint.key} 各有自己的一條線）。` : ""}`,
          method: nonlinear ? "Spearman 秩相關＋5 折交叉驗證比較直線／LOESS＋殘差變異數分析" : "Pearson／Spearman 相關＋ t 檢定＋直線迴歸",
          tags, vars: [A.key, B.key].concat(colorHint ? [colorHint.key] : []), spec
        }));
      }
    }
    return out;
  }

  // ---- 組間差異（單因子 ANOVA）----
  // 當整體 ANOVA 不顯著時，改用「配對／區塊」設計：把另一個變數（例如月份）的變異扣掉再比
  function blockedCard(ctx, f, m, keys, plain) {
    let best = null;
    const tryBlock = (blkP, kind) => {
      if (!blkP || !blkP.col) return;
      const blocks = m.idx.map((row) => catOf(blkP.col.values[row]));
      const ba = blockedAnova(m.values, m.ws, keys, blocks);
      if (!ba || ba.p >= 0.05 || ba.eta2 < 0.06) return;
      if (!best || ba.eta2 > best.ba.eta2) best = { blkP, kind, ba };
    };
    ctx.times.forEach((t) => { if (t.n >= 12) tryBlock(t, "time"); });
    ctx.factors.forEach((blk) => { if (blk !== f && blk.levels >= 3 && blk.levels <= 14) tryBlock(blk, "cat"); });
    if (!best) return null;
    const { blkP, kind, ba } = best;
    const hi = ba.groups[0], lo = ba.groups[ba.groups.length - 1];
    const cons = ba.consistent && ba.consistent.share >= 0.6
      ? `每個 ${blkP.key} 裡都是 <b>${ba.consistent.top}</b> 最高（${ba.blocks} 個區塊中的 ${Math.round(ba.consistent.share * ba.blocks)} 個，${fpct(ba.consistent.share, 0)}），代表穩定的順序而不是偶爾的高值。` : "";
    const spec = kind === "time"
      ? mkSpec({ X: [blkP.key], Y: [m.key], Color: [f.key] },
        { points: { alpha: 0.4, size: 2.6 }, time: { width: 2, rolling: 0, showPoints: true } }, { freq: ctx.freqKey, height: 244 })
      : mkSpec({ X: [blkP.key], Y: [m.key], Color: [f.key] },
        { points: { alpha: 0.34, size: 2.6 }, line: { statistic: "mean", width: 2.1, ci: false, showPoints: false } }, { freq: ctx.freqKey, height: 244 });
    return card("groupdiff", 0.5 + scale01(ba.eta2, 0.06, 0.6) * 0.3, {
      title: `${f.key} 之間的 ${m.key} 差異被 ${blkP.key} 掩蓋了（同 ${blkP.key} 內比較：η² = ${fst(ba.eta2)}）`,
      detail: `不考慮 ${blkP.key} 時${plain ? ` η² 只有 ${fst(plain.eta2)}、${fmtP(plain.p)}` : "看不出差異"}；因為 ${blkP.key} 本身的變化很大，會把組間差異吃掉。把 ${blkP.key} 當區塊（${ba.blocks} 個區塊、每區塊都含全部 ${ba.k} 組）後：F(${ba.dfG}, ${ba.dfE}) = ${fst(ba.F)}，${fmtP(ba.p)}，η² 升到 ${fst(ba.eta2)}。${hi.mean > lo.mean ? `<b>${hi.k}</b>（${fnum(hi.mean)}）比 <b>${lo.k}</b>（${fnum(lo.mean)}）高 ${fnum(hi.mean - lo.mean)}。` : ""}${cons}`,
      method: "隨機區塊（配對）變異數分析：先扣掉 " + blkP.key + " 的變異再比較組間",
      tags: ["配對 η² = " + fst(ba.eta2), "F = " + fst(ba.F), fmtP(ba.p), "區塊 = " + blkP.key + " × " + ba.blocks],
      vars: [m.key, f.key, blkP.key], spec,
      eta2: ba.eta2, factor: f.key, measure: m.key, overlayKey: null, blockKey: blkP.key, blockKind: kind
    });
  }

  function detectGroupDiff(ctx) {
    const out = [];
    for (const f of ctx.factors) {
      if (f.levels < 2 || f.levels > 12) continue;
      for (const m of ctx.measures) {
        const keys = m.idx.map((row) => catOf(f.col.values[row]));
        const an = groupAnova(m.values, m.ws, keys);
        if (!an || an.p >= 0.05 || an.eta2 < 0.06) {
          const bc = blockedCard(ctx, f, m, keys, an);
          if (bc) out.push(bc);
          continue;
        }
        const gs = an.groups;
        const hi = gs[0], lo = gs[gs.length - 1];
        let pair = null;
        try {
          const pick = (k) => { const v = [], w = []; m.idx.forEach((row, t) => { if (catOf(f.col.values[row]) === k) { v.push(m.values[t]); w.push(m.ws[t]); } }); return { vals: v, ws: w }; };
          pair = welchT(pick(hi.k), pick(lo.k));
        } catch (e) { /* 忽略 */ }
        const spread = m.sd ? Math.abs(hi.mean - lo.mean) / m.sd : 0;

        // 第二個因子當 Overlay（只在格子夠多時）
        let overlay = null;
        for (const f2 of ctx.factors) {
          if (f2 === f || f2.levels < 2 || f2.levels > 3) continue;
          if (f.levels * f2.levels > 12) continue;
          const an2 = groupAnova(m.values, m.ws, m.idx.map((row) => catOf(f2.col.values[row])));
          if (an2 && an2.p < 0.05 && an2.eta2 >= 0.05) { overlay = f2; break; }
        }
        const spec = mkSpec(
          Object.assign({ X: [f.key], Y: [m.key] }, overlay ? { Color: [overlay.key] } : {}),
          { points: { alpha: 0.4, size: 3 }, box: { fillOpacity: 0.22, showMean: true }, line: { statistic: "mean", ci: true, width: 1.8, showPoints: false, alpha: 0.95 } },
          { freq: ctx.freqKey });
        out.push(card("groupdiff", scale01(an.eta2, 0.06, 0.6) * 0.6 + scale01(m.n, 12, 120) * 0.12 + scale01(spread, 0.5, 2) * 0.2 + (overlay ? 0.06 : 0), {
          title: `${m.key} 依 ${f.key} 有明顯差異（η² = ${fst(an.eta2)}）`,
          detail: `F(${an.df1}, ${an.df2}) = ${fst(an.F)}，${fmtP(an.p)}，共 ${gs.length} 組${an.dropped ? `（n<3 的 ${an.dropped} 組已忽略）` : ""}。最高 <b>${hi.k}</b>（${fnum(hi.mean)}）比最低 <b>${lo.k}</b>（${fnum(lo.mean)}）高 ${fnum(Math.abs(hi.mean - lo.mean))}${hi.mean && lo.mean ? "（" + fpct(Math.abs(hi.mean - lo.mean) / Math.abs(lo.mean), 0) + "）" : ""}${pair ? `；兩組差異檢定 t = ${fst(pair.t)}，${fmtP(pair.p)}` : ""}。箱形圖＋原點＋平均數線是最清楚的画法。`,
          method: "加權單因子變異數分析（ANOVA）＋ Welch t 檢定",
          tags: ["η² = " + fst(an.eta2), "F = " + fst(an.F), fmtP(an.p), "k = " + gs.length, "N = " + m.n],
          vars: [m.key, f.key].concat(overlay ? [overlay.key] : []), spec,
          eta2: an.eta2, factor: f.key, measure: m.key, overlayKey: overlay ? overlay.key : null, blockKey: null, blockKind: null
        }));
      }
    }
    return out;
  }

  // ---- 分布形態（偏態／雙峰／離群值）----
  function detectDistribution(ctx) {
    const out = [];
    for (const m of ctx.measures) {
      if (m.n < 20 || m.distinct < 8) continue;
      const signals = [];
      const sk = Math.abs(m.skew || 0);
      if (sk >= 0.75) signals.push(["偏態", scale01(sk, 0.75, 2.2)]);
      if (m.bc >= 0.65 && sk < 1.0) signals.push(["雙峰", scale01(m.bc, 0.65, 1.1)]);
      if (m.outlierShare >= 0.02 && m.outliers.length >= 3) signals.push(["離群值", scale01(m.outlierShare, 0.02, 0.09)]);
      if (!signals.length) continue;
      const s = Math.max.apply(null, signals.map((x) => x[1]));
      const kindsTxt = signals.map((x) => x[0]).join("＋");

      let explainer = null, exEta = 0;
      if (m.bc >= 0.6) {
        for (const f of ctx.factors) {
          if (f.levels < 2 || f.levels > 8) continue;
          const an = groupAnova(m.values, m.ws, m.idx.map((row) => catOf(f.col.values[row])));
          if (an && an.p < 0.01 && an.eta2 > exEta) { exEta = an.eta2; explainer = { f, an }; }
        }
      }
      const which = signals.map((x) => x[0]);
      let why = [];
      if (which.includes("偏態")) why.push(`平均數 ${fnum(m.mean)} 明顯${m.skew > 0 ? "大於" : "小於"}中位數 ${fnum(m.median)}（偏態 ${fst(m.skew)}），${m.skew > 0 ? "右側有長尾" : "左側有長尾"}`);
      if (which.includes("雙峰")) why.push(`雙峰係數 BC = ${fst(m.bc)}（> 0.55 通常代表兩群混在一起）`);
      if (which.includes("離群值")) why.push(`${m.outliers.length} 列（${fpct(m.outlierShare)}）落在 1.5×IQR 柵欄外（< ${fnum(m.fenceLo)} 或 > ${fnum(m.fenceHi)}）`);

      const labelCol = ctx.labelCol;
      if (which.includes("離群值") && labelCol && m.outliers.length) {
        const names = [];
        for (let k = 0; k < m.idx.length && names.length < 3; k++) {
          const v = m.values[k];
          if (v < m.fenceLo || v > m.fenceHi) {
            const row = ctx.ds.rows[m.idx[k]];
            names.push((row[labelCol.key] != null ? row[labelCol.key] + " " : "") + fnum(v));
          }
        }
        if (names.length) why.push(`極端值：${names.join("、")}`);
      }
      const spec = mkSpec(Object.assign({ X: [m.key] }, explainer ? { Color: [explainer.f.key] } : {}),
        { histogram: { density: true, binRule: m.n >= 40 ? "fd" : "sturges", fillOpacity: 0.68 } },
        { freq: ctx.freqKey, height: 224 });
      out.push(card("distribution", s * 0.55 + scale01(m.n, 20, 200) * 0.1 + (explainer ? 0.15 : 0), {
        title: `${m.key} 的分布${which.includes("雙峰") ? "出現雙峰，可能是兩個族群混在一起" : which.includes("偏態") ? (m.skew > 0 ? "右偏（長尾在高值端）" : "左偏（長尾在低值端）") : "有幾個離群值"}`,
        detail: why.join("；") + `。${explainer ? `用 <b>${explainer.f.key}</b> 著色後就分成兩堆（組間差異 η² = ${fst(exEta)}），表示這不是同一個母體。` : ""}用直方圖＋密度曲線最容易看出来。`,
        method: "偏態／峰度／雙峰係數（BC）＋ 1.5×IQR 柵欄" ,
        tags: ["n = " + m.n, "偏態 = " + fst(m.skew), "BC = " + fst(m.bc), "離群 " + m.outliers.length + " 列"],
        vars: [m.key].concat(explainer ? [explainer.f.key] : []), spec
      }));
    }
    return out;
  }

  // ---- 類別 × 類別（卡方獨立性檢定）----
  function detectAssociation(ctx) {
    const out = [];
    const fs = ctx.factors.filter((p) => p.levels >= 2 && p.levels <= 10);
    for (let i = 0; i < fs.length; i++) {
      for (let j = i + 1; j < fs.length; j++) {
        const cs = chiSquare(fs[i], fs[j], ctx.idx, ctx.weightOf, 10);
        if (!cs || cs.p >= 0.05 || cs.V < 0.1 || cs.smallExpected > 0.2) continue;
        const b = cs.best;
        const rowShare = cs.table[b.i][b.j] / (cs.rt[b.i] || 1);
        const colShare = cs.table[b.i][b.j] / (cs.ct[b.j] || 1);
        const others = cs.rowKeys.filter((_, x) => x !== b.i)
          .map((x) => cs.table[cs.rowKeys.indexOf(x)][b.j] / (cs.rt[cs.rowKeys.indexOf(x)] || 1));
        const avgOther = others.length ? others.reduce((a, c) => a + c, 0) / others.length : 0;
        const many = cs.rowKeys.length <= cs.colKeys.length;
        const spec = cs.rowKeys.length * cs.colKeys.length <= 42
          ? mkSpec({ X: [fs[i].key], Y: [fs[j].key] }, { mosaic: { labels: true, bins: 4 } }, { freq: ctx.freqKey, legend: false, height: 228 })
          : mkSpec({ X: [fs[i].key], Y: [fs[j].key] }, { heatmap: { statistic: "n", colorMap: "YlOrRd", showValues: false } }, { freq: ctx.freqKey, height: 228 });
        out.push(card("association", scale01(cs.V, 0.1, 0.5) * 0.62 + scale01(cs.grand, 20, 200) * 0.1, {
          title: `${fs[i].key} 與 ${fs[j].key} 的類別分布有關聯（Cramér's V = ${fst(cs.V)}）`,
          detail: `χ²(${cs.df}) = ${fst(cs.x2)}，${fmtP(cs.p)}（N = ${Math.round(cs.grand)}）。最偏離期望的格子是 <b>${cs.rowKeys[b.i]} × ${cs.colKeys[b.j]}</b>（標準化殘差 z = ${fst(b.z)}）：${cs.rowKeys[b.i]} 裡有 ${fpct(rowShare, 0)} 落在 ${cs.colKeys[b.j]}，其他各組平均只有 ${fpct(avgOther, 0)}。${many ? "馬賽克圖的寬高直接反應這兩個比例" : "馬賽克圖可以看出寬高兩方向的偏移"}。`,
          method: "卡方獨立性檢定＋Cramér's V＋標準化殘差",
          tags: ["V = " + fst(cs.V), "χ² = " + fst(cs.x2), fmtP(cs.p), "N = " + Math.round(cs.grand)],
          vars: [fs[i].key, fs[j].key], spec
        }));
      }
    }
    return out;
  }

  // ---- 時間趨勢／循環 ----
  function detectTrend(ctx) {
    const out = [];
    if (!ctx.times.length) return out;
    for (const t of ctx.times) {
      for (const m of ctx.measures) {
        const shared = alignPair(t, m);
        if (shared.xs.length < 12) continue;
        const fit = trendFit(shared.xs, shared.ys, shared.ws);
        if (fit && fit.p < 0.05 && fit.r2 >= 0.15) {
          const up = fit.slope > 0;
          const spec = mkSpec({ X: [t.key], Y: [m.key] },
            { time: { width: 2, rolling: fit.r2 >= 0.7 ? 0 : Math.max(2, Math.min(12, Math.round(Math.sqrt(fit.n)))), showPoints: fit.n <= 60 } },
            { freq: ctx.freqKey, height: 240 });
          out.push(card("trend", scale01(fit.r2, 0.15, 0.8) * 0.6 + scale01(fit.n, 12, 120) * 0.15, {
            title: `${m.key} 隨 ${t.key}${up ? "上升" : "下降"}（每${fit.per} ${up ? "+" : "−"}${fnum(Math.abs(fit.slope))}）`,
            detail: `線性趨勢 R² = ${fst(fit.r2)}，${fmtP(fit.p)}；期間 ${dateText(fit.t0)} ～ ${dateText(fit.t1)} 共${up ? "增加" : "減少"} ${fnum(Math.abs(fit.total))}${fit.mean ? "（等於平均值 " + fpct(Math.abs(fit.total) / Math.abs(fit.mean), 0) + "）" : ""}。時間序列圖加上移動平均可以同時看到趨勢和短期波動。`,
            method: "以時間為自變數的加權直線迴歸（斜率 t 檢定）",
            tags: ["R² = " + fst(fit.r2), fmtP(fit.p), "斜率/" + fit.per + " = " + fst(fit.slope), "n = " + fit.n],
            vars: [m.key, t.key], spec
          }));
        }
        // 分組趨勢：各組方向一致時，加 Color 會比加總更有意義
        for (const f of ctx.factors) {
          if (f.levels < 2 || f.levels > 6) continue;
          const byG = new Map();
          for (let k = 0; k < shared.xs.length; k++) {
            const g = catOf(f.col.values[shared.idx[k]]);
            const arr = byG.get(g) || []; arr.push([shared.xs[k], shared.ys[k], shared.ws[k]]); byG.set(g, arr);
          }
          const fits = [];
          byG.forEach((arr, g) => {
            if (arr.length < 8) return;
            const ff = trendFit(arr.map((a) => a[0]), arr.map((a) => a[1]), arr.map((a) => a[2]));
            if (ff) fits.push({ g, ff });
          });
          if (fits.length < 2 || fits.length !== byG.size) continue;
          const sign = Math.sign(fits[0].ff.slope);
          const same = fits.filter((x) => Math.sign(x.ff.slope) === sign).length;
          const sig = fits.filter((x) => x.ff.p < 0.05 && Math.sign(x.ff.slope) === sign).length;
          const meanR2 = fits.reduce((a, x) => a + x.ff.r2, 0) / fits.length;
          if (same < fits.length || sig < Math.max(2, Math.ceil(fits.length * 0.6)) || meanR2 < 0.3) continue;
          const spec = mkSpec({ X: [t.key], Y: [m.key], Color: [f.key] },
            { time: { width: 1.9, rolling: meanR2 >= 0.7 ? 0 : 3, showPoints: fits[0].ff.n <= 40 } },
            { freq: ctx.freqKey, height: 240 });
          out.push(card("trend", scale01(meanR2, 0.3, 0.85) * 0.6 + 0.18, {
            title: `各 ${f.key} 的 ${m.key} 都朝同一個方向${sign > 0 ? "上升" : "下降"}`,
            detail: `${fits.length} 個 ${f.key} 分組的趨勢方向全部一致，其中 ${sig} 組達顯著（平圴 R² = ${fst(meanR2)}）。加總成一條線會被平均掉，用 Color 分組的時間序列才能看出各組自己的節奏。`,
            method: "分組線性趨勢（各組斜率符號與顯著性一致）",
            tags: fits.slice(0, 3).map((x) => x.g + " " + fst(x.ff.slope) + "/" + x.ff.per).concat(["R² = " + fst(meanR2)]),
            vars: [m.key, t.key, f.key], spec
          }));
        }
      }
    }
    return out;
  }

  function detectSeasonal(ctx) {
    const out = [];
    for (const t of ctx.times) {
      for (const m of ctx.measures) {
        const shared = alignPair(t, m);
        if (shared.xs.length < 14) continue;
        let best = null, colorKey = null;
        const plain = shared.idx.map((_, k) => [shared.xs[k], shared.ys[k]]).sort((a, b) => a[0] - b[0]).map((a) => a[1]);
        const pk = acfPeaks(plain, 24);
        if (pk) best = pk;
        for (const f of ctx.factors) {
          if (f.levels < 2 || f.levels > 5) continue;
          const byG = new Map();
          for (let k = 0; k < shared.xs.length; k++) {
            const g = catOf(f.col.values[shared.idx[k]]);
            const arr = byG.get(g) || []; arr.push([shared.xs[k], shared.ys[k]]); byG.set(g, arr);
          }
          const vals = [];
          let ok = true;
          byG.forEach((arr) => {
            arr.sort((a, b) => a[0] - b[0]);
            if (arr.length < 14) ok = false;
            vals.push(arr.map((a) => a[1]));
          });
          if (!ok || vals.length < 2) continue;
          const peaks = vals.map((v) => acfPeaks(v, 24));
          if (!peaks.every((p) => p && p.lag === peaks[0].lag)) continue;
          const strength = peaks.reduce((a, p) => a + p.value, 0) / peaks.length;
          if (!best || strength > best.value) { best = { lag: peaks[0].lag, value: strength }; colorKey = f.key; }
        }
        if (!best) continue;
        const spec = mkSpec(colorKey ? { X: [t.key], Y: [m.key], Color: [colorKey] } : { X: [t.key], Y: [m.key] },
          { time: { width: 1.9, rolling: 0, showPoints: true } }, { freq: ctx.freqKey, height: 240 });
        out.push(card("seasonal", 0.4 + scale01(best.value, 0.65, 0.95) * 0.4, {
          title: `${m.key} 有週期約 ${best.lag} 期的循環型態（自我相關 ${fst(best.value)}）`,
          detail: `去掉長期趨勢後，序列與自己往後 ${best.lag} 期的相關係數高達 ${fst(best.value)}，而半期（${Math.max(1, Math.round(best.lag / 2))} 期）相關接近 0 或負的——這是「重複出現的波峰波谷」而不是隨機波動。${colorKey ? "用 <b>" + colorKey + "</b> 分組後各組的週期長度相同，所以畫在同一張圖。" : ""}建議再加一條移動平均（rolling = ${Math.max(2, Math.round(best.lag / 3))}）標出週期。`,
          method: "去趨勢後的自我相關函數（ACF）搜尋",
          tags: ["週期 ≈ " + best.lag + " 期", "ACF = " + fst(best.value), "n = " + shared.xs.length],
          vars: [m.key, t.key].concat(colorKey ? [colorKey] : []), spec
        }));
        break;
      }
      if (out.length) break;
    }
    return out;
  }

  // ---- 組成／集中度 ----
  function detectComposition(ctx) {
    const out = [];
    for (const f of ctx.factors) {
      if (f.levels < 2 || f.levels > 12 || f.n < 10) continue;
      if (f.topShare < 0.34 && f.top2 < 0.55) continue;
      let valueMode = null;
      for (const m of ctx.measures) {
        if (m.role === "measure" || m.role === "freq") {
          const neg = m.values ? m.values.filter((v) => v < 0).length : 0;
          if (m.n < 8 || m.distinct < 2 || neg > m.n * 0.02) continue;
          const keys = m.idx.map((row) => catOf(f.col.values[row]));
          const sums = new Map();
          m.values.forEach((v, k) => { const g = keys[k]; sums.set(g, (sums.get(g) || 0) + v * m.ws[k]); });
          const arr = Array.from(sums, ([k, v]) => ({ k, v })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v);
          if (arr.length < 2) continue;
          const tot = arr.reduce((a, x) => a + x.v, 0);
          const top = arr[0].v / tot, top2 = arr.length > 1 ? (arr[0].v + arr[1].v) / tot : top;
          if (top >= 0.42 && arr.length >= 3) { valueMode = { m, arr: arr.map((x) => ({ k: x.k, share: x.v / tot, v: x.v })), top, top2, tot }; break; }
        }
      }
      const vm = valueMode;
      const strong = f.topShare >= 0.4 || (f.levels >= 4 && f.top2 >= 0.6) || !!vm;
      if (!strong) continue;
      const cats = vm ? vm.arr : f.cats.map((c) => ({ k: c.k, share: c.share }));
      const top = cats[0], top3 = cats.slice(0, 3).reduce((a, c) => a + c.share, 0);
      const spec = vm
        ? mkSpec({ X: [f.key], Y: [vm.m.key] }, { pie: { statistic: "sum", sort: "desc", labels: true, hole: 0 } }, { freq: null, height: 244 })
        : mkSpec({ X: [f.key] }, { pie: { statistic: "count", sort: "desc", labels: true, hole: 0 } }, { freq: null, height: 244 });
      out.push(card("composition", (scale01(top.share, 0.3, 0.7) * 0.4 + scale01(cats.length, 2, 8) * 0.12), {
        title: `${f.key}：${top.k} 一類就占了 ${fpct(top.share, 0)}${vm ? "（按 " + vm.m.key + " 總和算）" : " 的資料量"}`,
        detail: `共 ${cats.length} 類。${cats.slice(0, 3).map((c, i) => (i + 1) + ". " + c.k + " " + fpct(c.share, 1)).join("、")}${cats.length > 3 ? "，前三類合計 " + fpct(top3, 0) : ""}。${vm ? "這是<b>可加總</b>的量的集中度（不是行數佔比），圓餅圖按總和排序最能看出「大頭在哪」。" : "圓餅圖按次數佔比排序，一眼看出比例是否失衡。"}`,
        method: vm ? "分類加總＋佔比（Herfindahl 集中度）" : "分類次數佔比",
        tags: [vm ? vm.m.key + " 總和" : "次數", "Top = " + fpct(top.share, 0), "類數 = " + cats.length],
        vars: [f.key].concat(vm ? [vm.m.key] : []), spec
      }));
    }
    return out;
  }

  // ---- 流量結構（桑基圖）----
  function detectFlow(ctx) {
    const out = [];
    const cats = ctx.ds.columns.map((c) => ctx.profiles.find((p) => p.key === c.key))
      .filter((p) => p && p.type !== "continuous" && p.role !== "label" && p.levels >= 3 && p.levels <= 150 && p.n >= 6);
    const srcHint = /(^|_|\b)(from|source|src|origin|producer|supply|初級|來源|起|供給|送端)(_|$|\b)/i;
    const dstHint = /(^|_|\b)(to|target|dest|destination|demand|use|sector|部門|目標|迄|使用|需求)/i;
    const weight = ctx.measures.find((m) => m.n >= ctx.idx.length * 0.9 && m.values.every((v) => v > 0));
    const noted = new Set();
    for (let i = 0; i < cats.length; i++) {
      for (let j = 0; j < cats.length; j++) {
        if (i === j) continue;
        const A = cats[i], B = cats[j];
        const hinted = srcHint.test(A.key) && dstHint.test(B.key);
        const setA = new Set(A.cats.map((c) => c.k)), setB = new Set(B.cats.map((c) => c.k));
        const wOf = weight ? ((row) => { const v = num(weight.col.values[row]); return v == null || v <= 0 ? 0 : v; }) : (() => 1);
        const links = new Map();
        let wsum = 0, nRows = 0;
        for (let k = 0; k < ctx.idx.length; k++) {
          const row = ctx.idx[k];
          const a = catOf(A.col.values[row]), b = catOf(B.col.values[row]);
          if (!setB.has(b)) continue;
          const key = a + "\u0001" + b;
          const w = wOf(row);
          links.set(key, (links.get(key) || 0) + w);
          wsum += w; nRows++;
        }
        if (links.size < 5) continue;
        // 節點與度數：真正的流量是「網」，不是一對一的階層
        const nodes = new Set(); links.forEach((_, k) => { const [a, b] = k.split("\u0001"); nodes.add(a); nodes.add(b); });
        const outDeg = new Map(), inDeg = new Map();
        links.forEach((_, k) => {
          const [a, b] = k.split("\u0001");
          outDeg.set(a, (outDeg.get(a) || 0) + 1); inDeg.set(b, (inDeg.get(b) || 0) + 1);
        });
        const avgOut = links.size / Math.max(1, outDeg.size), avgIn = links.size / Math.max(1, inDeg.size);
        const layer = new Map();
        const bump = (n, d, guard) => {
          if (guard > 12 || !nodes.has(n)) return;
          layer.set(n, Math.max(layer.get(n) || 0, d));
          links.forEach((_, key) => { const [a, b] = key.split("\u0001"); if (a === n) bump(b, d + 1, guard + 1); });
        };
        Array.from(setA).filter((k) => !Array.from(links.keys()).some((key) => key.split("\u0001")[1] === k)).forEach((k) => bump(k, 0, 0));
        const layers = layer.size ? Math.max.apply(null, Array.from(layer.values())) + 1 : 2;
        const perRowLink = links.size >= Math.max(6, 0.75 * nRows);         // 每列就是一條（已彙總的）流
        const mesh = avgOut >= 1.8 && avgIn >= 1.8 && nodes.size >= 5 && nodes.size <= 45 && links.size >= 8;
        const looksFlow = hinted || (perRowLink && layers >= 3) || (avgOut >= 1.8 && avgIn >= 1.8 && links.size >= 20);
        if (!mesh && looksFlow && nodes.size > 45) {
          const nk = [A.key, B.key].sort().join("|");
          if (!noted.has(nk)) {
            noted.add(nk);
            ctx.notes.push(`偵測到 ${A.key} → ${B.key} 的流量結構，但有 ${nodes.size} 個節點（${links.size} 條流）——桑基圖會擠到不可讀，建議先在資料表裡彙總或只留前 30 大節點。`);
          }
        }
        if (!mesh) continue;                                                 // 一對一的階層（城市→洲）不叫流量
        if (!(hinted || (perRowLink && layers >= 3))) continue;              // 名稱不像流量、又只有兩層 → 不建議桑基圖
        let topLink = null;
        links.forEach((v, k) => { if (!topLink || v > topLink.v) topLink = { k, v }; });
        const [tl, tr] = topLink.k.split("\u0001");
        const spec = weight
          ? mkSpec({ X: [A.key], Y: [B.key], Freq: [weight.key] }, { sankey: { values: true, labels: true, gap: 12, colorMode: "node", gradient: true } }, { freq: weight.key, height: 300, legend: false })
          : mkSpec({ X: [A.key], Y: [B.key] }, { sankey: { values: true, labels: true, gap: 12 } }, { height: 300, legend: false });
        out.push(card("flow", (hinted ? 0.55 : 0.4) + scale01(nodes.size, 6, 30) * 0.2 + scale01(layers, 2, 4) * 0.12, {
          title: `${A.key} → ${B.key} 是流量結構，適合桑基圖（${nodes.size} 個節點、${links.size} 條流）`,
          detail: `自動分出 ${layers} 層（同一個名稱同時出現在左右兩側就會被推到中間層）。最大的一條是 <b>${tl} → ${tr}</b>（${fnum(topLink.v)}，佔 ${fpct(topLink.v / wsum, 1)}）${weight ? "，流量欄用 <b>" + weight.key + "</b>（放到 Freq）" : "，每列計為 1"}。這種「誰流到誰」的資料用長條圖會失去路徑資訊。`,
          method: "來源/目標欄位辨識＋最長路徑分層",
          tags: [nodes.size + " 節點", links.size + " 條流", layers + " 層", weight ? "Freq = " + weight.key : "每列 = 1"],
          vars: [A.key, B.key].concat(weight ? [weight.key] : []), spec
        }));
        if (out.length >= 2) return out;
      }
    }
    return out;
  }

  // ---- 地理 ----
  function detectMap(ctx) {
    const lat = ctx.profiles.find((p) => p.role === "lat"), lon = ctx.profiles.find((p) => p.role === "lon");
    if (!lat || !lon || !lat.col || lat.n < 3) return [];
    const color = ctx.factors.filter((f) => f.levels >= 2 && f.levels <= 8).sort((a, b) => b.balance - a.balance)[0] || null;
    const size = ctx.measures.filter((m) => m.cv > 0.25).sort((a, b) => (b.cv || 0) - (a.cv || 0))[0] || null;
    const spec = mkSpec(Object.assign({}, color ? { Color: [color.key] } : {}, size ? { Size: [size.key] } : {}),
      { map: { bubbles: true, maxSize: 26 } }, { height: 300 });
    return [card("map", 0.72 + (color ? 0.08 : 0) + (size ? 0.06 : 0), {
      title: `資料含經緯度（${lat.key}/${lon.key}），用互動式地理圖看空間分布`,
      detail: `${lat.n} 個位置${color ? `，以 <b>${color.key}</b> 著色（${color.levels} 類）` : ""}${size ? `，點的大小用 <b>${size.key}</b>（变异係數 ${fpct(size.cv, 0)}，差異大到值得用大小編碼）` : ""}。地圖可以滾輪縮放、拖曳，雙擊還原。`,
      method: "經緯度欄位辨識＋著色/大小編碼推薦",
      tags: [lat.key + " / " + lon.key, lat.n + " 個位置"].concat(color ? [color.key] : []).concat(size ? ["Size = " + size.key] : []),
      vars: [lat.key, lon.key].concat(color ? [color.key] : []), spec
    })];
  }

  // ---- 三變數氣泡 ----
  function detectBubble(ctx, best) {
    if (!best || ctx.measures.length < 3) return [];
    const pair = best.vars.slice(0, 2);
    const A = ctx.profiles.find((p) => p.key === pair[0]), B = ctx.profiles.find((p) => p.key === pair[1]);
    if (!A || !B) return [];
    let third = null, bestR = 0.3;
    for (const m of ctx.measures) {
      if (m.key === A.key || m.key === B.key) continue;
      const p1 = alignPair(A, m), p2 = alignPair(B, m);
      const r1 = p1.xs.length >= 8 ? pearson(p1.xs, p1.ys, p1.ws) : null;
      const r2 = p2.xs.length >= 8 ? pearson(p2.xs, p2.ys, p2.ws) : null;
      const s = Math.max(r1 ? Math.abs(r1.r) : 0, r2 ? Math.abs(r2.r) : 0);
      if (s > bestR) { bestR = s; third = m; }
    }
    if (!third) return [];
    const spec = mkSpec({ X: [A.key], Y: [B.key], Size: [third.key] },
      { points: { alpha: 0.66, size: 4 }, line: { statistic: "mean", ci: false, width: 1.6, showPoints: false, alpha: 0.9 } },
      { freq: ctx.freqKey, height: 244 });
    return [card("bubble", (best.score || 0.6) * 0.62, {
      title: `同一張圖看三個變數：${A.key} × ${B.key} × ${third.key}（點大小）`,
      detail: `${third.key} 與這對變數的相關可達 |r| = ${fst(bestR)}，用 <b>Size</b> 區塊編碼最合適（JMP 的做法：把 ${third.key} 拖到 Size）。${B.n >= 20 ? "再疊一條群組平均線當參考。" : ""}`,
      method: "第三變數與既有軸的相關強度",
      tags: ["Size = " + third.key, "|r| = " + fst(bestR), "n = " + B.n],
      vars: [A.key, B.key, third.key], spec
    })];
  }

  // ---- 多頁面板（多個 Y）----
  function detectPanel(groupCards) {
    const byFactor = new Map();
    groupCards.forEach((c) => {
      if (!c.eta2 || c.eta2 < 0.09) return;
      const arr = byFactor.get(c.factor) || [];
      arr.push(c); byFactor.set(c.factor, arr);
    });
    const out = [];
    byFactor.forEach((arr, factor) => {
      if (arr.length < 2) return;
      const pick = arr.slice(0, 3);
      const ys = pick.map((c) => c.measure);
      const blockedSame = pick.every((c) => c.blockKey && c.blockKey === pick[0].blockKey);
      let spec, title, detail;
      if (blockedSame) {
        const bk = pick[0].blockKey, isTime = pick[0].blockKind === "time";
        spec = mkSpec({ X: [bk], Y: ys, Color: [factor] },
          isTime
            ? { points: { alpha: 0.4, size: 2.6 }, time: { width: 2, rolling: 0, showPoints: true } }
            : { points: { alpha: 0.34, size: 2.6 }, line: { statistic: "mean", width: 2.1, ci: false, showPoints: false } },
          { freq: null, height: 344 });
        title = `${factor} 的 ${ys.join("、")}：同 ${bk} 比較才看得出來（多個 Y 一次看）`;
        detail = `把 ${ys.join("、")} 一起放到 <b>Y</b> 區塊（順序＝面板由上而下），X 用區塊變數 <b>${bk}</b>、Color 用 <b>${factor}</b>。每一格里 ${factor} 的各條線大致平行 ⇒ ${factor} 造成的差距在各個 ${bk} 下都差不多，這正是「配對比較」的圖形證據（配對 η² = ${pick.map((c) => fst(c.eta2)).join(" / ")}）。`;
      } else {
        spec = mkSpec(Object.assign({ X: [factor], Y: ys }, pick[0].overlayKey ? { Color: [pick[0].overlayKey] } : {}),
          { points: { alpha: 0.4, size: 2.8 }, box: { fillOpacity: 0.2, showMean: true }, line: { statistic: "mean", ci: false, width: 1.6, showPoints: false } },
          { freq: null, height: 340 });
        title = `${factor} 的 ${ys.join("、")} 都有群組差異 → 用多個 Y 一次比`;
        detail = `把 ${ys.join("、")} 全放到 <b>Y</b> 區塊（擺放順序＝面板由上而下），每格用自己的單位與刻度，不用換圖就能對照同一個 ${factor} 分組。η² 分別是 ${pick.map((c) => fst(c.eta2)).join("、")}。`;
      }
      out.push(card("panel", 0.44 + scale01(Math.max.apply(null, pick.map((c) => c.eta2)), 0.1, 0.5) * 0.35, {
        title, detail,
        method: "同一分組因子下、多個量測變數的變異數分析彙整",
        tags: ["多個 Y × " + ys.length, "η² = " + pick.map((c) => fst(c.eta2)).join(" / ")],
        vars: [factor].concat(ys), spec
      }));
    });
    return out;
  }

  // ---- 點密度（等高線）----
  function detectDensity(best) {
    if (!best || best.kind !== "correlation") return [];
    const [a, b] = best.vars;
    const spec = mkSpec({ X: [a], Y: [b] },
      { contour: { levels: 8, fill: true, fillOpacity: 0.4, bandwidth: 1, showPoints: true, grid: 50 }, points: { alpha: 0.4, size: 2.6 } },
      { freq: null, height: 250 });
    return [card("density", (best.score || 0.6) * 0.72, {
      title: `${a} × ${b} 的點密度（等高線）顯示資料集中在哪裡`,
      detail: "散點重疊時看不出「哪裡最密」。等高線圖用二維核密度估出同樣的機率輪廓，配上淡的原始點可以同时看離群的位置。",
      method: "二維核密度估計（Gaussian kernel）＋ 8 條位準",
      tags: ["8 條等高線", "a = " + a, "b = " + b],
      vars: [a, b], spec
    })];
  }

  // ==================================================================
  // 7) 主流程
  // ==================================================================
  function analyze(ds, opts) {
    const o = opts || {};
    const t0 = Date.now();
    const out = { cards: [], all: [], scanned: {}, sampled: false, notes: [], ms: 0 };
    if (!ds || !ds.rows || !ds.rows.length) { out.notes.push("資料表是空的。"); return out; }

    let idxs = [];
    for (let i = 0; i < ds.rows.length; i++) if (!ds.excluded.has(i)) idxs.push(i);
    if (!idxs.length) { out.notes.push("所有資料列都被排除，沒有可用的資料。"); return out; }
    if (idxs.length > MAX_SCAN_ROWS) {
      const step = idxs.length / MAX_SCAN_ROWS;
      const s = [];
      for (let k = 0; k < MAX_SCAN_ROWS; k++) s.push(idxs[Math.floor(k * step)]);
      idxs = s; out.sampled = true;
    }
    const freqKey = o.freqKey || null;
    const freqCol = freqKey ? ds.columns.find((c) => c.key === freqKey) : null;
    const weightOf = (i) => {
      if (!freqCol) return 1;
      const v = num(freqCol.values[i]);
      return v != null && v > 0 ? v : 1;
    };

    const profiles = ds.columns.map((c) => profileColumn(c, idxs, weightOf));
    const measures = profiles.filter(isMeasure).sort((a, b) => (b.n * b.distinct) - (a.n * a.distinct));
    const factors = profiles.filter((p) => isFactor(p, 2, 20, false)).sort((a, b) => a.levels - b.levels);
    const times = profiles.filter((p) => p.isTime && p.n >= 8);
    const labelCol = ds.columns.find((c) => c.role === "label") || null;

    const ctx = {
      ds, idx: idxs, idxs, weightOf, freqKey: freqCol ? freqKey : null, profiles, measures, factors, times, labelCol, notes: []
    };
    out.scanned = {
      columns: ds.columns.length, rows: ds.rows.length, used: idxs.length, excluded: ds.excluded.size,
      measures: measures.map((m) => m.key), factors: factors.map((f) => f.key), times: times.map((t) => t.key),
      freq: ctx.freqKey
    };

    const runs = [
      () => detectFlow(ctx),
      () => detectMap(ctx),
      () => detectCorrelation(ctx),
      () => detectGroupDiff(ctx),
      () => detectTrend(ctx),
      () => detectSeasonal(ctx),
      () => detectAssociation(ctx),
      () => detectDistribution(ctx),
      () => detectComposition(ctx)
    ];
    let all = [];
    runs.forEach((fn) => {
      try { all = all.concat(fn() || []); } catch (e) { if (typeof console !== "undefined") console.warn("insight detector failed", e); }
    });
    const bestCorr = all.slice().sort((x, y) => y.score - x.score).find((c) => c.kind === "correlation") || null;
    try { all = all.concat(detectBubble(ctx, bestCorr) || []); } catch (e) { /* 忽略 */ }
    try { all = all.concat(detectPanel(all.filter((c) => c.kind === "groupdiff")) || []); } catch (e) { /* 忽略 */ }
    try { all = all.concat(detectDensity(bestCorr) || []); } catch (e) { /* 忽略 */ }

    all = all.filter((c) => c && c.spec && c.score >= 0.11);
    all.sort((a, b) => b.score - a.score);
    const usedQuota = {}, used = new Map(), seen = new Set();
    const cards = [];
    const sigOf = (c) => c.kind + "|" + Object.keys(c.spec.zones).filter((k) => c.spec.zones[k].length).map((k) => k + ":" + c.spec.zones[k].join(",")).sort().join("&");
    all.forEach((c) => {
      if (cards.length >= MAX_CARDS) return;
      if ((usedQuota[c.kind] || 0) >= (QUOTA[c.kind] == null ? 2 : QUOTA[c.kind])) return;
      const sig = sigOf(c);
      if (seen.has(sig)) return;
      const cap = cards.length < 4 ? 4 : 3;                       // 前 4 張允许變數重複多一點
      if (c.vars.length && c.vars.every((v) => (used.get(v) || 0) >= cap)) return;
      seen.add(sig);
      usedQuota[c.kind] = (usedQuota[c.kind] || 0) + 1;
      c.vars.forEach((v) => used.set(v, (used.get(v) || 0) + 1));
      cards.push(c);
    });
    all.forEach((c) => { c.picked = cards.indexOf(c) >= 0; });
    out.all = all;
    out.cards = cards;
    out.strongest = all.filter((c) => c.score >= 0.45).length;
    out.ms = Date.now() - t0;
    (ctx.notes || []).forEach((n) => { if (out.notes.indexOf(n) < 0) out.notes.push(n); });
    if (!cards.length && !out.notes.length) {
      out.notes.push("沒找到達統計顯著水準的組合（可能是資料太少、變數太少，或各變數本來就無關）。");
    }
    return out;
  }

  global.GBInsight = {
    analyze, KINDS, QUOTA,
    util: { pearson, spearman, groupAnova, chiSquare, welchT, trendFit, acfPeaks, fmtP, fnum, fpct, chi2sf, tTwoSided, fSf }
  };
})(typeof window !== "undefined" ? window : globalThis);
