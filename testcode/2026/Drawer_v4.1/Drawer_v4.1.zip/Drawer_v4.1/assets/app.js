/* Graph Builder — 互動介面（拖放變數、圖元切換、選項、排除、匯出、JSL 腳本） */
(function (global) {
  "use strict";

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  const ZONES = [
    { id: "X", label: "X 軸", hint: "可放多個變數＝由左而右的分欄；順序可拖拉調整", primary: "zone-x" },
    { id: "Y", label: "Y 軸", hint: "可放多個變數＝由上而下的分頁；順序可拖拉調整", primary: "zone-y" },
    { id: "Group X", label: "群組 X", hint: "分開成多張圖（橫向）" },
    { id: "Group Y", label: "群組 Y", hint: "分開成多張圖（縱向）" },
    { id: "Wrap", label: "Wrap", hint: "以變數值分面（trellis）" },
    { id: "Color", label: "Color", hint: "依值上色並產生圖例" },
    { id: "Overlay", label: "Overlay", hint: "叠加不同變數" },
    { id: "Freq", label: "Freq", hint: "次數/權重欄" },
    { id: "Size", label: "Size", hint: "依值縮放點的大小" },
    { id: "Shape", label: "Shape", hint: "形狀/地圖用途欄位" }
  ];

  const ELEMENT_ICONS = {
    points: '<g><circle cx="7" cy="17" r="2.3"/><circle cx="13" cy="11" r="2.3"/><circle cx="19" cy="14" r="2.3"/><circle cx="24" cy="7" r="2.3"/></g>',
    line: '<g><polyline points="5,20 11,13 17,16 25,6" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="11" cy="13" r="1.6"/><circle cx="17" cy="16" r="1.6"/></g>',
    smoother: '<g><path d="M4,20 C9,20 9,8 14,8 S20,18 26,6" fill="none" stroke="currentColor" stroke-width="1.9"/></g>',
    box: '<g><line x1="9" y1="4" x2="9" y2="8"/><rect x="5.5" y="8" width="7" height="9" fill="none" stroke="currentColor" stroke-width="1.5"/><line x1="5.5" y1="12.5" x2="12.5" y2="12.5" stroke="currentColor" stroke-width="1.9"/><line x1="9" y1="17" x2="9" y2="21"/><line x1="20" y1="6" x2="20" y2="20" stroke="currentColor" stroke-width="1.4"/><circle cx="20" cy="4" r="1.4" fill="none" stroke="currentColor"/></g>',
    bar: '<g><rect x="4" y="13" width="5" height="8"/><rect x="11.5" y="7" width="5" height="14"/><rect x="19" y="16" width="5" height="5"/></g>',
    histogram: '<g><rect x="3" y="17" width="4.6" height="4"/><rect x="8" y="11" width="4.6" height="10"/><rect x="13" y="6" width="4.6" height="15"/><rect x="18" y="13" width="4.6" height="8"/><rect x="23" y="18" width="4.6" height="3"/></g>',
    heatmap: '<g><rect x="3" y="4" width="6" height="6"/><rect x="10" y="4" width="6" height="6" opacity=".5"/><rect x="17" y="4" width="6" height="6" opacity=".8"/><rect x="3" y="11" width="6" height="6" opacity=".35"/><rect x="10" y="11" width="6" height="6" opacity=".9"/><rect x="17" y="11" width="6" height="6" opacity=".45"/><rect x="3" y="18" width="6" height="6" opacity=".7"/><rect x="10" y="18" width="6" height="6" opacity=".3"/><rect x="17" y="18" width="6" height="6" opacity=".6"/></g>',
    contour: '<g><path d="M14,4 C20,6 22,12 18,17 C15,21 8,20 7,15 C6,10 10,6 14,4 Z" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M13,8 C17,9 18,13 15,16 C12,18 9,16 9,13 C9,10 11,8 13,8 Z" fill="none" stroke="currentColor" stroke-width="1.3"/></g>',
    time: '<g><path d="M3,18 L8,12 L11,15 L16,7 L20,10 L26,4" fill="none" stroke="currentColor" stroke-width="1.7"/><line x1="3" y1="22" x2="26" y2="22" stroke="currentColor" stroke-width="1"/></g>',
    map: '<g><circle cx="14.5" cy="13" r="9.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M5,13 H24 M14.5,3.5 V22.5 M7.5,7.5 C11,10 18,10 21.5,7.5 M7.5,18.5 C11,16 18,16 21.5,18.5" fill="none" stroke="currentColor" stroke-width="1"/></g>',
    mosaic: '<g><rect x="3" y="4" width="10" height="9"/><rect x="14" y="4" width="10" height="5" opacity=".6"/><rect x="14" y="10" width="10" height="3" opacity=".35"/><rect x="3" y="14" width="10" height="7" opacity=".45"/><rect x="14" y="14" width="10" height="7" opacity=".8"/></g>',
    pie: '<g><circle cx="14" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M14,12 L14,3 A9,9 0 0,1 22.2,8.4 Z"/><path d="M14,12 L14,3 A9,9 0 0,0 5.8,8.4 Z" opacity=".45"/></g>',
    sankey: '<g><rect x="3" y="4" width="3" height="7"/><rect x="3" y="13" width="3" height="7"/><rect x="22" y="4" width="3" height="6"/><rect x="22" y="11" width="3" height="4"/><rect x="22" y="16" width="3" height="4"/><path d="M6,7 C13,7 13,7 22,7 M6,16 C13,16 13,13 22,13 M6.5,10 C13,10 13,18 22,18" fill="none" stroke="currentColor" stroke-width="1.1" opacity=".85"/></g>'
  };

  // 快速開始：一次設定放置區 + 圖元（照 JMP 常見用法）
  const PRESETS = [
    { id: "scatter", label: "散點 + 平滑器", sample: "Big Class",
      zones: { X: ["Height"], Y: ["Weight"], Color: ["Sex"] }, elements: { points: { on: true }, smoother: { on: true } } },
    { id: "box", label: "箱形圖比較群組", sample: "Big Class",
      zones: { X: ["Age"], Y: ["Weight"], Color: ["Sex"] }, elements: { box: { on: true } } },
    { id: "bar", label: "群組平均長條", sample: "Big Class",
      zones: { X: ["Sex"], Y: ["Weight"], Color: ["Age"] }, elements: { bar: { on: true, stack: "side", ci: true } } },
    { id: "hist", label: "分布直方圖", sample: "Big Class",
      zones: { X: ["Height"], Color: ["Sex"] }, elements: { histogram: { on: true, density: true } } },
    { id: "mosaic", label: "馬賽克：類別 × 類別", sample: "Big Class",
      zones: { X: ["Sex"], Y: ["Age"] }, elements: { mosaic: { on: true } } },
    { id: "heat", label: "二維熱圖", sample: "Big Class",
      zones: { X: ["Height"], Y: ["Weight"] }, elements: { heatmap: { on: true } } },
    { id: "time", label: "時間序列", sample: "Weather (時間序列)",
      zones: { X: ["Date"], Y: ["Temp"], Color: ["City"] }, elements: { time: { on: true, rolling: 3 } } },
    { id: "map", label: "城市地圖", sample: "World Cities (地圖)",
      zones: { Color: ["Continent"], Size: ["Pop"] }, elements: { map: { on: true } } },
    { id: "multiY", label: "多個 Y（上下分頁）", sample: "汽車規格（多變數軸）",
      zones: { X: ["Country"], Y: ["Turning Circle", "Weight"], Color: ["Type"] },
      elements: { box: { on: true, alpha: 1 }, points: { on: true, alpha: 0.55 }, line: { on: true, alpha: 1 } } },
    { id: "multiX", label: "多個 X（左右分欄）", sample: "汽車規格（多變數軸）",
      zones: { X: ["Country", "Type"], Y: ["Horsepower"], Color: ["Type"] },
      elements: { bar: { on: true, alpha: 1 }, points: { on: true, alpha: 0.5 } } },
    { id: "sankey", label: "能源流向桑基圖", sample: "能源流向（桑基圖）",
      zones: { X: ["From"], Y: ["To"], Freq: ["Value"] }, elements: { sankey: { on: true, values: true, gap: 10 } } }
  ];

  const TYPE_BADGE = { continuous: { t: "連續", c: "cont" }, ordinal: { t: "序號", c: "ord" }, nominal: { t: "名義", c: "nom" } };

  const state = {
    ds: null,
    zones: {},           // zoneId -> [keys]
    elements: {},        // elId -> {on, alpha, ...opts}
    order: GBElements.order.slice(),   // 繪製順序：第 0 個在最下層
    grouping: "side",
    legend: true,
    exportBg: "transparent",
    height: 420,
    freq: null,
    title: "",
    activePreset: null,
    hiddenGroups: new Set(),
    lastRender: null
  };

  // ---------------- 初始化 ----------------
  function init() {
    ZONES.forEach((z) => (state.zones[z.id] = []));
    buildZoneUI();
    buildElementBar();
    bindToolbar();
    bindDropAnywhere();
    loadSample("Big Class");
    if (global.GBSelect) GBSelect.onChange(syncSelUI);
    window.addEventListener("resize", debounce(() => render(), 250));
    document.addEventListener("keydown", (ev) => {
      if (ev.key === "Escape") {
        closeMenu();
        if (!document.querySelector(".modal-mask")) selClear();   // 沒有對話框開著時：Esc ＝清除框選
        closeModal();
      }
    });
  }

  function buildZoneUI() {
    const prim = $(".zones-primary"), sec = $(".zones-secondary");
    prim.innerHTML = ""; sec.innerHTML = "";
    // JMP 習慣：Y 在上、X 在下
    ["Y", "X"].forEach((id) => {
      const z = ZONES.find((x) => x.id === id);
      const cell = document.createElement("div");
      cell.className = "zone zone-axis " + z.primary;
      cell.dataset.zone = z.id;
      cell.title = z.hint;
      cell.innerHTML = `<span class="axis-badge">${z.id}</span><span class="zone-label">${z.label}</span><span class="zone-chips"></span>`;
      wireZone(cell);
      prim.appendChild(cell);
    });
    ZONES.filter((z) => !z.primary).forEach((z) => {
      const cell = document.createElement("div");
      cell.className = "zone";
      cell.dataset.zone = z.id;
      cell.title = z.hint;
      cell.innerHTML = `<span class="zone-label">${z.label}</span><span class="zone-chips"></span>`;
      wireZone(cell);
      sec.appendChild(cell);
    });
    renderZones();
  }

  function wireZone(cell) {
    cell.addEventListener("dragover", onZoneDragOver);
    cell.addEventListener("dragleave", () => cell.classList.remove("over"));
    cell.addEventListener("drop", onZoneDrop);
    cell.addEventListener("click", (ev) => {
      if (ev.target.classList.contains("chip-x")) return;
      openVariablePicker(cell.dataset.zone, ev);
    });
  }

  // ---------- 圖層面板：堆疊順序（由下而上繪製）與每層透明度 ----------
  function enabledEls() {
    return state.order.filter((k) => (state.elements[k] || {}).on);
  }

  function renderLayers() {
    const holder = $("#layers");
    if (!holder) return;
    const list = enabledEls();
    $("#layers-empty").classList.toggle("hidden", list.length > 0);
    holder.innerHTML = "";
    // 由上往下顯示＝最上層在上面（反轉繪製順序）
    list.slice().reverse().forEach((id) => {
      const st = state.elements[id];
      const row = document.createElement("div");
      row.className = "layer";
      row.draggable = true;
      row.dataset.el = id;
      const depth = list.indexOf(id) + 1;
      row.innerHTML =
        `<span class="layer-grip" title="拖曳改變堆疊順序">⋮⋮</span>` +
        `<button class="layer-eye" title="${st.on ? "隱藏此圖元" : "顯示此圖元"}">${st.on ? "👁" : "— "}</button>` +
        `<span class="layer-name">${GBElements.defs[id].label}</span>` +
        `<span class="layer-depth" title="繪製順序（1 = 最下層）">${depth}</span>` +
        `<span class="layer-move"><button data-act="up" title="往上移一層">▲</button><button data-act="down" title="往下移一層">▼</button></span>` +
        `<label class="layer-alpha" title="這個圖元的透明度"><input type="range" min="0.1" max="1" step="0.05" value="${st.alpha == null ? 1 : st.alpha}"><output>${st.alpha == null ? 1 : st.alpha}</output></label>`;
      $(".layer-name", row).addEventListener("click", () => openOptions(id));
      $(".layer-eye", row).addEventListener("click", () => toggleElement(id));
      $$('[data-act]', row).forEach((b) => b.addEventListener("click", () => moveLayer(id, b.dataset.act === "up" ? 1 : -1)));
      const rng = $("input[type=range]", row);
      rng.addEventListener("input", (ev) => {
        st.alpha = +ev.target.value;
        $("output", row).textContent = ev.target.value;
        renderLive();
      });
      row.addEventListener("dragstart", (ev) => { ev.dataTransfer.setData("text/layer", id); ev.dataTransfer.effectAllowed = "move"; });
      row.addEventListener("dragover", (ev) => { ev.preventDefault(); row.classList.add("over"); });
      row.addEventListener("dragleave", () => row.classList.remove("over"));
      row.addEventListener("drop", (ev) => {
        ev.preventDefault(); ev.stopPropagation(); row.classList.remove("over");
        const src = ev.dataTransfer.getData("text/layer");
        if (src && src !== id) reorderLayerTo(src, id);
      });
      holder.appendChild(row);
    });
  }
  function moveLayer(id, dir) {
    // 只在「已開啟的圖元」之間移動，否則會被沒啟用、夾在中間的圖元吃掉一步
    const list = enabledEls();
    const i = list.indexOf(id);
    const j = i + dir;                       // dir=+1 → 往前（畫在最上面）
    if (i < 0 || j < 0 || j >= list.length) return;
    const other = list[j];
    state.order.splice(state.order.indexOf(id), 1);
    const k = state.order.indexOf(other);
    state.order.splice(dir > 0 ? k + 1 : k, 0, id);
    render();
  }
  function reorderLayerTo(srcId, targetId) {
    const i = state.order.indexOf(srcId);
    if (i < 0) return;
    state.order.splice(i, 1);
    const j = state.order.indexOf(targetId);
    state.order.splice(j + 1, 0, srcId);      // 放到目標的上面
    render();
  }
  function bringToFront(id) {
    const i = state.order.indexOf(id);
    if (i >= 0) { state.order.splice(i, 1); state.order.push(id); }
  }

  function renderZones() {
    if (!state.ds) return;
    const colMap = new Map(state.ds.columns.map((c) => [c.key, c]));
    for (const z of ZONES) {
      const cell = $(`.zone[data-zone="${z.id}"]`);
      if (!cell) continue;
      const holder = $(".zone-chips", cell);
      holder.innerHTML = "";
      const keys = state.zones[z.id];
      if (!keys.length) {
        const ph = document.createElement("span");
        ph.className = "zone-hint";
        ph.textContent = z.id === "Y" ? "拖變數進來（可放多個＝由上而下）" : z.id === "X" ? "拖變數進來（可放多個＝由左而右）" : (z.primary ? "把變數拖進來" : "");
        holder.appendChild(ph);
      }
      keys.forEach((key, idx) => {
        const col = colMap.get(key);
        const chip = document.createElement("span");
        chip.className = "chip " + (col ? TYPE_BADGE[col.type].c : "");
        chip.draggable = true;
        const ordinal = z.primary && keys.length > 1
          ? `<i class="chip-idx" title="面板順序：第 ${idx + 1} 個">${idx + 1}</i>` : "";
        chip.innerHTML = `${ordinal}<span class="chip-key">${escapeHtml(shortName(key))}</span><button class="chip-x" title="移除">×</button>`;
        chip.addEventListener("dragstart", (ev) => {
          ev.dataTransfer.setData("text/plain", JSON.stringify({ key, from: z.id, idx }));
          ev.dataTransfer.effectAllowed = "move";
        });
        $(".chip-x", chip).addEventListener("click", (ev) => {
          ev.stopPropagation();
          state.zones[z.id].splice(idx, 1);
          afterChange();
        });
        chip.addEventListener("contextmenu", (ev) => {
          ev.preventDefault();
          openZoneChipMenu(ev, z.id, idx, key);
        });
        holder.appendChild(chip);
      });
    }
    renderVariableList();
  }

  function shortName(k) { return k.length > 14 ? k.slice(0, 13) + "…" : k; }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  function onZoneDragOver(ev) {
    ev.preventDefault();
    ev.currentTarget.classList.add("over");
    ev.dataTransfer.dropEffect = "move";
  }

  function onZoneDrop(ev) {
    ev.preventDefault();
    const cell = ev.currentTarget;
    cell.classList.remove("over");
    const zoneId = cell.dataset.zone;
    let payload;
    const raw = ev.dataTransfer.getData("text/plain");
    if (!raw) return;
    try { payload = JSON.parse(raw); } catch (e) { return; }
    const key = payload.key;
    if (!key) return;
    const sameZone = payload.from === zoneId;
    if (payload.from) {
      const from = state.zones[payload.from];
      const i = from.indexOf(key);
      if (i >= 0) from.splice(i, 1);
    }
    const arr = state.zones[zoneId];
    // 拖到 X/Y 的色塊徽章上＝取代該軸（JMP 把變數拖到軸標籤的行為）
    const onBadge = ev.target && ev.target.closest && ev.target.closest(".axis-badge");
    if (onBadge && !sameZone) { arr.splice(0, arr.length, key); afterChange(); return; }
    // 其餘情況：依滑鼠位置插入（同一區內拖＝重新排列，順序＝面板由左而右／由上而下）
    arr.splice(insertIndex(cell, ev.clientX, ev.clientY, arr.length), 0, key);
    afterChange();
  }

  // 依滑鼠停在第幾個 chip 的左/右半邊，決定插入位置
  function insertIndex(cell, x, y, len) {
    const chips = Array.from(cell.querySelectorAll(".zone-chips > .chip"));
    if (!chips.length) return len;
    for (let i = 0; i < chips.length; i++) {
      const r = chips[i].getBoundingClientRect();
      if (y < r.bottom + 4 && (y > r.top - 4 ? x < r.left + r.width / 2 : y < r.top)) return i;
    }
    return len;
  }

  function bindDropAnywhere() {
    document.addEventListener("dragover", (ev) => { if (ev.dataTransfer.types.includes("Files")) ev.preventDefault(); });
    document.addEventListener("drop", (ev) => {
      if (!ev.dataTransfer.files || !ev.dataTransfer.files.length) return;
      ev.preventDefault();
      Array.from(ev.dataTransfer.files).forEach(loadFile);
    });
  }

  // ---------------- 變數清單 ----------------
  function renderVariableList() {
    const list = $("#variables");
    list.innerHTML = "";
    const used = new Set(Object.values(state.zones).flat());
    state.ds.columns.forEach((col) => {
      const item = document.createElement("div");
      item.className = "var" + (used.has(col.key) ? " used" : "");
      item.dataset.key = col.key;
      item.draggable = true;
      const badge = TYPE_BADGE[col.type];
      item.innerHTML = `<span class="var-type ${badge.c}" title="建模類型">${badge.t}</span><span class="var-name">${escapeHtml(col.key)}</span><span class="var-n">${col.distinct} 值${col.missing ? " · 缺 " + col.missing : ""}</span>`;
      item.addEventListener("dragstart", (ev) => {
        ev.dataTransfer.setData("text/plain", JSON.stringify({ key: col.key, from: null }));
        ev.dataTransfer.effectAllowed = "copyMove";
      });
      item.addEventListener("dblclick", () => autoAssign(col.key));
      item.addEventListener("contextmenu", (ev) => { ev.preventDefault(); openVarMenu(ev, col.key); });
      list.appendChild(item);
    });
    $("#ds-name").textContent = state.ds.name + "（" + state.ds.rows.length + " 列 × " + state.ds.columns.length + " 欄）";
  }

  function autoAssign(key) {
    const col = state.ds.columns.find((c) => c.key === key);
    if (!col) return;
    const target = col.role === "measure" ? "Y" : col.role === "category" || col.role === "ordinal" ? "X" : col.role === "time" ? "X" : "Color";
    const arr = state.zones[target];
    if (!arr.includes(key)) arr.push(key);
    afterChange();
  }

  // ---------------- 圖元列 ----------------
  function buildElementBar() {
    const bar = $("#elements");
    bar.innerHTML = "";
    GBElements.order.forEach((id) => {
      const def = GBElements.defs[id];
      const b = document.createElement("button");
      b.className = "el";
      b.dataset.el = id;
      b.title = def.label + "（" + def.short + "）— 左鍵切換，右鍵開選項";
      b.innerHTML = `<svg viewBox="0 0 28 24" aria-hidden="true">${ELEMENT_ICONS[id]}</svg><span>${def.label}</span><i class="el-badge hidden"></i>`;
      b.addEventListener("click", () => { toggleElement(id); });
      b.addEventListener("contextmenu", (ev) => { ev.preventDefault(); toggleElement(id, true); openOptions(id); });
      bar.appendChild(b);
    });
    syncElementBar();
  }

  function toggleElement(id, forceOn) {
    const st = state.elements[id] || (state.elements[id] = { on: false });
    if (st.alpha === undefined) st.alpha = 1;
    const wasOn = st.on;
    if (forceOn && !st.on) { st.on = true; }
    else if (!forceOn) st.on = !st.on;
    if (!wasOn && st.on) { bringToFront(id); if (state.activePreset) markPreset(null); }   // 剛開啟的圖元預設畫在最上層
    if (st.on) openOptions(id); else closeOptionsIf(id);
    afterChange();
  }

  function syncElementBar() {
    const list = enabledEls();
    $$("#elements .el").forEach((b) => {
      const on = !!(state.elements[b.dataset.el] || {}).on;
      b.classList.toggle("on", on);
      const badge = $(".el-badge", b);
      if (badge) {
        const depth = list.indexOf(b.dataset.el) + 1;
        badge.textContent = depth;
        badge.classList.toggle("hidden", !on || list.length < 2);
        badge.title = on ? `堆疊順序：第 ${depth} 層（共 ${list.length} 層，數字大＝畫在前面）` : "";
      }
    });
  }

  function suggestElements() {
    const c = cfgPreview();
    const on = {};
    const els = Object.keys(state.elements).filter((k) => state.elements[k].on);
    // 依 JMP 直覺：點為預設；雙連續加平滑器；類別 X 加長條；單連續加直方圖
    if (!els.length) {
      if (c.mapMode) on.map = true;
      else if (c.x && c.y && c.xD && c.yD) { on.mosaic = true; on.bar = false; }
      else if (c.x && c.y && !c.xD && !c.yD) { on.points = true; on.smoother = true; }
      else if (c.x && c.y && c.xD) { on.bar = true; on.box = true; on.points = true; }
      else if (c.x && c.y && c.yD) { on.box = true; on.points = true; }
      else if (c.x && !c.xD) { on.histogram = true; }
      else if (c.x && c.xD && !c.y) { on.pie = true; }
      else if (c.y && !c.yD) { on.histogram = true; }
      else if (c.x || c.y) { on.histogram = !!(c.x && !c.xD) || !!(c.y && !c.yD); if (!on.histogram) on.bar = true; }
      else if (c.time) on.time = true;
    }
    Object.keys(on).forEach((k) => {
      state.elements[k] = state.elements[k] || { on: false };
      state.elements[k].on = !!on[k];
    });
    syncElementBar();
  }

  function cfgPreview() {
    const colMap = new Map(state.ds.columns.map((c) => [c.key, c]));
    const g = (z) => (state.zones[z][0] ? colMap.get(state.zones[z][0]) : null);
    const x = g("X"), y = g("Y");
    const timeCol = state.ds.columns.find((c) => c.role === "time");
    const lat = state.ds.columns.find((c) => c.role === "lat");
    const lon = state.ds.columns.find((c) => c.role === "lon");
    return {
      x, y,
      xD: x ? x.type !== "continuous" : false,
      yD: y ? y.type !== "continuous" : false,
      time: timeCol,
      mapMode: !!(lat && lon && (state.elements.map || {}).on)
    };
  }

  // ---------------- 選項面板 ----------------
  const OPTION_SCHEMA = {
    points: [["size", "點大小", "range", 1, 12, 1], ["opacity", "不透明度", "range", 0.1, 1, 0.05], ["jitter", "抖動", "range", 0, 1, 0.1]],
    line: [["statistic", "彙統統計", "stat"], ["ci", "顯示信賴區間", "bool"], ["ciLevel", "信賴區間 %", "range", 50, 99.9, 0.5], ["connect", "連接方式", "enum", { linear: "直線", step: "階梯", smooth: "平滑" }], ["width", "線寬", "range", 0.5, 5, 0.1], ["showPoints", "顯示資料點", "bool"]],
    smoother: [["method", "方法", "enum", { loess: "LOESS（JMP 預設）", spline: "平滑樣條", linear: "線性擬合" }], ["lambda", "λ 平滑參數", "range", 0.01, 0.2, 0.005], ["band", "顯示信賴帶", "bool"], ["ciLevel", "信賴區間 %", "range", 50, 99.9, 0.5], ["width", "線寬", "range", 1, 5, 0.1], ["showEquation", "顯示擬合式", "bool"]],
    box: [["whisker", "鬚長", "enum", { "1.5": "1.5×IQR（預設）", "3": "3×IQR", minmax: "最小/最大值" }], ["outliers", "顯示離群點", "bool"], ["showMean", "顯示平均數菱形", "bool"], ["ciMean", "平均數 CI %", "range", 0, 99.9, 0.5], ["fillOpacity", "箱體透明度", "range", 0, 1, 0.05]],
    bar: [["statistic", "彙統統計", "stat"], ["ci", "平均數 95% CI 誤差棒", "bool"], ["ciLevel", "信賴區間 %", "range", 50, 99.9, 0.5], ["stack", "分組方式", "enum", { side: "並排", stack: "堆疊" }], ["label", "顯示數值標籤", "bool"], ["fillOpacity", "填滿透明度", "range", 0.1, 1, 0.05]],
    histogram: [["binRule", "分箱規則", "enum", { sturges: "Sturges", fd: "Freedman–Diaconis", sqrt: "平方根", manual: "自訂" }], ["bins", "自訂分箱數（0=自動）", "range", 0, 60, 1], ["density", "顯示密度曲線", "bool"], ["densityBandwidth", "密度頻寬倍數", "range", 0.4, 3, 0.1], ["stack", "多群組", "enum", { overlay: "疊加顯示", stack: "堆疊" }], ["fillOpacity", "填滿透明度", "range", 0.1, 1, 0.05]],
    heatmap: [["statistic", "儲存格統計", "statn"], ["colorMap", "配色", "enum", { YlOrRd: "黃→紅", Viridis: "Viridis", Blues: "藍階", Turbo: "Turbo", RdYlGn: "紅黃綠" }], ["showValues", "顯示數值", "bool"], ["nx", "X 分箱數（連續時）", "range", 4, 60, 1], ["ny", "Y 分箱數（連續時）", "range", 4, 60, 1]],
    contour: [["levels", "等高線層數", "range", 3, 14, 1], ["fill", "填色", "bool"], ["fillOpacity", "填色透明度", "range", 0, 1, 0.05], ["bandwidth", "核頻寬倍數", "range", 0.3, 3, 0.1], ["showPoints", "顯示資料點", "bool"], ["grid", "解析度", "range", 20, 90, 2]],
    time: [["width", "線寬", "range", 0.5, 5, 0.1], ["rolling", "移動平均期數（0=關）", "range", 0, 24, 1], ["bandRange", "顯示期間範圍帶", "bool"], ["showPoints", "顯示資料點", "bool"]],
    map: [["size", "點大小", "range", 2, 16, 0.5], ["maxSize", "依 Size 欄的最大半徑", "range", 6, 40, 1]],
    mosaic: [["bins", "連續變數的分帶數", "range", 2, 10, 1], ["labels", "顯示佔比標籤", "bool"]],
    pie: [["statistic", "切片數值", "pie"], ["hole", "中間挖空（0=圓餅、0.6=甜甜圈）", "range", 0, 0.85, 0.05], ["sort", "排序", "enum", { desc: "由大到小", asc: "由小到大", none: "依類別順序" }], ["labels", "顯示標籤與百分比", "bool"], ["decimals", "小數位數", "range", 0, 3, 1]],
    sankey: [["colorMode", "節點配色", "enum", { node: "每個節點不同色（預設）", layer: "同層同色" }], ["gradient", "色帶用來源→目標漸層", "bool"], ["opacity", "流量透明度", "range", 0.08, 0.9, 0.02], ["nodeWidth", "節點寬度", "range", 6, 40, 1], ["gap", "節點間距", "range", 2, 40, 1], ["curvature", "曲線彎度", "range", 0.1, 0.9, 0.05], ["labels", "顯示節點名稱", "bool"], ["values", "顯示流量數值", "bool"]]
  };

  function openOptions(id) {
    const st = state.elements[id];
    if (!st) return;
    st.on = true;
    $("#opt-title").textContent = GBElements.defs[id].label + " 選項";
    const holder = $("#opt-fields");
    holder.innerHTML = "";
    const def = GBElements.defs[id].defaults;
    const rows = OPTION_SCHEMA[id] || [];
    for (const [key, label, kind, a, b, step] of rows) {
      const value = st[key] === undefined ? def[key] : st[key];
      const row = document.createElement("label");
      row.className = "opt";
      if (kind === "bool") {
        row.innerHTML = `<span>${label}</span><input type="checkbox" ${value ? "checked" : ""}>`;
        $("input", row).addEventListener("change", (ev) => { st[key] = ev.target.checked; render(); });
      } else if (kind === "range") {
        row.innerHTML = `<span>${label}</span><span class="opt-val">${value}</span><input type="range" min="${a}" max="${b}" step="${step}" value="${value}">`;
        $("input", row).addEventListener("input", (ev) => {
          st[key] = +ev.target.value;
          $(".opt-val", row).textContent = ev.target.value;
          renderLive();
        });
      } else if (kind === "enum") {
        row.innerHTML = `<span>${label}</span><select>${Object.entries(a).map(([k, t]) => `<option value="${k}" ${String(value) === k ? "selected" : ""}>${t}</option>`).join("")}</select>`;
        $("select", row).addEventListener("change", (ev) => { st[key] = ev.target.value; render(); });
      } else if (kind === "pie") {
        row.innerHTML = `<span>${label}</span><select>${Object.entries({ share: "總和（預設，即佔比）", count: "次數", mean: "平均數", median: "中位數", sum: "總和", max: "最大值" }).map(([k, t]) => `<option value="${k}" ${String(value || "share") === k ? "selected" : ""}>${t}</option>`).join("")}</select>`;
        $("select", row).addEventListener("change", (ev) => { st[key] = ev.target.value; render(); });
      } else if (kind === "stat" || kind === "statn") {
        const names = kind === "statn" ? Object.assign({ n: "次數" }, GBElements.STAT_NAMES) : GBElements.STAT_NAMES;
        row.innerHTML = `<span>${label}</span><select>${Object.entries(names).map(([k, t]) => `<option value="${k}" ${String(value || "mean") === k ? "selected" : ""}>${t}</option>`).join("")}</select>`;
        $("select", row).addEventListener("change", (ev) => { st[key] = ev.target.value; render(); });
      }
      holder.appendChild(row);
    }
    $("#options").classList.remove("hidden");
    $$("#elements .el").forEach((b) => b.classList.toggle("active", b.dataset.el === id));
  }
  function closeOptionsIf(id) {
    if ($("#opt-title").textContent.startsWith(GBElements.defs[id].label)) $("#options").classList.add("hidden");
  }

  // ---------------- 右鍵選單 ----------------
  let menuEl = null;
  function openMenu(ev, items) {
    closeMenu();
    menuEl = document.createElement("div");
    menuEl.className = "menu";
    for (const it of items) {
      if (it === "-") { const hr = document.createElement("div"); hr.className = "menu-sep"; menuEl.appendChild(hr); continue; }
      if (it.disabled) {                                     // 灰字提示（不可點）
        const d = document.createElement("div");
        d.className = "menu-hint"; d.textContent = it.label;
        menuEl.appendChild(d); continue;
      }
      const b = document.createElement("button");
      b.innerHTML = (it.check ? "✓ " : "&nbsp;&nbsp;") + escapeHtml(it.label);
      b.addEventListener("click", () => { closeMenu(); it.action && it.action(); });
      menuEl.appendChild(b);
    }
    document.body.appendChild(menuEl);
    const w = menuEl.offsetWidth, h = menuEl.offsetHeight;
    menuEl.style.left = Math.min(window.innerWidth - w - 6, ev.clientX) + "px";
    menuEl.style.top = Math.min(window.innerHeight - h - 6, ev.clientY) + "px";
    setTimeout(() => document.addEventListener("click", closeMenu, { once: true }), 0);
  }
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }

  function openVarMenu(ev, key) {
    const col = state.ds.columns.find((c) => c.key === key);
    const items = [
      { label: `設為 X 軸`, action: () => push("X", key) },
      { label: `設為 Y 軸`, action: () => push("Y", key) },
      { label: "設為 Color", action: () => push("Color", key) },
      { label: "設為 Wrap（分面）", action: () => push("Wrap", key) },
      { label: "設為 Freq（次數欄）", action: () => push("Freq", key) },
      { label: "設為 Size", action: () => push("Size", key) },
      "-",
      { label: "改為連續建模", check: col.type === "continuous", action: () => setType(key, "continuous") },
      { label: "改為序號建模", check: col.type === "ordinal", action: () => setType(key, "ordinal") },
      { label: "改為名義建模", check: col.type === "nominal", action: () => setType(key, "nominal") },
      { label: "視為日期時間", check: col.hasDate, action: () => setDateLike(key) },
      "-",
      { label: "清除所有區塊中的此變數", action: () => { Object.values(state.zones).forEach((a) => { const i = a.indexOf(key); if (i >= 0) a.splice(i, 1); }); afterChange(); } }
    ];
    openMenu(ev, items);
  }

  function openZoneChipMenu(ev, zoneId, idx, key) {
    openMenu(ev, [
      { label: "移出 " + zoneId, action: () => { state.zones[zoneId].splice(idx, 1); afterChange(); } },
      { label: "設為 Y 軸", action: () => { moveKey(zoneId, idx, "Y"); } },
      { label: "設為 X 軸", action: () => { moveKey(zoneId, idx, "X"); } },
      { label: "設為 Color", action: () => { moveKey(zoneId, idx, "Color"); } },
      "-",
      { label: "清空 " + zoneId, action: () => { state.zones[zoneId] = []; afterChange(); } }
    ]);
  }

  function moveKey(from, idx, to) {
    const key = state.zones[from][idx];
    state.zones[from].splice(idx, 1);
    push(to, key);
  }
  function push(zone, key) {
    const arr = state.zones[zone];
    if (!arr.includes(key)) arr.push(key);
    afterChange();
  }
  function setType(key, type) {
    const col = state.ds.columns.find((c) => c.key === key);
    if (!col) return;
    col.type = type;
    if (type !== "continuous") col.role = type === "ordinal" ? "ordinal" : "category";
    markInsightsStale("變數建模類型變了");
    afterChange();
  }
  function setDateLike(key) {
    const col = state.ds.columns.find((c) => c.key === key);
    if (!col) return;
    col.values = col.raw.map((v) => (v == null || v === "" ? null : GBData.parseDateValue(v)));
    col.hasDate = true;
    col.type = "continuous";
    col.numFmt = "date";
    col.role = "time";
    markInsightsStale("變數建模類型變了");
    afterChange();
  }

  function openVariablePicker(zoneId, ev) {
    const items = state.ds.columns.map((c) => ({
      label: `${c.key}（${TYPE_BADGE[c.type].t}）`,
      check: state.zones[zoneId].includes(c.key),
      action: () => push(zoneId, c.key)
    }));
    if (!items.length) items.push({ label: "（沒有變數）", action: null });
    openMenu({ clientX: ev.clientX, clientY: ev.clientY }, items.slice(0, 40));
  }

  // ---------------- 資料 ----------------
  function loadSample(name) {
    state.ds = GBData.SAMPLES[name]();
    state.hiddenGroups.clear();
    if (global.GBSelect) GBSelect.reset();
    state.zones = Object.fromEntries(ZONES.map((z) => [z.id, []]));
    state.elements = {};
    state.title = "";
    $("#title-input").value = "";
    const keys = GBData.autoKeys(state.ds.columns);
    state.freq = keys.freq[0] || null;

    if (name === "Big Class") {
      state.zones.X = ["Height"]; state.zones.Y = ["Weight"]; state.zones.Color = ["Sex"];
      state.elements = { points: { on: true, alpha: 1 }, smoother: { on: true, alpha: 1 } };
    } else if (name.startsWith("能源流向")) {
      state.zones.X = ["From"]; state.zones.Y = ["To"]; state.zones.Freq = ["Value"];
      state.freq = "Value";
      state.elements = { sankey: { on: true, values: true, gap: 10, alpha: 1 } };
      state.title = "桑基圖：能源流向";
    } else if (name.startsWith("Weather")) {
      state.zones.X = ["Date"]; state.zones.Y = ["Temp"]; state.zones.Color = ["City"];
      state.elements = { time: { on: true, alpha: 1 } };
      state.title = "時間序列：各城市氣溫";
    } else if (name.startsWith("World")) {
      state.zones.Color = ["Continent"]; state.zones.Size = ["Pop"];
      state.elements = { map: { on: true, alpha: 1 } };
      state.title = "世界城市地圖";
    } else {
      suggestElements();
    }
    $("#title-input").value = state.title;
    syncElementBar();
    $("#freq-select").innerHTML = freqOptions();
    $("#freq-select").value = state.freq || "";
    renderZones();
    render();
    updateStatus();
    aiRerunIfOpen();
  }

  function freqOptions() {
    const cont = state.ds.columns.filter((c) => c.type === "continuous");
    return `<option value="">（不使用）</option>` + cont.map((c) => `<option value="${escapeHtml(c.key)}">${escapeHtml(c.key)}</option>`).join("");
  }

  function loadFile(file) {
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result);
      let rows;
      try {
        if (/\.json$/i.test(file.name)) rows = JSON.parse(text);
        else if (/\b|\t/.test(text) && /\.tsv$/i.test(file.name)) rows = GBData.parseTSV(text);
        else rows = GBData.parseCSV(text);
      } catch (e) { alert("檔案解析失敗：" + e.message); return; }
      if (!Array.isArray(rows) || !rows.length) { alert("找不到資料列（需要 CSV/TSV/JSON 的物件陣列）"); return; }
      adoptData(file.name, rows);
    };
    reader.readAsText(file);
  }

  function adoptData(name, rows) {
    state.ds = GBData.buildDataset(name, rows);
    state.hiddenGroups.clear();
    if (global.GBSelect) GBSelect.reset();
    state.zones = Object.fromEntries(ZONES.map((z) => [z.id, []]));
    const keys = GBData.autoKeys(state.ds.columns);
    if (keys.time[0]) state.zones.X = [keys.time[0]];
    else if (keys.cats[0]) state.zones.X = [keys.cats.find((k) => k !== keys.label[0]) || keys.cats[0]];
    if (keys.cont[0]) state.zones.Y = [keys.cont[0]];
    state.zones.Color = keys.cats.filter((k) => k !== state.zones.X[0] && state.ds.columns.find((c) => c.key === k).distinct <= 12).slice(0, 1);
    state.freq = keys.freq[0] || null;
    $("#freq-select").innerHTML = freqOptions();
    $("#freq-select").value = state.freq || "";
    state.elements = {};
    suggestElements();
    syncElementBar();
    renderZones();
    render();
    updateStatus();
    aiRerunIfOpen();
  }

  // ---------------- 繪製 ----------------
  let renderTimer = null;
  let rafId = null;
  function renderSoon() { clearTimeout(renderTimer); renderTimer = setTimeout(() => render(), 120); }
  // 拖動滑桿時：每一動畫格重繪一次（即時反應，也不會因過多重繪而卡頓）
  function renderLive() {
    if (rafId != null) return;
    rafId = requestAnimationFrame(() => { rafId = null; render(); });
  }
  function render() {
    const spec = {
      zones: state.zones,
      elements: Object.fromEntries(Object.entries(state.elements).map(([k, v]) => [k, v])),
      grouping: state.grouping,
      legend: state.legend,
      height: state.height,
      freq: state.freq,
      title: state.title,
      paintOrder: state.order
    };
    renderLayers();
    const el = $("#chart");
    if (!spec.elements || !Object.values(spec.elements).some((v) => v.on)) {
      d3.select(el).selectAll("*").remove();
      d3.select(el).attr("viewBox", "0 0 800 240").attr("width", 800).attr("height", 240);
      d3.select(el).append("text").attr("x", 400).attr("y", 120).attr("text-anchor", "middle")
        .attr("class", "fit-note-text").attr("font-size", 15)
        .text("請從左側把變數拖到 X / Y 區塊，並點上面任一個圖元圖示開始繪圖");
      $("#status").textContent = "尚未選擇圖元";
      return;
    }
    $$("#elements .el").forEach((b) => b.classList.toggle("on", !!(state.elements[b.dataset.el] || {}).on));
    try {
      const out = GBElements.draw(el, state.ds, spec);
      if (out && out.then) out.then((r) => { state.lastRender = r; }).catch((e) => console.warn(e));
    } catch (e) {
      console.error(e);
      $("#status").textContent = "繪圖錯誤：" + e.message;
    }
    updateStatus();
  }
  function rerenderSoon(ms) { (ms ? renderSoon : render)(); }

  // ---------------- 跨圖框選（拖曳框選 → 所有圖連動高亮／未選到的變淡） ----------------
  const SEL = () => global.GBSelect || null;
  function selOn() { const S = SEL(); return !!(S && S.isOn()); }
  function syncSelUI() {
    const S = SEL(), chip = $("#sel-chip");
    if (!S || !chip) return;
    const n = S.count();
    chip.classList.toggle("hidden", !n);
    if (n) {
      const total = state.ds ? state.ds.rows.length : 0;
      $("#sel-count").textContent = `框選 ${n} / ${total} 列（${Math.round((n / Math.max(1, total)) * 100)}%）`;
      const src = S.sourceLabel();
      $("#sel-src").textContent = src ? "來源：圖表「" + String(src).replace(/\s+/g, " ").slice(0, 24) + "」" : "";
    }
    ai.entries.forEach((e, i) => e.el.classList.toggle("gb-src", S.sourceId() === "card-" + i));
  }
  function selClear() { const S = SEL(); if (S && S.isOn()) S.clear(); }
  // 把框選結果轉成 JMP 的 Exclude（只保留／排除框選的列）
  function selToExclude(keepOnly) {
    const S = SEL();
    if (!S || !S.isOn()) return;
    const picked = new Set(S.rows());
    const n = picked.size;
    for (let i = 0; i < state.ds.rows.length; i++) {
      const hit = picked.has(i);
      if (keepOnly) { if (hit) state.ds.excluded.delete(i); else state.ds.excluded.add(i); }
      else if (hit) state.ds.excluded.add(i);
    }
    S.clear();
    render(); updateStatus();
    toast((keepOnly ? "已只保留框選的 " : "已排除框選的 ") + n + " 列");
  }

  function updateStatus() {
    const total = state.ds.rows.length;
    const ex = state.ds.excluded.size;
    const els = Object.keys(state.elements).filter((k) => state.elements[k].on).map((k) => GBElements.defs[k].label);
    const zs = Object.entries(state.zones).filter(([, v]) => v.length).map(([k, v]) => `${k}=${v.join(",")}`);
    $("#status").textContent =
      `資料列 ${total - ex} / ${total}${ex ? "（已排除 " + ex + "）" : ""}   |   ${zs.length ? zs.join("  ") : "尚未指定變數"}   |   圖元：${els.join(" + ") || "無"}`;
    $("#btn-clear-excl").disabled = !ex;
    syncSelUI();
    if (ex !== lastExcluded) { if (lastExcluded >= 0 && ai.open) markInsightsStale("排除的列變了"); lastExcluded = ex; }
  }

  function afterChange() {
    if (state.activePreset) markPreset(null);
    suggestElementsIfNeeded();
    renderZones();
    syncElementBar();
    render();
    updateStatus();
  }
  function suggestElementsIfNeeded() {
    const any = Object.values(state.elements).some((v) => v.on);
    if (!any) suggestElements();
  }

  // ---------------- 工具列 ----------------
  function applyPreset(id) {
    const p = PRESETS.find((x) => x.id === id);
    if (!p) return;
    const sel = $("#sample-select");
    if (sel.value !== p.sample && Array.from(sel.options).some((o) => o.value === p.sample)) {
      sel.value = p.sample;
      sel.dispatchEvent(new Event("change"));   // loadSample 會重置區塊，之後再套用範本設定
    }
    state.zones = Object.fromEntries(ZONES.map((z) => [z.id, (p.zones[z.id] || []).slice()]));
    state.elements = {};
    Object.entries(p.elements).forEach(([k, v]) => (state.elements[k] = Object.assign({ on: true, alpha: 1 }, v)));
    state.freq = (p.zones.Freq || [])[0] || null;
    $("#freq-select").value = state.freq || "";
    state.title = p.label;
    $("#title-input").value = p.label;
    syncElementBar();
    renderZones();
    render();
    updateStatus();
    markPreset(p.id);
    toast("已套用：" + p.label);
  }
  function markPreset(id) {
    state.activePreset = id;
    $$("#presets .preset").forEach((b) => b.classList.toggle("on", b.dataset.preset === id));
  }

  function bindToolbar() {
    $("#presets").innerHTML = PRESETS.map((p) => `<button class="preset" data-preset="${p.id}">${p.label}</button>`).join("");
    $$("#presets .preset").forEach((b) => b.addEventListener("click", () => applyPreset(b.dataset.preset)));
    $("#sample-select").innerHTML = Object.keys(GBData.SAMPLES).map((k) => `<option>${k}</option>`).join("");
    $("#sample-select").addEventListener("change", (ev) => loadSample(ev.target.value));
    $("#freq-select").addEventListener("change", (ev) => { state.freq = ev.target.value || null; render(); updateStatus(); });
    $("#btn-upload").addEventListener("click", () => $("#file-input").click());
    $("#file-input").addEventListener("change", (ev) => { Array.from(ev.target.files).forEach(loadFile); ev.target.value = ""; });
    $("#btn-paste").addEventListener("click", openPasteDialog);
    $("#btn-clear-excl").addEventListener("click", () => { state.ds.excluded.clear(); render(); updateStatus(); });
    $("#btn-clear-sel").addEventListener("click", selClear);
    $("#btn-reset-zones").addEventListener("click", () => { state.zones = Object.fromEntries(ZONES.map((z) => [z.id, []])); afterChange(); });
    $("#grouping").addEventListener("change", (ev) => { state.grouping = ev.target.value; render(); });
    $("#legend-toggle").addEventListener("change", (ev) => { state.legend = ev.target.checked; render(); });
    $("#height-range").value = state.height;
    $("#height-range").addEventListener("input", (ev) => { state.height = +ev.target.value; $("#height-val").textContent = ev.target.value + "px"; renderSoon(); });
    $("#title-input").addEventListener("input", (ev) => { state.title = ev.target.value; renderSoon(); });
    $("#export-bg").addEventListener("change", (ev) => { state.exportBg = ev.target.value; });
    $("#btn-png").addEventListener("click", () => exportPNG());
    $("#btn-svg").addEventListener("click", () => exportSVG());
    $("#btn-done").addEventListener("click", showScript);
    $("#btn-table").addEventListener("click", showTable);
    $("#btn-help").addEventListener("click", () => $("#help").classList.toggle("hidden"));
    aiBind();
    $("#var-search").addEventListener("input", (ev) => {
      const q = ev.target.value.trim().toLowerCase();
      $$("#variables .var").forEach((v) => {
        v.classList.toggle("hidden", !!q && v.dataset.key.toLowerCase().indexOf(q) < 0);
      });
    });
    $("#chart").addEventListener("contextmenu", (ev) => {
      ev.preventDefault();
      openChartMenu(ev);
    });
  }

  function openChartMenu(ev) {
    const items = GBElements.order.map((id) => ({
      label: GBElements.defs[id].label,
      check: !!(state.elements[id] || {}).on,
      action: () => toggleElement(id)
    }));
    openMenu(ev, [
      { label: "AI 自動分析（自動組合有意義的圖）", action: aiRun },
      "-",
      ...items,
      "-",
      ...(selOn()
        ? [
            { label: `清除框選（${SEL().count()} 列）`, action: selClear },
            { label: "只保留框選的列（其餘排除）", action: () => selToExclude(true) },
            { label: "排除框選的列", action: () => selToExclude(false) },
            "-"
          ]
        : [{ label: "拖曳可框選（Alt 追加／Shift 減除）", disabled: true }, "-"]),
      { label: "重設縮放（地圖）", action: () => { d3.select("#chart").call(d3.zoom().transform, d3.zoomIdentity); } },
      { label: "匯出 PNG", action: exportPNG },
      { label: "顯示資料表", action: showTable },
      { label: "完成（產生 JMP 腳本）", action: showScript }
    ]);
  }

  // ---------------- 匯出 ----------------
  function svgNode() { return $("#chart"); }
  function cssText() {
    return Array.from(document.styleSheets)
      .flatMap((sh) => { try { return Array.from(sh.cssRules).map((r) => r.cssText); } catch (e) { return []; } })
      .join("\n");
  }
  function baseFontStack() {
    return (getComputedStyle(document.body).fontFamily || "sans-serif") + ", sans-serif";
  }
  function exportName(ext, override) {
    const t = (override || state.title || "").trim();
    const base = t || `${(state.ds.name || "graph")}-${(state.zones.Y[0] || "") + (state.zones.X[0] ? " vs " + state.zones.X[0] : "")}`;
    return (base.replace(/[\\/:*?"<>|#\uFF1A\uFF1F\uFF01\u3000\u3001\uFF0C\uFF1B\s]+/g, "_").replace(/^[_.]+|[_.]+$/g, "") || "graph") + "." + ext;
  }
  // 產生可獨立顯示的 SVG：嵌入樣式、明確尺寸、白色實底（避免匯出後背景變黑）
  function buildExportSvg(node) {
    node = node || svgNode();
    const vb = (node.getAttribute("viewBox") || "0 0 800 450").split(/\s+/).map(Number);
    const w = node.clientWidth || vb[2] || 800, h = node.clientHeight || vb[3] || 450;
    const clone = node.cloneNode(true);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    clone.setAttribute("xmlns:xlink", "http://www.w3.org/1999/xlink");
    clone.setAttribute("width", Math.round(w));
    clone.setAttribute("height", Math.round(h));
    clone.removeAttribute("style");
    const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = `svg{font-family:${baseFontStack()}}` + cssText();
    const transparent = state.exportBg !== "white";
    if (transparent) {
      // 透明背景：拔掉根元素的白色底色與面板底rect，讓匯出的圖真正透通
      style.textContent += `\n.gb-svg{background:transparent !important}.gb-svg .panel-bg{fill:none !important;stroke:none !important}`;
    }
    clone.insertBefore(style, clone.firstChild);
    if (!transparent) {
      const bg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      bg.setAttribute("x", vb[0] || 0); bg.setAttribute("y", vb[1] || 0);
      bg.setAttribute("width", vb[2] || w); bg.setAttribute("height", vb[3] || h);
      bg.setAttribute("fill", "#ffffff");
      clone.insertBefore(bg, style.nextSibling);
    }
    return { str: new XMLSerializer().serializeToString(clone), w, h, transparent };
  }
  function exportSVG(node, name) {
    const { str } = buildExportSvg(node);
    downloadBlob(new Blob(['<?xml version="1.0" encoding="UTF-8"?>\n' + str], { type: "image/svg+xml;charset=utf-8" }), exportName("svg", name));
  }
  function exportPNG(node, name) {
    const { str, w, h, transparent } = buildExportSvg(node);
    const scale = Math.max(1, Math.min(3, Math.round((window.devicePixelRatio || 1) * 2) || 2));
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(w * scale); canvas.height = Math.round(h * scale);
      const ctx = canvas.getContext("2d");
      if (!transparent) { ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, canvas.width, canvas.height); }
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      const send = () => canvas.toBlob((b) => b && downloadBlob(b, exportName("png", name)), "image/png");
      if (canvas.toBlob) send(); else downloadBlob(dataUrlToBlob(canvas.toDataURL("image/png")), exportName("png", name));
    };
    img.onerror = () => alert("PNG 匯出失敗，請改用 SVG");
    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(str);
  }
  function dataUrlToBlob(url) {
    const [head, b64] = url.split(",");
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return new Blob([buf], { type: head.match(/:(.*?);/)[1] });
  }
  function downloadBlob(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }

  // ---------------- JMP 腳本（Done） ----------------
  function showScript() { showScriptFor(state.zones, state.elements, state.order, state.freq); }
  function showScriptFor(zones, elements, orderList, freqKey) {
    const body = buildScript(zones, elements, orderList, freqKey);
    showModal("完成 — 對應的 JMP 腳本", body, () => {
      if (navigator.clipboard) navigator.clipboard.writeText(body).then(() => toast("已複製到剪貼簿"));
      else toast("瀏覽器不支援剪貼簿，請手動複製");
    });
  }
  function buildScript(zones, elements, orderList, freqKey) {
    const z = zones;
    const order = Array.isArray(orderList) ? orderList : state.order;
    const els = Object.keys(elements).filter((k) => elements[k] && elements[k].on);
    const args = [];
    const add = (name, keys) => { if (keys && keys.length) args.push(`${name}( ${keys.map((k) => ":" + col(k)).join(", ")} )`); };
    add("X", z.X); add("Y", z.Y);
    add("Group X", z["Group X"]); add("Group Y", z["Group Y"]);
    add("Wrap", z.Wrap);
    add("Overlay", (z.Overlay || []).concat(z.Color || []));
    add("Size", z.Size);
    add("Shape", z.Shape);
    const freq = (z.Freq && z.Freq[0]) || freqKey;
    if (freq) args.push(`Freq( :${col(freq)} )`);
    const elArgs = elementArgs(els, elements);
    const notes = [];
    if (z.Y && z.Y.length > 1) notes.push(`// 多個 Y：Y 區塊的擺放順序＝面板由上而下（${z.Y.join(" → ")}）`);
    if (z.X && z.X.length > 1) notes.push(`// 多個 X：X 區塊的擺放順序＝面板由左而右（${z.X.join(" → ")}）`);
    const topEls = order.filter((k) => (elements[k] || {}).on);
    if (els.length > 1) {
      notes.push("// 圖層前後順序（由下而上）：" + topEls.map((k) => GBElements.defs[k].label).join(" → ")
        + "；透明度：" + topEls.map((k) => `${GBElements.defs[k].label}=${(elements[k].alpha == null ? 1 : elements[k].alpha)}`).join(", "));
    }
    return [
      "// Graph Builder — 由網頁版 Graph Builder 產生",
      "// 可直接貼到 JMP 的腳本視窗（視窗 > 腳本）執行",
      ...notes,
      `dt = Data Table( "${state.ds.name}" );`,
      "dt << Graph Builder(",
      "  Variables(",
      "    " + args.join(",\n    "),
      "  ),",
      "  Elements( " + (elArgs.length ? elArgs.join(", ") : "Points( X, Y )") + " )",
      ");"
    ].join("\n");
  }
  function col(k) { return /\s/.test(k) ? "`" + k + "`" : k; }
  function elementArgs(els, elements) {
    // 對應 JMP 的 Elements(...) 寫法（含圖元引用 X/Y 與常用參數）
    const EL = elements || state.elements;
    const out = [];
    const sm = EL.smoother || {};
    const ln = EL.line || {};
    const method = { loess: "Loess", spline: "Spline", linear: "Linear" }[sm.method || "loess"];
    const statName = (o) => ({ mean: "Mean", median: "Median", sum: "Sum", min: "Min", max: "Max", n: "N" }[o.statistic || "mean"]);
    for (const id of els) {
      if (id === "smoother") continue;
      if (id === "points") {
        out.push(els.includes("smoother") ? `Points( X, Y, Smoother( ${method} ) )` : "Points( X, Y )");
        continue;
      }
      const o = EL[id] || {};
      const map = {
        line: `Line( X, Y, Summary Stat( "${statName(o)}" )${o.ci ? `, Confidence Interval( ${((o.ciLevel == null ? 95 : o.ciLevel) / 100).toFixed(2)} )` : "" } )`,
        box: "Boxplot( X, Y )",
        bar: `Bar( X, Y${o.count || !state.ds ? "" : `, Summary Stat( "${statName(o)}" )`}${o.ci ? ", Interval( \"Mean Reciprocal Square\" )" : ""} )`,
        histogram: "Histogram( X )",
        heatmap: "Heatmap( X, Y )",
        contour: "Density Contours( X, Y )",
        time: "Line( X, Y, Summary Stat( \"Mean\" ) )",
        map: "Map( Shapes, Lat, Lon, Points )",
        mosaic: "Mosaic( X, Y )",
        pie: 'Area( X, Y, Label( "per" ) )',
        sankey: "/* 桑基圖：JMP Graph Builder 無對應圖元，請以資料表彙整 From/To/Value 後用其他圖元或附加元件 */"
      };
      const txt = map[id] || id;
      if (!out.includes(txt)) out.push(txt);
    }
    if (!out.length && els.includes("smoother")) out.push(`Points( X, Y, Smoother( ${method} ) )`);
    return out;
  }

  function showTable() {
    const cols = state.ds.columns;
    const S = SEL();
    const html = `<div class="tbl-wrap"><table><thead><tr><th>#</th>${cols.map((c) => `<th title="${c.type}">${escapeHtml(c.key)}</th>`).join("")}</tr></thead><tbody>${state.ds.rows.slice(0, 200).map((r, i) => `<tr class="${state.ds.excluded.has(i) ? "excl " : ""}${S && S.has(i) ? "sel" : ""}"><td>${i + 1}</td>${cols.map((c) => `<td>${escapeHtml(fmtCell(c.values[i]))}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
    showModal(`資料表（前 200 列，點擊列可排除${S && S.isOn() ? "；橘色底＝目前框選到的列" : ""}）`, "", null, html, (root) => {
      root.querySelectorAll("tbody tr").forEach((tr, i) => {
        tr.addEventListener("click", () => {
          if (state.ds.excluded.has(i)) state.ds.excluded.delete(i); else state.ds.excluded.add(i);
          tr.classList.toggle("excl");
          render(); updateStatus();
        });
      });
    });
  }
  function fmtCell(v) { return v instanceof Date ? d3.timeFormat("%Y-%m-%d")(v) : (v == null ? "" : String(v)); }

  function openPasteDialog() {
    showModal("貼上資料（CSV／TSV）", "", null, `<textarea id="paste-box" placeholder="Name,Height,Weight,Sex&#10;Tom,65,115,M"></textarea>`,
      (root) => {
        const btn = document.createElement("button");
        btn.className = "primary";
        btn.textContent = "載入";
        btn.addEventListener("click", () => {
          const text = $("#paste-box", root).value;
          const rows = /\t/.test(text) && !/,/.test(text) ? GBData.parseTSV(text) : GBData.parseCSV(text);
          if (!rows.length) { alert("解析不到資料"); return; }
          closeModal();
          adoptData("貼上的資料", rows);
        });
        root.querySelector(".modal-actions").appendChild(btn);
      });
  }

  // ---------------- AI 自動分析（自動組合有意義的圖）----------------
  const ai = { open: false, running: false, result: null, showAll: false, stale: false, entries: [] };
  let aiTimer = null, lastExcluded = -1;

  const stripTags = (t) => String(t).replace(/<[^>]*>/g, "");
  // 分析結果裡我們自己用 <b> 標重點，其餘（資料值）一律 escape
  const safeRich = (t) => escapeHtml(t).replace(/&lt;b&gt;/g, "<b>").replace(/&lt;\/b&gt;/g, "</b>");

  // 小圖有自己的互動宿主：點一下排除列／點圖例時，重畫這面牆而不是只有主圖
  function insightHost() {
    return {
      hiddenGroups: state.hiddenGroups,
      toggleHiddenGroup(k) {
        if (state.hiddenGroups.has(k)) state.hiddenGroups.delete(k); else state.hiddenGroups.add(k);
        aiRefreshSoon();
      },
      rerenderSoon() { aiRefreshSoon(); },
      updateStatus() { updateStatus(); }
    };
  }
  function markInsightsStale(why) {
    if (!ai.open || !ai.result || ai.stale) return;
    ai.stale = true;
    const hint = $("#ai-hint");
    if (hint) { hint.textContent = "資料已經改變（" + (why || "排除的列變了") + "）· 點「重新分析」更新"; hint.style.color = "var(--warn)"; }
  }
  function aiRefreshSoon() { clearTimeout(aiTimer); aiTimer = setTimeout(aiRedrawAll, 200); }
  async function aiRedrawAll() {
    for (const e of ai.entries) await aiDraw(e);
    render();
    syncSelUI();
  }

  async function aiRun() {
    if (ai.running) return;
    if (!global.GBInsight) { toast("分析引擎 insight.js 沒載入"); return; }
    if (!state.ds || !state.ds.rows.length) { toast("先載入一張資料表"); return; }
    ai.running = true;
    const btn = $("#btn-ai");
    btn.classList.add("busy"); btn.disabled = true;
    $("#insights").classList.remove("hidden"); ai.open = true;
    ai.showAll = false;
    const hint = $("#ai-hint"); hint.style.color = ""; hint.textContent = "掃描中…正在做統計檢定";
    $("#ai-summary").innerHTML = '<span class="ai-sum-lead">正在檢定所有欄位組合…</span>' +
      "<span>相關／變異數分析／卡方／趨勢／自我相關／分布形態 · 全部在本機算，不上網</span>";
    $("#ai-grid").innerHTML = Array.from({ length: 5 }, () =>
      '<div class="insight skeleton"><div class="sk-line w60"></div><div class="sk-line"></div><div class="sk-box"></div><div class="sk-line"></div></div>').join("");
    $("#ai-foot").textContent = "";
    await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 30)));   // 讓骨架先顯示出來
    let res = null, err = null;
    try { res = global.GBInsight.analyze(state.ds, { freqKey: state.freq }); } catch (e) { err = e; }
    ai.running = false; btn.classList.remove("busy"); btn.disabled = false;
    if (err) {
      console.error(err);
      $("#ai-summary").innerHTML = '<span class="ai-sum-lead">分析失敗：</span>' + escapeHtml(err.message);
      $("#ai-grid").innerHTML = "";
      return;
    }
    ai.result = res; ai.stale = false;
    await aiRender();
    const box = $("#insights").getBoundingClientRect();
    window.scrollTo({ top: box.top + window.scrollY - 8, behavior: "smooth" });
  }

  async function aiRender() {
    const res = ai.result;
    if (!res) return;
    const nm = global.GBInsight.KINDS;
    const list = ai.showAll ? res.all : res.cards;
    selClear();                 // 圖表牆內容要重建：舊的框選來源已失效
    ai.entries = [];
    const grid = $("#ai-grid");
    grid.innerHTML = "";

    const kinds = {};
    res.cards.forEach((c) => { kinds[c.kind] = (kinds[c.kind] || 0) + 1; });
    const lead = res.cards.length
      ? `找到 <b>${res.cards.length}</b> 個值得看的組合（依統計強度排序）`
      : "沒找到達顯著水準的組合";
    $("#ai-summary").innerHTML =
      `<span class="ai-sum-lead">${lead}</span>` +
      `<span>掃描 ${res.scanned.columns} 欄 × ${res.scanned.used} 列` +
      (res.scanned.excluded ? "（已排除 " + res.scanned.excluded + " 列）" : "") +
      (res.sampled ? " · 大資料已抽樣" : "") + "</span>" +
      Object.keys(kinds).sort((a, b) => kinds[b] - kinds[a]).map((k) =>
        `<button class="ai-chip k-${k}" data-kind="${k}" title="跳到第一張「${nm[k].label}」"><i></i>${nm[k].label} × ${kinds[k]}</button>`).join("");
    $$("#ai-summary .ai-chip").forEach((b) => b.addEventListener("click", () => {
      const el = grid.querySelector('.insight[data-kind="' + b.dataset.kind + '"]');
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }));

    const more = $("#btn-ai-more");
    if (res.all.length > res.cards.length) {
      more.classList.remove("hidden");
      more.textContent = ai.showAll ? `只看 ${res.cards.length} 個建議` : `顯示全部 ${res.all.length} 個候選`;
    } else more.classList.add("hidden");

    if (!list.length) {
      grid.innerHTML = `<div class="ai-empty">${escapeHtml((res.notes || []).join(" ") || "沒有可用的組合。")}<br>` +
        "至少需要兩個數值欄（看相關）、或一個類別欄＋一個數值欄（看組間差異），才找得到有意義的圖。</div>";
      $("#ai-foot").textContent = "";
      return;
    }
    list.forEach((cardData, i) => {
      const el = document.createElement("article");
      el.className = "insight";
      el.dataset.kind = cardData.kind;
      el.dataset.i = String(i);
      el.innerHTML =
        `<div class="ins-head"><span class="ins-kind k-${cardData.kind}">${(nm[cardData.kind] || {}).label || cardData.kind}</span>` +
        `<span class="ins-title">${safeRich(cardData.title)}</span>` +
        `<span class="ins-num" title="統計強度分數（0–1）">${cardData.score.toFixed(2)}</span></div>` +
        `<div class="ins-tags">${(cardData.tags || []).map((t) => `<span>${escapeHtml(t)}</span>`).join("")}</div>` +
        `<div class="ins-chart"><svg class="gb-svg" role="img" aria-label="${escapeHtml(stripTags(cardData.title))}"></svg></div>` +
        `<p class="ins-detail">${safeRich(cardData.detail)}</p>` +
        `<div class="ins-method">方法：${escapeHtml(cardData.method || "")}</div>` +
        `<div class="ins-actions">` +
        `<button class="primary" data-act="apply" title="把放置區、圖元、圖層順序與透明度整套搬到上面的畫布">在主圖開啟</button>` +
        `<button data-act="png" title="匯出這張（沿用上方「匯出背景」的設定）">PNG</button>` +
        `<button data-act="jsl" title="產生這張圖對應的 JMP 腳本">JMP 腳本</button></div>`;
      grid.appendChild(el);
      const entry = { card: cardData, el, svg: $(".gb-svg", el) };
      ai.entries.push(entry);
      $('[data-act="apply"]', el).addEventListener("click", () => aiApply(entry));
      $('[data-act="png"]', el).addEventListener("click", () => exportPNG(entry.svg, stripTags(cardData.title).slice(0, 60)));
      $('[data-act="jsl"]', el).addEventListener("click", () =>
        showScriptFor(cardData.spec.zones, cardData.spec.elements, cardData.spec.paintOrder, cardData.spec.freq));
    });
    $("#ai-foot").innerHTML = "每一張都是同一份資料、同一套本機統計引擎算出來的；圖裡<b>拖曳可框選</b>（Alt 追加／Shift 減除），框到的資料在<strong>這一整面牆與上方主圖</strong>一起高亮、沒框到的變淡；點一下排除列、點圖例隱藏群組的行為與主圖相同，排除是共用的，會一起重算。分析用時 " + res.ms + " ms。";
    for (const e of ai.entries) await aiDraw(e);
    syncSelUI();
  }

  async function aiDraw(e) {
    if (!e.el.isConnected || !e.svg) return;
    const idx = ai.entries.indexOf(e);
    const spec = Object.assign({}, e.card.spec, {
      host: insightHost(),
      chartId: "card-" + idx,
      chartLabel: stripTags(e.card.title).slice(0, 28),
      grouping: e.card.spec.grouping || state.grouping,
      legend: e.card.spec.legend !== false
    });
    try { await GBElements.draw(e.svg, state.ds, spec); }
    catch (err) {
      console.warn("AI 卡片繪製失敗", e.card.kind, err);
      const box = $(".ins-chart", e.el);
      if (box) box.innerHTML = `<div class="ai-empty">這張图画不起來：${escapeHtml(err.message)}</div>`;
    }
  }

  function aiApply(e) {
    const spec = e.card.spec;
    state.zones = Object.fromEntries(ZONES.map((z) => [z.id, (spec.zones[z.id] || []).slice()]));
    state.elements = {};
    Object.keys(spec.elements).forEach((k) => (state.elements[k] = Object.assign({}, spec.elements[k])));
    const on = Object.keys(spec.elements);
    state.order = GBElements.order.filter((k) => on.indexOf(k) < 0)
      .concat((spec.paintOrder || on).filter((k) => on.indexOf(k) >= 0));
    state.freq = spec.freq || null;
    $("#freq-select").value = state.freq || "";
    state.title = ""; $("#title-input").value = "";
    markPreset(null);
    ai.entries.forEach((x) => x.el.classList.toggle("applied", x === e));
    renderZones(); syncElementBar(); render(); updateStatus();
    window.scrollTo({ top: 0, behavior: "smooth" });
    toast("已搬到主圖：" + stripTags(e.card.title).slice(0, 42));
  }

  function aiClose() {
    $("#insights").classList.add("hidden");
    ai.open = false;
  }

  function aiBind() {
    $("#btn-ai").addEventListener("click", () => {
      if (ai.running) return;
      if (ai.open && ai.result && !ai.stale) { $("#insights").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
      aiRun();
    });
    $("#btn-ai-close").addEventListener("click", aiClose);
    $("#btn-ai-rerun").addEventListener("click", () => { ai.stale = false; aiRun(); });
    $("#btn-ai-more").addEventListener("click", () => { ai.showAll = !ai.showAll; aiRender(); });
  }
  function aiRerunIfOpen() {
    if (!ai.open || ai.running) return;
    ai.stale = false;
    setTimeout(() => { if (!ai.running) aiRun(); }, 90);
  }

  // ---------------- 對話框 ----------------
  function showModal(title, code, onCopy, html, after) {
    closeModal();
    const mask = document.createElement("div");
    mask.className = "modal-mask";
    mask.innerHTML = `<div class="modal"><div class="modal-head"><b>${escapeHtml(title)}</b><button class="chip-x" id="modal-close">×</button></div>
      <div class="modal-body">${html || ""}${code ? `<pre id="modal-code">${escapeHtml(code)}</pre>` : ""}</div>
      <div class="modal-actions"></div></div>`;
    document.body.appendChild(mask);
    $("#modal-close", mask).addEventListener("click", closeModal);
    mask.addEventListener("click", (ev) => { if (ev.target === mask) closeModal(); });
    if (code && onCopy) {
      const b = document.createElement("button");
      b.className = "primary"; b.textContent = "複製腳本";
      b.addEventListener("click", onCopy);
      $(".modal-actions", mask).appendChild(b);
    }
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "關閉";
    closeBtn.addEventListener("click", closeModal);
    $(".modal-actions", mask).appendChild(closeBtn);
    if (after) after(mask);
  }
  function closeModal() { const m = document.querySelector(".modal-mask"); if (m) m.remove(); }
  function toast(msg) {
    const t = document.createElement("div");
    t.className = "toast"; t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1800);
  }

  function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

  global.GBApp = {
    state, render, renderSoon, rerenderSoon, updateStatus, aiRun, aiState: ai,
    hiddenGroups: state.hiddenGroups,
    toggleHiddenGroup(k) {
      if (state.hiddenGroups.has(k)) state.hiddenGroups.delete(k); else state.hiddenGroups.add(k);
      render();
    }
  };

  document.addEventListener("DOMContentLoaded", init);
})(typeof window !== "undefined" ? window : globalThis);
