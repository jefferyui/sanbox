/* Graph Builder — 資料載入、型別推斷、內建範例資料 */
(function (global) {
  "use strict";

  const CONTINUOUS_HINTS = /(height|weight|age|time|date|temp|price|score|value|amount|count|lat|lon|lng|speed|duration|sales|cost|rate|index|dpi|mpg|km|kg|cm|inch|收入|溫度|時間|年齡|價格|數量|銷售|次數)/i;
  const ID_HINTS = /(^|_)(name|label|title|姓名|名稱)(_|$)|\bname\b/i;

  function looksLikeDateColumn(name, values) {
    if (!values.length) return false;
    let hits = 0, considered = 0;
    for (const raw of values.slice(0, 200)) {
      if (raw == null || raw === "") continue;
      const s = String(raw).trim();
      // 明確日期格式
      if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}([ T]\d{1,2}:\d{2})?$/.test(s) ||
          /^\d{1,2}[-/]\d{1,2}[-/]\d{4}$/.test(s) ||
          /^\d{4}[-/]\d{1,2}([ T]\d{1,2}:\d{2})?$/.test(s)) hits++;
      considered++;
    }
    if (/date|time|日期|時間|year|月份/i.test(name) && considered) return hits / considered > 0.6;
    return considered > 0 && hits / considered > 0.8;
  }

  function parseDateValue(s) {
    const str = String(s).trim();
    let m;
    if ((m = str.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?$/))) {
      return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0));
    }
    if ((m = str.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/))) {
      return new Date(+m[3], +m[1] - 1, +m[2]);
    }
    if ((m = str.match(/^(\d{4})[-/](\d{1,2})$/))) return new Date(+m[1], +m[2] - 1, 1);
    const d = new Date(str);
    return isNaN(d.getTime()) ? null : d;
  }

  function numericOf(v) {
    if (typeof v === "number") return v;
    if (v == null || v === "") return null;
    const s = String(v).replace(/[, ]/g, "");
    const n = Number(s);
    return isFinite(n) ? n : null;
  }

  function inferColumns(rows) {
    if (!rows.length) return [];
    const keys = Object.keys(rows[0]);
    return keys.map((key) => {
      const raw = rows.map((r) => r[key]);
      const nonBlank = raw.filter((v) => v != null && v !== "");
      const uniq = Array.from(new Set(nonBlank.map(String)));
      const nums = raw.map(numericOf);
      const numNonNull = nums.filter((n) => n != null);
      const numericRatio = nonBlank.length ? numNonNull.length / nonBlank.length : 0;
      const dateCandidates = raw.filter((v) => v != null && v !== "" && typeof v !== "number");
      const dateParsed = dateCandidates.map(parseDateValue);
      const dateRatio = dateCandidates.length ? dateParsed.filter(Boolean).length / dateCandidates.length : 0;
      const nameLike = /(^|_)(name|label|title|姓名|名稱|名稱)$|\bname\b/i.test(key);
      const isDate = dateCandidates.length > 0 && dateRatio > 0.9 &&
        (/date|time|日期|時間|year|month|季度/i.test(key) ||
         dateCandidates.every((v) => /^\d{4}[-/]\d{1,2}([-/]\d{1,2})?([ T]\d{1,2}:\d{2})?$|^\d{1,2}[-/]\d{1,2}[-/]\d{4}$/.test(String(v).trim())));
      const distinctNum = new Set(numNonNull).size;

      const catNamed = /(^|_)(sex|grp|group|type|level|tier|cat|yesno|flag|類別|組|級)(_|$)/i.test(key);
      let type, numFmt = null, hasDate = isDate;
      if (isDate) {
        type = "continuous"; numFmt = "date";
      } else if (numericRatio > 0.9 && uniq.length > 0) {
        type = "continuous";
        const intLike = numNonNull.length && numNonNull.every((n) => Number.isInteger(n));
        numFmt = intLike ? "integer" : "number";
        if (distinctNum > 1 && distinctNum <= 12 && catNamed) type = "ordinal";
        // 少量整數值且名稱像分數/年齡/等級 → 序號（JMP 的 Age 也是 Ordinal）
        else if (intLike && distinctNum > 1 && distinctNum <= 12 &&
                 /(^|_)(age|scores?|grades?|stars?|rating|rank|level|step|級|年齡|年歲|評分|等級)(_|$)/i.test(key)) type = "ordinal";
      } else {
        type = "nominal";
      }

      const values = raw.map((v, i) => {
        if (isDate) return v == null || v === "" ? null : parseDateValue(v);
        if (type === "continuous") return nums[i];
        return v == null || v === "" ? null : String(v);
      });

      return {
        key, type, numFmt, hasDate, values, raw,
        distinct: uniq.length, distinctNum,
        role: guessRole(key, type, uniq.length, distinctNum, isDate, nameLike),
        missing: raw.length - nonBlank.length
      };
    });
  }

  function guessRole(key, type, distinct, distinctNum, isDate, nameLike) {
    if (isDate) return "time";
    if (/^(lat|latitude|ycoord|緯度)$/i.test(key)) return "lat";
    if (/^(lon|lng|long|longitude|xcoord|經度)$/i.test(key)) return "lon";
    if (type === "continuous" && /^(freq|frequency|count|n|次數|權重|freqwt)$/i.test(key) && distinctNum > 1) return "freq";
    if (nameLike && type !== "continuous") return "label";
    if (type === "continuous") return "measure";
    if (type === "ordinal") return "ordinal";
    return "category";
  }

  function typedCopy(col, type) {
    const c = Object.assign({}, col, { type });
    return c;
  }

  // ---------- 內建 Big Class 資料（JMP Help > Sample Data Folder 風格） ----------
  const BIG_CLASS = `North,17,68,130,M
Tom,16,65,115,M
Alfred,14,64,90,M
Alice,14,63,85,F
Madison,15,66,105,M
John,15,65,100,M
James,15,66,105,M
Robert,15,67,110,M
Michael,14,62,85,M
William,14,63,90,M
David,14,62,85,M
Richard,14,61,80,M
Joseph,14,60,75,M
Charles,13,59,70,M
Thomas,13,57,65,M
Christopher,13,56,62,M
Daniel,13,55,60,M
Matthew,13,56,63,M
Anthony,12,54,58,M
Donald,12,52,55,M
Steven,12,53,57,M
Kenneth,12,52,55,M
Mark,12,51,52,M
George,12,50,50,M
Paul,12,51,53,M
Jeffrey,11,49,48,M
Frank,11,48,45,M
Ray,11,47,44,M
Bob,15,65,105,M
Jim,16,67,118,M
Bill,17,69,135,M
Jerry,16,66,112,M
Sally,15,64,100,F
Helen,14,61,85,F
Susan,16,65,105,F
Judy,15,63,95,F
Mary,14,60,80,F
Lori,13,58,72,F
Barbara,15,62,90,F
Cathy,14,61,82,F
Patti,13,57,70,F
Peggy,16,66,110,F
Debbie,15,63,92,F
Carol,14,60,78,F
Nancy,13,56,65,F
Beth,12,52,52,F
Randy,15,64,98,M
Melissa,14,62,88,F
Karen,13,58,74,F
Heather,12,54,60,F`;

  function bigClassRows() {
    return BIG_CLASS.trim().split("\n").map((line) => {
      const [Name, Age, Height, Weight, Sex] = line.split(",");
      return {
        Name, Age: +Age, Height: +Height, Weight: +Weight, Sex,
        // 依 身高×體重 產生可重複的偽隨機區間，作為 Freq 之外的第二個連續變數
        Runtime: +(8 + (Number(Height) % 7) * 0.9 + (Number(Weight) % 5) * 0.6).toFixed(1),
        Freq: 1
      };
    });
  }

  // 天氣時間序列（示範 Time Series / Line）
  function weatherRows() {
    const months = ["2024-01", "2024-02", "2024-03", "2024-04", "2024-05", "2024-06",
                    "2024-07", "2024-08", "2024-09", "2024-10", "2024-11", "2024-12",
                    "2025-01", "2025-02", "2025-03", "2025-04", "2025-05", "2025-06"];
    const cities = {
      Taipei: [16.2, 17.1, 19.4, 22.8, 25.9, 28.1, 29.8, 29.6, 27.9, 24.8, 21.3, 17.4, 16.5, 17.8, 20.1, 23.2, 26.4, 28.6],
      Kaohsiung: [18.9, 19.8, 22.1, 25.4, 28.1, 30.2, 31.4, 31.1, 29.8, 27.4, 24.1, 20.2, 19.1, 20.4, 22.8, 25.9, 28.6, 30.6],
      Taichung: [16.8, 17.9, 20.1, 23.5, 26.4, 28.6, 29.9, 29.7, 28.2, 25.5, 22.2, 18.4, 17.2, 18.5, 20.9, 23.9, 26.8, 29.0]
    };
    const rain = { Taipei: [120, 140, 180, 210, 300, 380, 320, 350, 400, 90, 60, 80, 110, 150, 190, 220, 310, 390],
                   Kaohsiung: [20, 40, 60, 90, 180, 320, 380, 420, 350, 40, 20, 15, 18, 45, 70, 100, 200, 340],
                   Taichung: [35, 50, 70, 110, 200, 300, 330, 360, 280, 55, 30, 28, 32, 55, 85, 125, 215, 315] };
    const rows = [];
    Object.keys(cities).forEach((city) => {
      months.forEach((m, i) => {
        rows.push({ Date: m + "-01", City: city, Temp: cities[city][i], Rain: rain[city][i] });
      });
    });
    return rows;
  }

  // 世界城市坐标（示範 Map）
  const CITIES = [
    ["Taipei", 25.03, 121.56, "Asia", 2647], ["Kaohsiung", 22.62, 120.30, "Asia", 2769],
    ["Tokyo", 35.68, 139.69, "Asia", 13960], ["Seoul", 37.56, 126.97, "Asia", 9508],
    ["Hong Kong", 22.31, 114.17, "Asia", 7482], ["Singapore", 1.35, 103.81, "Asia", 5637],
    ["Bangkok", 13.75, 100.50, "Asia", 10539], ["Mumbai", 19.07, 72.87, "Asia", 12442],
    ["Delhi", 28.61, 77.20, "Asia", 16787], ["Sydney", -33.86, 151.20, "Oceania", 5312],
    ["London", 51.50, -0.12, "Europe", 8982], ["Paris", 48.85, 2.35, "Europe", 2161],
    ["Berlin", 52.52, 13.40, "Europe", 3644], ["Madrid", 40.41, -3.70, "Europe", 3223],
    ["Moscow", 55.75, 37.61, "Europe", 12537], ["Istanbul", 41.00, 28.97, "Europe", 15462],
    ["New York", 40.71, -74.00, "Americas", 8336], ["Los Angeles", 34.05, -118.24, "Americas", 3979],
    ["Chicago", 41.87, -87.62, "Americas", 2693], ["Toronto", 43.65, -79.38, "Americas", 2930],
    ["Mexico City", 19.43, -99.13, "Americas", 9209], ["Sao Paulo", -23.55, -46.63, "Americas", 12325],
    ["Rio de Janeiro", -22.90, -43.17, "Americas", 6747], ["Buenos Aires", -34.60, -58.38, "Americas", 3075],
    ["Cairo", 30.04, 31.24, "Africa", 10025], ["Lagos", 6.52, 3.37, "Africa", 15388],
    ["Nairobi", -1.29, 36.82, "Africa", 4397], ["Cape Town", -33.92, 18.42, "Africa", 4618],
    ["Dubai", 25.20, 55.27, "Asia", 3331], ["Tel Aviv", 32.08, 34.78, "Asia", 467]
  ];

  function cityRows() {
    return CITIES.map(([City, Lat, Lon, Continent, Pop]) => ({ City, Lat, Lon, Continent, Pop }));
  }

  // 能源流向（桑基圖範例）：初級能源 → 轉換 → 部門，單位 TWh（數值前後平衡）
  const ENERGY_FLOWS = [
    ["煤", "固體燃料", 900], ["天然氣", "氣體燃料", 1200], ["原油", "煉油", 2600],
    ["核燃料", "發電系統", 420], ["生質能與廢棄物", "生物轉換", 260], ["水力", "發電系統", 60],
    ["風力", "發電系統", 90], ["太陽光電", "發電系統", 110], ["太陽能熱", "太陽熱利用", 25],
    ["固體燃料", "發電系統", 700], ["固體燃料", "區域供熱", 100], ["固體燃料", "工業", 100],
    ["氣體燃料", "發電系統", 520], ["氣體燃料", "區域供熱", 120], ["氣體燃料", "家庭", 180],
    ["氣體燃料", "商業", 120], ["氣體燃料", "工業", 200], ["氣體燃料", "損失", 60],
    ["煉油", "成品油", 2200], ["煉油", "石化工料", 300], ["煉油", "損失", 100],
    ["生物轉換", "發電系統", 60], ["生物轉換", "區域供熱", 80], ["生物轉換", "工業", 120],
    ["太陽熱利用", "區域供熱", 25],
    ["發電系統", "輸配電損失", 100], ["發電系統", "家庭", 480], ["發電系統", "商業", 430],
    ["發電系統", "工業", 620], ["發電系統", "交通", 60], ["發電系統", "過剩發電/出口", 270],
    ["區域供熱", "家庭", 130], ["區域供熱", "商業", 120], ["區域供熱", "工業", 45], ["區域供熱", "損失", 30],
    ["成品油", "交通", 1500], ["成品油", "工業", 380], ["成品油", "商業", 90],
    ["成品油", "家庭", 40], ["成品油", "損失", 190], ["石化工料", "工業", 300]
  ];

  function energyRows() {
    return ENERGY_FLOWS.map(([From, To, Value]) => ({ From, To, Value }));
  }

  // 汽車規格（多變數軸範例）：Country × Type，含多個連續變數
  // 每個 (Country, Type) 有基準值，再用可重現的偽隨機數扰动
  const CAR_BASE = [
    ["Japan", "Sedan", 1350, 10.4, 2.0, 150], ["Japan", "SUV", 1650, 11.2, 2.5, 190],
    ["Japan", "Hatchback", 1150, 9.8, 1.5, 110], ["Japan", "Truck", 1950, 12.4, 3.0, 210],
    ["USA", "Sedan", 1600, 11.6, 3.0, 240], ["USA", "SUV", 2150, 12.6, 3.6, 290],
    ["USA", "Truck", 2450, 13.4, 5.0, 380], ["USA", "Hatchback", 1350, 10.6, 1.6, 130],
    ["Germany", "Sedan", 1550, 11.0, 2.0, 200], ["Germany", "SUV", 1900, 11.8, 3.0, 260],
    ["Germany", "Hatchback", 1300, 10.2, 1.4, 140], ["Germany", "Truck", 2100, 12.8, 3.0, 250],
    ["Korea", "Sedan", 1450, 10.8, 2.0, 160], ["Korea", "SUV", 1750, 11.5, 2.4, 190],
    ["Korea", "Hatchback", 1200, 10.0, 1.6, 125], ["Korea", "Truck", 2000, 12.5, 2.2, 185]
  ];

  function carRows() {
    const rows = [];
    let seed = 20261022;
    const rnd = () => {
      seed = (seed * 1103515245 + 12345) % 2147483648;
      return seed / 2147483648;
    };
    CAR_BASE.forEach(([Country, Type, w0, tc0, disp0, hp0]) => {
      for (let i = 0; i < 3; i++) {
        const j = (rnd() - 0.5) * 2;
        rows.push({
          Country, Type,
          "Weight": Math.round(w0 + j * 90),
          "Turning Circle": +(tc0 + (rnd() - 0.5) * 0.9).toFixed(1),
          "Displacement": +(disp0 + (rnd() - 0.5) * 0.5).toFixed(1),
          "Horsepower": Math.round(hp0 + j * 22)
        });
      }
    });
    return rows;
  }

  function buildDataset(name, rows) {
    const columns = inferColumns(rows);
    return { name, rows, columns, excluded: new Set() };
  }

  const SAMPLES = {
    "Big Class": () => buildDataset("Big Class", bigClassRows()),
    "能源流向（桑基圖）": () => buildDataset("能源流向", energyRows()),
    "汽車規格（多變數軸）": () => buildDataset("汽車規格", carRows()),
    "Weather (時間序列)": () => buildDataset("Weather", weatherRows()),
    "World Cities (地圖)": () => buildDataset("World Cities", cityRows())
  };

  function parseCSV(text) {
    const rows = [];
    let i = 0, field = "", row = [], inQuotes = false, prev = "";
    const pushField = () => { row.push(field); field = ""; };
    const pushRow = () => { pushField(); rows.push(row); row = []; };
    while (i < text.length) {
      const ch = text[i];
      if (inQuotes) {
        if (ch === '"' && text[i + 1] === '"') { field += '"'; i += 2; continue; }
        if (ch === '"') { inQuotes = false; i++; prev = ch; continue; }
        field += ch; i++; prev = ch; continue;
      }
      if (ch === '"') { inQuotes = true; i++; prev = ch; continue; }
      if (ch === ",") { pushField(); i++; prev = ch; continue; }
      if (ch === "\r") { i++; continue; }
      if (ch === "\n") { pushRow(); i++; prev = ch; continue; }
      field += ch; i++; prev = ch;
    }
    if (field.length || row.length) pushRow();
    const nonEmpty = rows.filter((r) => r.some((c) => c.trim() !== ""));
    if (!nonEmpty.length) return [];
    const header = nonEmpty[0].map((h, idx) => (h.trim() || `Col${idx + 1}`));
    return nonEmpty.slice(1).map((r) => {
      const o = {};
      header.forEach((h, idx) => {
        const v = r[idx];
        const n = v != null && v.trim() !== "" && isFinite(Number(v.replace(/,/g, ""))) ? Number(v.replace(/,/g, "")) : v;
        o[h] = v == null ? null : (typeof n === "number" ? n : v.trim() === "" ? null : v);
      });
      return o;
    });
  }

  function parseTSV(text) { return parseCSV(text.replace(/\t/g, ",")); }

  function autoKeys(columns) {
    const cont = columns.filter((c) => c.type === "continuous" && c.numFmt !== "date" && c.role === "measure").map((c) => c.key);
    const cats = columns.filter((c) => c.type !== "continuous").map((c) => c.key);
    const time = columns.filter((c) => c.role === "time").map((c) => c.key);
    const label = columns.filter((c) => c.role === "label").map((c) => c.key);
    const freq = columns.filter((c) => c.role === "freq").map((c) => c.key);
    const lat = columns.filter((c) => c.role === "lat").map((c) => c.key);
    const lon = columns.filter((c) => c.role === "lon").map((c) => c.key);
    return { cont, cats, time, label, freq, lat, lon };
  }

  global.GBData = { inferColumns, buildDataset, parseCSV, parseTSV, autoKeys, typedCopy, SAMPLES, numericOf, parseDateValue };
})(typeof window !== "undefined" ? window : globalThis);
