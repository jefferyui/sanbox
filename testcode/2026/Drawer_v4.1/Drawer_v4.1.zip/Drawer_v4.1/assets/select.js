/* GBSelect —— 跨圖連動框選（linked brushing）
   ------------------------------------------------------------------
   概念（對應 JMP 的 Box Select / Local Data Filter 的高亮行為）：
     1. 在**任何一張圖**（主圖或 ✨AI 卡片）用滑鼠拖出一個矩形＝框選（brush）。
     2. 框選結果是一份共用的「資料列索引」集合；所有圖共用同一份狀態。
     3. 有框選時：被框到的圖元保持鮮明（並加描邊），**沒框到的圖元一律變淡**，
        於是同一批資料在各種圖表上「落在哪一個區段」一眼就能看出來。
     4. 聚合圖元（長條、直方箱、熱圖格、馬賽克、桑基節點…）只要**含有一列**被框到就算被選到；
       其底部（或左側）會出現一條橘色**比例條**，代表這個圖元裡有多少比例的列被框選。

   这个檔案只管「選到哪些列 + 各圖怎麼顯示」，不重算統計（框選是高亮，不是排除）。
     - 拖曳＝框選（取代舊選取）｜Alt+拖曳＝加入選取｜Shift+拖曳＝從選取移除
     - 點一下空白處、Esc、或「清除框選」按鈕＝清除
   對應的圖元登記在 charts.js 各圖元的 ctx.sel(...)。
*/
(function (global) {
  "use strict";

  const SVGNS = "http://www.w3.org/2000/svg";
  const LIVE_CAP = 9000;          // 全部圖的圖元總數超過這個數：拖曳中不做即時預覽（放開滑鼠才套）

  const selSet = new Set();       // 目前框選到的資料列索引（row.__i）
  const charts = new Map();       // chartId -> { svg, label, rect:{fx,fy,fw,fh} }
  const listeners = new Set();
  let brushing = false;           // 正在拖矩形（用來暫停提示框）
  let sourceId = null;            // 框選來源圖（只有它顯示矩形）

  // ---------------- 小工具 ----------------
  function emit() { listeners.forEach((f) => { try { f(); } catch (e) { console.warn(e); } }); }
  function clamp01(v) { return Math.max(0, Math.min(1, v)); }

  function totalMarks() {
    let t = 0;
    charts.forEach((c) => { if (c.svg && c.svg.isConnected) t += (c.svg.__gbMarks || []).length; });
    return t;
  }
  function eachSvg(fn) {
    Array.from(charts.keys()).forEach((id) => {
      const c = charts.get(id);
      if (!c || !c.svg || !c.svg.isConnected) { charts.delete(id); return; }
      fn(c.svg, c);
    });
  }

  function userBox(svgEl) {
    let vb = null;
    try { vb = svgEl.viewBox && svgEl.viewBox.baseVal; } catch (e) { vb = null; }
    if (vb && vb.width > 0 && vb.height > 0) return { x: vb.x, y: vb.y, w: vb.width, h: vb.height };
    const r = svgEl.getBoundingClientRect();
    return { x: 0, y: 0, w: r.width || 800, h: r.height || 400 };
  }
  function clientToUser(svgEl, cx, cy) {
    let m = null;
    try { m = svgEl.getScreenCTM(); } catch (e) { m = null; }
    if (!m) return null;
    const inv = m.inverse();
    return { x: inv.a * cx + inv.c * cy + inv.e, y: inv.b * cx + inv.d * cy + inv.f };
  }
  // 把「元素自身座標系」的矩形，換算成螢幕（client）座標
  function localRectToClient(parentNode, x, y, w, h) {
    let m = null;
    try { m = parentNode.getScreenCTM(); } catch (e) { m = null; }
    if (!m) return null;
    const p1 = { x: m.a * x + m.c * y + m.e, y: m.b * x + m.d * y + m.f };
    const p2 = { x: m.a * (x + w) + m.c * (y + h) + m.e, y: m.b * (x + w) + m.d * (y + h) + m.f };
    return { x0: Math.min(p1.x, p2.x), y0: Math.min(p1.y, p2.y), x1: Math.max(p1.x, p2.x), y1: Math.max(p1.y, p2.y) };
  }
  function localPointToClient(parentNode, x, y) {
    let m = null;
    try { m = parentNode.getScreenCTM(); } catch (e) { m = null; }
    if (!m) return null;
    return { x: m.a * x + m.c * y + m.e, y: m.b * x + m.d * y + m.f };
  }

  // ---------------- 框選矩形（拖曳中的虛線框 + 保留在來源圖上的框） ----------------
  function brushLayer(svgEl) {
    let g = svgEl.__gbBrushLayer;
    if (!g || g.ownerSVGElement !== svgEl) {
      g = document.createElementNS(SVGNS, "g");
      g.setAttribute("class", "gb-brush-layer");
      g.setAttribute("pointer-events", "none");
      svgEl.appendChild(g);
      svgEl.__gbBrushLayer = g;
    }
    return g;
  }
  function setTempRect(svgEl, u) {
    const g = brushLayer(svgEl);
    let r = svgEl.__gbTempRect;
    if (!u) { if (r) { r.remove(); svgEl.__gbTempRect = null; } return; }
    if (!r) {
      r = document.createElementNS(SVGNS, "rect");
      r.setAttribute("class", "gb-brush-temp");
      g.appendChild(r);
      svgEl.__gbTempRect = r;
    }
    r.setAttribute("x", u.x0); r.setAttribute("y", u.y0);
    r.setAttribute("width", Math.max(0, u.x1 - u.x0)); r.setAttribute("height", Math.max(0, u.y1 - u.y0));
  }
  function paintKeepRect(svgEl, c) {
    let g = svgEl.__gbKeep;
    if (!g || g.ownerSVGElement !== svgEl) {
      g = document.createElementNS(SVGNS, "g");
      g.setAttribute("class", "gb-brush-keep");
      brushLayer(svgEl).appendChild(g);
      svgEl.__gbKeep = g;
    }
    while (g.firstChild) g.removeChild(g.firstChild);
    if (!c || !c.rect || !selSet.size) return;
    const b = userBox(svgEl);
    const x = b.x + c.rect.fx * b.w, y = b.y + c.rect.fy * b.h;
    const w = c.rect.fw * b.w, h = c.rect.fh * b.h;
    const r = document.createElementNS(SVGNS, "rect");
    r.setAttribute("class", "gb-brush-rect");
    r.setAttribute("x", x); r.setAttribute("y", y); r.setAttribute("width", Math.max(1, w)); r.setAttribute("height", Math.max(1, h));
    g.appendChild(r);
    const t = document.createElementNS(SVGNS, "text");
    t.setAttribute("class", "gb-brush-label");
    t.setAttribute("x", x + w / 2); t.setAttribute("y", Math.max(10, y - 4));
    t.setAttribute("text-anchor", "middle");
    t.textContent = "框選 " + selSet.size + " 列";
    g.appendChild(t);
  }

  // ---------------- 命中測試：矩形框到哪些資料列 ----------------
  function markHits(m, cRect, cache) {
    if (!m.kind || !m.parent) return false;
    if (m.kind === "path" && m.node && m.node.getTotalLength) {
      // 曲線（桑基色帶、圓餅切片）：沿路徑取樣，任一模點落在框內才算框到
      let L = 0;
      try { L = m.node.getTotalLength(); } catch (e) { return false; }
      if (!L) return false;
      const n = Math.max(6, Math.min(40, Math.round(L / 12)));
      for (let i = 0; i <= n; i++) {
        let p;
        try { p = m.node.getPointAtLength((L * i) / n); } catch (e) { return false; }
        const cp = localPointToClient(m.parent, p.x, p.y);
        if (cp && cp.x >= cRect.x0 && cp.x <= cRect.x1 && cp.y >= cRect.y0 && cp.y <= cRect.y1) return true;
      }
      return false;
    }
    let mtx = cache.get(m.parent);
    if (mtx === undefined) {
      try { mtx = m.parent.getScreenCTM(); } catch (e) { mtx = null; }
      cache.set(m.parent, mtx);
    }
    if (!mtx) return false;
    if (m.kind === "point") {
      const p = { x: mtx.a * m.x + mtx.c * m.y + mtx.e, y: mtx.b * m.x + mtx.d * m.y + mtx.f };
      // 點的半徑也算進去（小點好框）：用外掛的 r（像素）
      const rr = (m.r || 0) * Math.abs(mtx.a || 1) + 2;
      return p.x >= cRect.x0 - rr && p.x <= cRect.x1 + rr && p.y >= cRect.y0 - rr && p.y <= cRect.y1 + rr;
    }
    const cr = localRectToClient(m.parent, m.x, m.y, m.w, m.h);
    if (!cr) return false;
    return cr.x1 >= cRect.x0 && cr.x0 <= cRect.x1 && cr.y1 >= cRect.y0 && cr.y0 <= cRect.y1;
  }

  function rowsInRect(svgEl, cRect) {
    const marks = svgEl.__gbMarks || [];
    const cache = new Map();
    const out = new Set();
    for (let i = 0; i < marks.length; i++) {
      const m = marks[i];
      if (!markHits(m, cRect, cache)) continue;
      for (let j = 0; j < m.rows.length; j++) out.add(m.rows[j]);
    }
    return out;
  }

  // ---------------- 顯示：淡出未選取 / 高亮已選取 / 比例條 ----------------
  function noteText(m, active, n) {
    if (!active || !m.rows.length) return null;
    if (m.rows.length === 1) return (n ? "已框選" : "未框選") + "（列 #" + (m.rows[0] + 1) + "）";
    const pct = Math.round((n / m.rows.length) * 100);
    return "框選 " + n + " / " + m.rows.length + " 列（" + pct + "%）";
  }
  function removeFrac(m) { if (m.fracEl) { m.fracEl.remove(); m.fracEl = null; } }
  function drawFrac(m, frac) {
    if (!m.node || !m.node.parentNode || !m.anchor || !isFinite(m.w) || !isFinite(m.h)) { removeFrac(m); return; }
    if (frac == null || !(frac > 0.02) || frac > 0.985) { removeFrac(m); return; }
    let r = m.fracEl;
    if (!r) {
      r = document.createElementNS(SVGNS, "rect");
      r.setAttribute("class", "gb-frac");
      r.setAttribute("pointer-events", "none");
      m.node.parentNode.appendChild(r);
      m.fracEl = r;
    }
    const t = Math.max(2, Math.min(4, Math.min(m.w, m.h) * 0.22));
    if (m.anchor === "left") {
      r.setAttribute("x", m.x); r.setAttribute("y", m.y);
      r.setAttribute("width", t); r.setAttribute("height", Math.max(1, m.h * frac));
    } else {
      r.setAttribute("x", m.x); r.setAttribute("y", m.y + m.h - t);
      r.setAttribute("width", Math.max(1, m.w * frac)); r.setAttribute("height", t);
    }
  }

  function applyMark(m, active) {
    let n = 0;
    if (active) {
      for (let i = 0; i < m.rows.length; i++) if (selSet.has(m.rows[i])) n++;
    }
    // state: 0 沒框選｜1 有選到｜-1 沒選到（或純衍生圖形）
    const state = !active ? 0 : (m.decor ? -1 : (n > 0 ? 1 : -1));
    if (m.__state === state && m.__n === n) return;
    m.__state = state; m.__n = n;
    const cls = m.node && m.node.classList;
    if (cls) {
      cls.toggle("gb-dim", state === -1);
      cls.toggle("gb-lit", state === 1 && m.lit !== false);
    }
    if (m.node) m.node.__gbSelNote = noteText(m, active, n);
    drawFrac(m, state === 1 && !m.decor && m.rows.length > 1 ? n / m.rows.length : null);
  }

  function applyTo(svgEl) {
    if (!svgEl) return;
    const marks = svgEl.__gbMarks || [];
    const active = selSet.size > 0;
    for (let i = 0; i < marks.length; i++) applyMark(marks[i], active);
    paintKeepRect(svgEl, charts.get(svgEl.__gbChartId));
  }
  function applyAll() { eachSvg((svg) => applyTo(svg)); }

  // ---------------- 對外 API ----------------
  const api = {
    isOn() { return selSet.size > 0; },
    count() { return selSet.size; },
    rows() { return Array.from(selSet); },
    has(i) { return selSet.has(i); },
    brushing() { return brushing; },
    sourceId() { return sourceId; },
    sourceLabel() { const c = charts.get(sourceId); return c ? c.label : null; },
    onChange(f) { listeners.add(f); return () => listeners.delete(f); },

    // charts.js 每畫好一個圖元就登記一筆（圖元 ↔ 資料列）
    register(svgEl, mark) {
      if (!svgEl || !mark) return;
      if (!svgEl.__gbMarks) svgEl.__gbMarks = [];
      svgEl.__gbMarks.push(mark);
    },
    beginMarks(svgEl) { if (svgEl) { svgEl.__gbMarks = []; svgEl.__gbBrushLayer = null; svgEl.__gbTempRect = null; svgEl.__gbKeep = null; } },

    // 每張圖畫完時呼叫：綁定拖曳事件 + 重新套用目前的框選
    attach(svgEl, o) {
      if (!svgEl) return;
      o = o || {};
      const id = o.chartId || ("chart" + (charts.size + 1));
      const c = charts.get(id) || { rect: null };
      c.svg = svgEl; c.label = o.label || id; c.id = id;
      charts.set(id, c);
      svgEl.__gbChartId = id;
      bind(svgEl);
      applyTo(svgEl);
    },

    // 直接指定選取（給右鍵選單、未來的外掛用）
    setRows(list, srcId) {
      selSet.clear();
      (list || []).forEach((i) => selSet.add(i));
      sourceId = selSet.size ? (srcId || sourceId) : null;
      if (!selSet.size) charts.forEach((c) => { c.rect = null; });
      applyAll(); emit();
    },
    clear(silent) {
      if (!selSet.size && !sourceId) return;
      selSet.clear(); sourceId = null;
      charts.forEach((c) => { c.rect = null; });
      applyAll();
      if (!silent) emit();
    },
    reset() { api.clear(false); },
    applyAll
  };

  // ---------------- 拖曳框選引擎 ----------------
  function hasClickHandler(node, root) {
    let n = node;
    while (n && n !== root) {
      const on = n.__on;
      if (on) for (let i = 0; i < on.length; i++) if (on[i].typ === "click") return true;
      n = n.parentNode;
    }
    return false;
  }
  function suppressNextClick() {
    const h = (e) => {
      e.stopPropagation();
      if (e.preventDefault) e.preventDefault();
      window.removeEventListener("click", h, true);
    };
    window.addEventListener("click", h, true);
    setTimeout(() => window.removeEventListener("click", h, true), 400);
  }

  function commit(svgEl, cRect, mode, base) {
    const found = rowsInRect(svgEl, cRect);
    const next = mode === "set" ? new Set() : new Set(base);
    found.forEach((i) => { if (mode === "sub") next.delete(i); else next.add(i); });
    selSet.clear();
    next.forEach((i) => selSet.add(i));
    const b = userBox(svgEl);
    const u0 = clientToUser(svgEl, cRect.x0, cRect.y0);
    const u1 = clientToUser(svgEl, cRect.x1, cRect.y1);
    const c = charts.get(svgEl.__gbChartId);
    if (selSet.size && u0 && u1 && c) {
      c.rect = {
        fx: clamp01((u0.x - b.x) / b.w), fy: clamp01((u0.y - b.y) / b.h),
        fw: clamp01((u1.x - u0.x) / b.w), fh: clamp01((u1.y - u0.y) / b.h)
      };
      sourceId = svgEl.__gbChartId;
    } else {
      if (c) c.rect = null;
      sourceId = selSet.size ? sourceId : null;
    }
    applyAll();
  }

  function bind(svgEl) {
    if (svgEl.__gbBound) return;
    svgEl.__gbBound = true;

    svgEl.addEventListener("mousedown", (ev) => {
      if (ev.button !== 0 || ev.ctrlKey || ev.metaKey) return;
      const t = ev.target;
      if (t && t.closest && t.closest(".gb-brush-layer")) return;         // 框選矩形本身
      if (t && t.classList && t.closest && t.closest(".legend")) return;   // 圖例：點擊是隱藏群組
      // 關鍵：SVG 內容在 Chrome 会被當成可拖曳的物件（dragstart 會讓後面的 mousemove/mouseup 不再送進網頁），
      // 所以在 mousedown 就擋掉預設行為；「點一下圖元」改用下面手動補一個 click（preventDefault 不影響 click，但補發比較保險）。
      if (ev.preventDefault) ev.preventDefault();
      const clicked = t;
      const start = { x: ev.clientX, y: ev.clientY };
      let sawClick = false;
      const clickProbe = () => { sawClick = true; };
      window.addEventListener("click", clickProbe, true);
      const stopProbe = () => window.removeEventListener("click", clickProbe, true);
      const mode = ev.altKey ? "add" : ev.shiftKey ? "sub" : "set";
      const base = new Set(selSet);
      const canLive = totalMarks() <= LIVE_CAP;
      let moved = false, last = start;

      const onMove = (e2) => {
        last = { x: e2.clientX, y: e2.clientY };
        if (!moved && Math.abs(e2.clientX - start.x) + Math.abs(e2.clientY - start.y) < 4) return;
        moved = true;
        brushing = true;
        if (e2.preventDefault) e2.preventDefault();          // 不要順帶選取到網頁文字
        const cRect = {
          x0: Math.min(start.x, last.x), y0: Math.min(start.y, last.y),
          x1: Math.max(start.x, last.x), y1: Math.max(start.y, last.y)
        };
        const a = clientToUser(svgEl, cRect.x0, cRect.y0), z = clientToUser(svgEl, cRect.x1, cRect.y1);
        if (a && z) setTempRect(svgEl, { x0: a.x, y0: a.y, x1: z.x, y1: z.y });
        if (canLive) commit(svgEl, cRect, mode, base);
      };
      const onUp = (e2) => {
        window.removeEventListener("mousemove", onMove, true);
        window.removeEventListener("mouseup", onUp, true);
        brushing = false;
        setTempRect(svgEl, null);
        const target = e2.target || clicked;
        if (!moved) {
          if (hasClickHandler(target, svgEl)) {
            // 一般點擊落在圖元上：保留原本行為（點一下排除該列、點長條跳到該類別…）。
            // 上面的 preventDefault 在 Chrome 仍會派發 click；萬一沒有，才補發一個。
            setTimeout(() => {
              const native = sawClick;
              stopProbe();
              if (!native && target.dispatchEvent) {
                target.dispatchEvent(new MouseEvent("click", {
                  bubbles: true, cancelable: true, view: window,
                  clientX: e2.clientX, clientY: e2.clientY, button: 0
                }));
              }
            }, 0);
          } else {
            stopProbe();
            if (selSet.size) api.clear();      // 點在空白處＝清除框選
          }
          return;
        }
        stopProbe();
        const cRect = {
          x0: Math.min(start.x, e2.clientX), y0: Math.min(start.y, e2.clientY),
          x1: Math.max(start.x, e2.clientX), y1: Math.max(start.y, e2.clientY)
        };
        commit(svgEl, cRect, mode, base);
        suppressNextClick();
        emit();
      };
      window.addEventListener("mousemove", onMove, true);
      window.addEventListener("mouseup", onUp, true);
    });
  }

  global.GBSelect = api;
})(typeof window !== "undefined" ? window : globalThis);
