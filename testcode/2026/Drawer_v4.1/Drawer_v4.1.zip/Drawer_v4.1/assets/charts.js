/* Graph Builder — 圖元渲染器 + 座標軸/面板配置（d3 v7）
   每個圖元：GBElements.defs[id] = {label, short, render(ctx), defaults}
   ctx: {g, inner, rows, cfg, opt, scales, color, gkeys, tip, tipOff, ...}
*/
(function (global) {
  "use strict";

  const SQRT2PI = Math.sqrt(2 * Math.PI);
  const fmt = (v, d) => {
    if (v == null || !isFinite(v)) return "—";
    const p = d == null ? 4 : d;
    if (v !== 0 && (Math.abs(v) >= 1e5 || Math.abs(v) < 1e-3)) return d3.format(`.${Math.max(1, Math.min(6, p))}e`)(v);
    return d3.format(",." + (Number.isInteger(v) ? 0 : Math.min(2, p)) + "f")(v);
  };
  const fmtDate = (dt) => (dt instanceof Date ? d3.timeFormat("%Y-%m-%d")(dt) : String(dt));

  const palette = d3.quantize((t) => d3.hsl((210 + 360 * t) % 360, 0.5, 0.52), 12);
  function colorScale(keys) {
    const map = new Map();
    keys.forEach((k, i) => map.set(k, palette[i % palette.length]));
    return (k) => (k == null ? "#4c78a8" : map.get(String(k)) || "#4c78a8");
  }

  function uniqueStrings(vals) {
    const seen = new Set(), out = [];
    for (const v of vals) {
      const k = v == null || v === "" ? "(缺失)" : String(v);
      if (!seen.has(k)) { seen.add(k); out.push(k); }
    }
    return out;
  }

  function statFn(name) {
    const m = {
      mean: (v, w) => Stats.wmean(v, w),
      median: (v, w) => Stats.wquantile(v, w, 0.5),
      min: (v) => (v.length ? Stats.min(v) : null),
      max: (v) => (v.length ? Stats.max(v) : null),
      sum: (v, w) => v.reduce((a, x, i) => a + x * (w ? w[i] : 1), 0),
      stddev: (v, w) => Stats.wvariance(v, w).sd,
      stderr: (v, w) => Stats.meanCI(v, w, 0.95).se,
      n: (v, w) => (w ? Stats.wsum(v.map((x, i) => [x, w[i]])) : v.length)
    };
    return m[name] || m.mean;
  }
  const STAT_NAMES = { mean: "平均數", median: "中位數", min: "最小值", max: "最大值", sum: "總和", stddev: "標準差", stderr: "標準誤", n: "次數" };

  function dodgeOffset(gk, gkeys, bandPx) {
    if (!gkeys || gkeys.length < 2 || gk === "__all__") return { center: 0, width: 1 };
    const n = gkeys.length;
    const w = 0.82 / n;
    return { center: (gkeys.indexOf(gk) - (n - 1) / 2) * w * bandPx, width: w };
  }

  function vErrBar(g, cx, lo, hi, yScale, color) {
    if (lo == null || hi == null || !isFinite(lo) || !isFinite(hi)) return;
    const a = yScale(Math.min(lo, hi)), b = yScale(Math.max(lo, hi));
    g.append("line").attr("x1", cx).attr("x2", cx).attr("y1", a).attr("y2", b).attr("stroke", color).attr("stroke-width", 1.2);
    g.append("line").attr("x1", cx - 4).attr("x2", cx + 4).attr("y1", a).attr("y2", a).attr("stroke", color).attr("stroke-width", 1.2);
    g.append("line").attr("x1", cx - 4).attr("x2", cx + 4).attr("y1", b).attr("y2", b).attr("stroke", color).attr("stroke-width", 1.2);
  }

  // ==================== 圖元 ====================
  const defs = {};

  defs.points = {
    label: "點", short: "Points",
    defaults: { size: 3.5, opacity: 0.85, jitter: 0 },
    render(ctx) {
      const { g, rows, cfg, opt, scales, color } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!xCol || !yCol) return;
      const sizeCol = sizeColumnOf(cfg);
      const sizeVals = sizeCol ? ctx.numsOf(rows, sizeCol) : null;
      const sizeScale = sizeVals && sizeVals.length > 1 ? d3.scaleSqrt().domain(d3.extent(sizeVals)).range([2.5, 11]) : null;
      const xBandPx = scales.xBandWidth;

      for (const [gk, grows] of ctx.groups(rows)) {
        const c = color(gk);
        const off = ctx.dodge ? dodgeOffset(gk, ctx.gkeys, xBandPx).center : 0;
        const series = g.append("g").attr("class", "series").attr("data-group", gk);
        for (const r of grows) {
          const xv = xCol.values[r.__i], yv = yCol.values[r.__i];
          let px, py;
          if (ctx.xDisc) { const k = catForValue(scales, "x", xv); px = k == null ? null : scales.x(k) + scales.xBandWidth / 2; }
          else px = xv == null ? null : scales.x(+xv);
          if (ctx.yDisc) { const k = catForValue(scales, "y", yv); py = k == null ? null : scales.y(k) + scales.yBandWidth / 2; }
          else py = yv == null ? null : scales.y(+yv);
          if (px == null || py == null || !isFinite(px) || !isFinite(py)) continue;
          px += off;
          if (opt.jitter) {
            px += (pseudo(r.__i) - 0.5) * opt.jitter * 30;
            py += (pseudo(r.__i + 977) - 0.5) * opt.jitter * 30;
          }
          let rad = opt.size || 3.5;
          if (sizeScale) { const sv = +sizeCol.values[r.__i]; if (isFinite(sv)) rad = sizeScale(sv); }
          const ex = ctx.isExcluded(r);
          const dot = series.append("circle")
            .attr("cx", px).attr("cy", py).attr("r", ex ? 1.5 : rad)
            .attr("fill", ex ? "#ccd1d8" : c).attr("fill-opacity", ex ? 0.45 : opt.opacity)
            .attr("stroke", ex ? "#b6bcc6" : d3.color(c).darker(0.9).toString()).attr("stroke-width", 0.55)
            .style("cursor", "pointer")
            .on("mousemove", (ev) => ctx.tip(ev, ctx.rowTip(r)))
            .on("mouseleave", ctx.tipOff)
            .on("click", (ev) => { ev.stopPropagation(); ctx.toggleExclude(r.__i); });
          ctx.sel(dot, r, { kind: "point" });
        }
      }
    }
  };

  function pseudo(n) { const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }

  defs.line = {
    label: "線", short: "Line",
    defaults: { statistic: "mean", ci: false, ciLevel: 95, width: 1.9, showPoints: true, connect: "linear" },
    render(ctx) {
      const { g, rows, cfg, opt, scales, color } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!yCol || yCol.type !== "continuous") return;
      const stat = statFn(opt.statistic);
      const aggregate = ctx.xDisc && !ctx.xTime;
      for (const [gk, grows] of ctx.groups(rows)) {
        const c = color(gk);
        const pts = [];
        if (aggregate) {
          const byCat = new Map();
          for (const r of grows) {
            const k = xCol ? String(xCol.values[r.__i]) : "__all__";
            const yv = yCol.values[r.__i];
            if (yv == null || !isFinite(yv)) continue;
            if (!byCat.has(k)) byCat.set(k, { v: [], w: [], rows: [] });
            byCat.get(k).v.push(yv); byCat.get(k).w.push(ctx.freqW(r)); byCat.get(k).rows.push(r);
          }
          for (const cat of scales.x.domain()) {
            const cell = byCat.get(String(cat));
            if (!cell || !cell.v.length) continue;
            const ci = Stats.meanCI(cell.v, cell.w, opt.ciLevel / 100);
            pts.push({ px: scales.x(String(cat)) + scales.xBandWidth / 2, py: scales.y(stat(cell.v, cell.w)),
                       lo: ci.lo, hi: ci.hi, n: Stats.wsum(cell.v.map((a, i) => [a, cell.w[i]])), cat, value: stat(cell.v, cell.w), rows: cell.rows });
          }
        } else {
          for (const r of grows) {
            const xv = xCol ? xCol.values[r.__i] : null;
            const yv = yCol.values[r.__i];
            if (yv == null || !isFinite(yv)) continue;
            const px = ctx.xTime ? scales.x(xv instanceof Date ? xv : new Date(+xv)) : scales.x(+xv);
            if (px == null || !isFinite(px)) continue;
            pts.push({ px, py: scales.y(+yv), rawX: xv, value: +yv, n: ctx.freqW(r), rows: [r] });
          }
          pts.sort((a, b) => a.px - b.px);
        }
        if (pts.length < 1) continue;
        const curve = opt.connect === "step" ? d3.curveStepAfter : opt.connect === "smooth" ? d3.curveMonotoneX : d3.curveLinear;
        if (opt.ci && aggregate) {
          const band = pts.filter((p) => p.lo != null && p.hi != null);
          if (band.length > 1) ctx.sel(g.append("path")
            .attr("d", d3.area().x((d) => d.px).y0((d) => scales.y(d.lo)).y1((d) => scales.y(d.hi)).curve(d3.curveLinear)(band))
            .attr("class", "decor").attr("fill", c).attr("fill-opacity", 0.14), [], { decor: true, lit: false });
        }
        const errG = (opt.ci && aggregate) ? g.append("g") : null;
        if (pts.length > 1) ctx.sel(g.append("path")
          .attr("d", d3.line().x((d) => d.px).y((d) => d.py).curve(curve)(pts))
          .attr("fill", "none").attr("stroke", c).attr("stroke-width", opt.width)
          .attr("stroke-dasharray", opt.dash === "dashed" ? "5 3" : null), grows, { lit: false });
        if (opt.ci && aggregate) {
          for (const p of pts) vErrBar(errG, p.px, p.lo, p.hi, scales.y, d3.color(c).darker(0.8).toString());
          ctx.sel(errG, [], { decor: true, lit: false });
        }
        if (opt.showPoints) g.selectAll(null).data(pts).join("circle")
          .attr("cx", (d) => d.px).attr("cy", (d) => d.py).attr("r", aggregate ? 3.2 : 1.9)
          .attr("fill", c).attr("stroke", "#fff").attr("stroke-width", aggregate ? 0.8 : 0.4)
          .on("mousemove", (ev, d) => ctx.tip(ev,
            `${cfg.x ? cfg.x + "：" + (d.cat != null ? d.cat : (d.rawX instanceof Date ? fmtDate(d.rawX) : fmt(d.rawX))) : ""}\n` +
            `${cfg.color ? cfg.color + "：" + (gk === "__all__" ? "—" : gk) + "\n" : ""}` +
            `${STAT_NAMES[opt.statistic] || opt.statistic} = ${fmt(d.value)}   n = ${fmt(d.n)}`))
          .on("mouseleave", ctx.tipOff)
          .each(function (d) { ctx.sel(this, d.rows, { kind: "point" }); });
        else for (const p of pts) ctx.sel(null, p.rows, { kind: "point", x: p.px, y: p.py, r: 4, space: g, hitOnly: true });
      }
    }
  };

  defs.smoother = {
    label: "平滑器", short: "Smooth",
    defaults: { method: "loess", lambda: 0.05, band: true, ciLevel: 95, width: 2.4, showEquation: true },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales, color } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!xCol || !yCol || xCol.type !== "continuous" || yCol.type !== "continuous") {
        if (!ctx.small) note(g, inner, "平滑器需要兩個連續變數（X 與 Y）");
        return;
      }
      const level = opt.ciLevel / 100;
      const xd = scales.x.domain();
      const x0 = +xd[0], x1 = +xd[1];
      const evals = d3.range(70).map((i) => x0 + (x1 - x0) * i / 69);
      const toPx = (x) => scales.x(ctx.xTime ? new Date(x) : x);
      const notes = [];

      for (const [gk, grows] of ctx.groups(rows)) {
        const p = ctx.pairs(grows, xCol, yCol);
        if (p.xs.length < (opt.method === "linear" ? 3 : 6)) continue;
        const c = color(gk);
        let fitted = null, text = null;
        if (opt.method === "linear") {
          const fit = Stats.linreg(p.xs, p.ys, p.ws);
          if (!fit) continue;
          fitted = evals.map((x) => ({ x, y: fit.intercept + fit.slope * x, se: null }));
          text = `${cfg.y} = ${fmt(fit.intercept, 3)} ${fit.slope >= 0 ? "+" : "−"} ${fmt(Math.abs(fit.slope), 3)}·${cfg.x}   R²=${fmt(fit.r2, 3)}`;
        } else if (opt.method === "spline") {
          const lam = +opt.lambda;
          const xsSorted = p.xs.slice().sort((a, b) => a - b);
          const K = Math.max(4, Math.min(16, Math.round(Math.min(30, 1 / Math.max(0.02, lam)))));
          const knots = d3.range(K).map((i) => d3.quantile(xsSorted, (i + 1) / (K + 1)));
          fitted = Stats.smoothingSpline(p.xs, p.ys, p.ws, lam, knots, evals);
          text = `平滑樣條 λ=${lam}  結點=${K}  n=${p.xs.length}`;
        } else {
          const lam = +opt.lambda;
          const span = Math.max(0.12, Math.min(0.95, 0.95 - lam * 4));
          fitted = Stats.loess(p.xs, p.ys, p.ws, span, 1, evals);
          text = `LOESS λ=${lam} (span=${span.toFixed(2)})  n=${p.xs.length}`;
        }
        if (!fitted) continue;
        const clean = fitted.filter((d) => d.y != null && isFinite(d.y) && isFinite(toPx(d.x)) && isFinite(scales.y(d.y)));
        if (clean.length < 2) continue;
        if (opt.band) {
          const band = clean.filter((d) => d.se != null);
          if (band.length > 1) {
            const tc = Stats.tCrit(Math.max(2, (band[0].nEff || band.length) - 2), (1 + level) / 2);
            g.append("path")
              .attr("d", d3.area().x((d) => toPx(d.x)).y0((d) => scales.y(Math.max(0, d.y - tc * d.se))).y1((d) => scales.y(d.y + tc * d.se)).curve(d3.curveMonotoneX)(band))
              .attr("fill", c).attr("class", "decor").attr("fill-opacity", 0.13);
          }
        }
        g.append("path")
          .attr("d", d3.line().x((d) => toPx(d.x)).y((d) => scales.y(d.y)).curve(d3.curveMonotoneX)(clean))
          .attr("fill", "none").attr("stroke", c).attr("stroke-width", opt.width)
          .attr("stroke-dasharray", opt.method === "linear" ? "7 3" : null);
        notes.push({ gk, text });
      }
      if (opt.showEquation && notes.length && !ctx.small) {
        const box = g.append("g").attr("class", "fit-notes").attr("transform", `translate(${inner.w - 6},6)`);
        box.append("rect").attr("x", -172).attr("y", 0).attr("width", 176).attr("height", notes.length * 14 + 8)
          .attr("fill", "#ffffff").attr("fill-opacity", 0.82).attr("stroke", "#e2e6ec").attr("rx", 3);
        notes.forEach((n, i) => {
          const t = box.append("text").attr("class", "fit-note-text").attr("x", -4).attr("y", i * 14 + 13).attr("text-anchor", "end").text(n.text);
          if (n.gk !== "__all__") t.append("tspan").attr("fill", color(n.gk)).text(" ●");
        });
      }
    }
  };

  function note(g, inner, text) {
    g.append("text").attr("class", "fit-note-text").attr("x", inner.w / 2).attr("y", inner.h / 2).attr("text-anchor", "middle").text(text);
  }

  defs.box = {
    label: "箱形圖", short: "Box",
    defaults: { whisker: "1.5", outliers: true, ciMean: 95, fillOpacity: 0.28, showMean: true },
    render(ctx) {
      const { g, rows, cfg, opt, scales, color, inner } = ctx;
      // 決定方向：類別在 X → 直立；類別在 Y → 橫式；兩軸皆連續 → 直立單一群組（由 Color 區分）
      const horiz = !ctx.xDisc && ctx.yDisc;
      const catCol = horiz ? cfg.yCol : (ctx.xDisc ? cfg.xCol : null);
      const valCol = horiz ? cfg.xCol : (ctx.xDisc ? cfg.yCol : (cfg.yCol && cfg.yCol.type === "continuous" ? cfg.yCol : cfg.xCol));
      if (!valCol || valCol.type !== "continuous") { if (!ctx.small) note(g, inner, "箱形圖需要一個連續變數（Y 或 X）與一個類別變數"); return; }

      const vS = horiz ? scales.x : scales.y;             // 數值軸（像素）
      const catScale = horiz ? scales.y : scales.x;       // 類別軸
      const singleCat = !catCol;
      const cats = singleCat ? [valCol.key] : ((catScale.__cats) || catScale.domain().map(String));
      const bandPx = singleCat ? (horiz ? inner.h : inner.w) : (horiz ? scales.yBandWidth : scales.xBandWidth);
      const nG = ctx.gkeys.length > 1 && ctx.gkeys[0] !== "__all__" ? ctx.gkeys.length : 1;
      const boxThick = Math.max(4, bandPx * 0.7 / nG);
      const level = (opt.ciMean || 95) / 100;

      const catCenter = (cat) => singleCat ? (horiz ? inner.h / 2 : inner.w / 2) : catScale(cat) + bandPx / 2;
      const pos = (val, center) => horiz ? [vS(val), center] : [center, vS(val)];

      for (const [gk, grows] of ctx.groups(rows)) {
        const c = color(gk);
        const gi = ctx.gkeys.indexOf(gk);
        const shift = (singleCat || nG === 1) ? 0 : (gi - (nG - 1) / 2) * boxThick;
        for (const cat of cats) {
          const v = [], w = [], rowAt = [];
          for (const r of grows) {
            if (catCol) { const k = catForValue(scales, horiz ? "y" : "x", catCol.values[r.__i]); if (k !== cat) continue; }
            const val = valCol.values[r.__i];
            if (typeof val === "number" && isFinite(val)) { v.push(val); w.push(ctx.freqW(r)); rowAt.push(r); }
          }
          if (v.length < 2) continue;
          const q1 = Stats.wquantile(v, w, 0.25), q2 = Stats.wquantile(v, w, 0.5), q3 = Stats.wquantile(v, w, 0.75);
          const iqr = q3 - q1;
          let loF, hiF;
          if (opt.whisker === "minmax") { loF = Stats.min(v); hiF = Stats.max(v); }
          else { const k = +opt.whisker; loF = q1 - k * iqr; hiF = q3 + k * iqr; }
          const inside = v.filter((x) => x >= loF && x <= hiF);
          const wLo = inside.length ? Stats.min(inside) : q1, wHi = inside.length ? Stats.max(inside) : q3;
          const center = catCenter(cat) + (horiz ? shift : 0);
          const cross = horiz ? "y" : "x";
          const grp = g.append("g").attr("class", "box");
          const line = (a, b) => grp.append("line").attr("x1", a[0]).attr("y1", a[1]).attr("x2", b[0]).attr("y2", b[1])
            .attr("stroke", c).attr("stroke-width", 1.1);
          line(pos(q1, center), pos(wLo, center));
          line(pos(q3, center), pos(wHi, center));
          const half = boxThick * 0.24;
          [[wLo], [wHi]].forEach(([val]) => {
            const pt = pos(val, center);
            if (horiz) grp.append("line").attr("x1", pt[0]).attr("x2", pt[0]).attr("y1", center - half).attr("y2", center + half).attr("stroke", c);
            else grp.append("line").attr("x1", center - half).attr("x2", center + half).attr("y1", pt[1]).attr("y2", pt[1]).attr("stroke", c);
          });
          const a = pos(q1, center), b = pos(q3, center);
          const rx = Math.min(a[0], b[0]), ry = Math.min(a[1], b[1]);
          const rw = horiz ? Math.max(2, Math.abs(b[0] - a[0])) : boxThick;
          const rh = horiz ? boxThick : Math.max(2, Math.abs(b[1] - a[1]));
          const rectEl = grp.append("rect")
            .attr("x", horiz ? rx : center - boxThick / 2).attr("y", horiz ? center - boxThick / 2 : ry)
            .attr("width", rw).attr("height", rh)
            .attr("fill", c).attr("fill-opacity", opt.fillOpacity).attr("stroke", c).attr("stroke-width", 1.1);
          const m = pos(q2, center);
          if (horiz) grp.append("line").attr("x1", m[0]).attr("x2", m[0]).attr("y1", center - boxThick / 2).attr("y2", center + boxThick / 2).attr("stroke", c).attr("stroke-width", 2.4);
          else grp.append("line").attr("x1", center - boxThick / 2).attr("x2", center + boxThick / 2).attr("y1", m[1]).attr("y2", m[1]).attr("stroke", c).attr("stroke-width", 2.4);
          const ci = Stats.meanCI(v, w, level);
          if (opt.showMean && ci.mean != null) {
            const p = pos(ci.mean, center), rr = 4;
            grp.append("path").attr("d", `M${p[0]},${p[1] - rr}L${p[0] + rr},${p[1]}L${p[0]},${p[1] + rr}L${p[0] - rr},${p[1]}Z`)
              .attr("fill", "#fff").attr("stroke", c).attr("stroke-width", 1.2);
            if (opt.ciMean && ci.lo != null && !horiz) vErrBar(grp, center, ci.lo, ci.hi, scales.y, d3.color(c).darker(1).toString());
          }
          if (opt.outliers !== false) {
            v.forEach((x, i) => {
              if (x >= loF && x <= hiF) return;
              const p = pos(x, center);
              ctx.sel(grp.append("circle").attr("cx", p[0]).attr("cy", p[1]).attr("r", 2.5)
                .attr("fill", "none").attr("stroke", c).attr("stroke-width", 0.9), rowAt[i], { kind: "point" });
            });
          }
          // 滑鼠提示區（涵蓋整個箱形圖）
          const ext = [pos(Stats.min(v), center), pos(Stats.max(v), center)];
          grp.append("rect")
            .attr("x", horiz ? Math.min(ext[0][0], ext[1][0]) : center - boxThick / 2)
            .attr("y", horiz ? center - boxThick / 2 : Math.min(ext[0][1], ext[1][1]))
            .attr("width", horiz ? Math.abs(ext[1][0] - ext[0][0]) : boxThick)
            .attr("height", horiz ? boxThick : Math.abs(ext[1][1] - ext[0][1]))
            .attr("fill", "transparent").style("cursor", "help")
            .on("mousemove", (ev) => ctx.tip(ev,
              `${cat}${singleCat || gk === "__all__" ? "" : " · " + cfg.color + "：" + gk}\nQ1 = ${fmt(q1)}   中位數 = ${fmt(q2)}   Q3 = ${fmt(q3)}\nIQR = ${fmt(iqr)}   平均數 = ${fmt(ci.mean)}\n95% 平均數 CI = [${fmt(ci.lo)}, ${fmt(ci.hi)}]\n鬚 = [${fmt(wLo)}, ${fmt(wHi)}]   n = ${fmt(Stats.wsum(v.map((x, i) => [x, w[i]])))}`))
            .on("mouseleave", ctx.tipOff);
          // 整個箱子＝這組資料列（框選時只要有一列被選到就不淡；底部比例條顯示比例）
          ctx.sel(grp, rowAt, { kind: "area", anchor: horiz ? "left" : "bottom", lit: false });
        }
      }
    }
  };

  defs.bar = {
    label: "長條圖", short: "Bar",
    defaults: { statistic: "mean", ci: true, ciLevel: 95, stack: "side", label: false, fillOpacity: 0.85 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales, color } = ctx;
      const catCol = cfg.xCol, valCol = cfg.yCol;
      if (!catCol || !ctx.xDisc) { if (!ctx.small) note(g, inner, "長條圖需要類別變數在 X 軸"); return; }
      const isCount = !valCol || valCol.type !== "continuous";
      const cats = scales.x.domain().map(String);
      const stacked = opt.stack === "stack";
      const stat = statFn(opt.statistic);
      const level = opt.ciLevel / 100;
      const acc = new Map(cats.map((c) => [c, 0]));

      for (const [gk, grows] of ctx.groups(rows)) {
        const c = color(gk);
        for (const cat of cats) {
          const sub = grows.filter((r) => String(catCol.values[r.__i]) === cat);
          if (!sub.length) continue;
          let value = null, lo = null, hi = null, n = Stats.wsum(sub.map((r) => [1, ctx.freqW(r)]));
          if (!isCount) {
            const v = [], w = [];
            sub.forEach((r) => { const yv = valCol.values[r.__i]; if (typeof yv === "number" && isFinite(yv)) { v.push(yv); w.push(ctx.freqW(r)); } });
            if (!v.length) continue;
            value = stat(v, w);
            n = Stats.wsum(v.map((a, i) => [a, w[i]]));
            if (opt.ci && (opt.statistic || "mean") === "mean") { const ci = Stats.meanCI(v, w, level); lo = ci.lo; hi = ci.hi; }
          } else value = n;
          if (value == null || !isFinite(value)) continue;
          const bandPx = scales.xBandWidth;
          const dodge = stacked ? { center: 0 } : dodgeOffset(gk, ctx.gkeys, bandPx);
          const bw = Math.max(2, stacked ? bandPx : bandPx * (ctx.gkeys.length > 1 ? 0.8 / ctx.gkeys.length : 0.8));
          const base = stacked ? acc.get(cat) : 0;
          const yTop = scales.y(stacked ? base + value : value);
          const yBase = scales.y(stacked ? base : (ctx.yHasZero ? 0 : d3.min(scales.y.domain())));
          ctx.sel(g.append("rect")
            .attr("x", scales.x(cat) + (bandPx - bw) / 2 + (stacked ? 0 : dodge.center - (ctx.gkeys.length > 1 ? dodge.center : 0)))
            .attr("y", Math.min(yTop, yBase)).attr("width", bw).attr("height", Math.max(1, Math.abs(yBase - yTop)))
            .attr("fill", c).attr("fill-opacity", opt.fillOpacity).attr("stroke", d3.color(c).darker(0.7).toString()).attr("stroke-width", 0.7)
            .style("cursor", "pointer")
            .on("mousemove", (ev) => ctx.tip(ev,
              `${cfg.x}：${cat}${gk === "__all__" ? "" : "\n" + cfg.color + "：" + gk}\n${isCount ? "次數 = " + fmt(value) : (STAT_NAMES[opt.statistic] || opt.statistic) + " = " + fmt(value)}\nn = ${fmt(n)}`))
            .on("mouseleave", ctx.tipOff)
            .on("click", (ev) => { ev.stopPropagation(); ctx.highlightCategory(cfg.x, cat); }), sub, { kind: "area", anchor: "bottom" });
          if (opt.ci && lo != null && !stacked) {
            const cx = scales.x(cat) + bandPx / 2 + (ctx.gkeys.length > 1 ? dodge.center : 0);
            const eg = g.append("g");
            vErrBar(eg, cx, lo, hi, scales.y, d3.color(c).darker(1.1).toString());
            ctx.sel(eg, sub, { lit: false });
          }
          if (opt.label) ctx.sel(g.append("text").attr("class", "bar-label")
            .attr("x", scales.x(cat) + bandPx / 2).attr("y", Math.min(yTop, yBase) - 3).attr("text-anchor", "middle").text(fmt(value)), sub, { lit: false });
          if (stacked) acc.set(cat, base + value);
        }
      }
    }
  };

  defs.histogram = {
    label: "直方圖", short: "Histogram",
    defaults: { binRule: "sturges", bins: 0, density: false, stack: "overlay", fillOpacity: 0.75 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales, color } = ctx;
      if (cfg.histSuppressed) { if (!ctx.small) note(g, inner, "直方圖只在單一變數（或只選直方圖）時顯示；請取消其他圖元或只用一個變數"); return; }
      const valueAxis = cfg.histOn === "y" ? "y" : "x";           // 值軸
      const col = valueAxis === "y" ? cfg.yCol : cfg.xCol;
      if (!col || col.type === "nominal") { if (!ctx.small) note(g, inner, "直方圖需要連續或序號變數"); return; }
      const countAxis = valueAxis === "y" ? "x" : "y";
      const vals = ctx.numsOf(rows, col);
      if (!vals.length) return;
      const [lo, hi] = scales[col === cfg.xCol ? "x" : "y"].domain();
      const k = opt.bins > 0 ? +opt.bins : Stats.binCount(vals, null, opt.binRule === "auto" ? "fd" : opt.binRule);
      const binW = (hi - lo) / k;
      const stacked = opt.stack === "stack";
      const groups = ctx.groups(rows);
      const binsPer = new Map();
      const rowsPer = new Map();                 // 每個 (群組, bin) 含哪些資料列（跨圖框選用）
      const binW2 = (hi - lo) / k || 1;
      const totals = new Array(k).fill(0);
      for (const [gk, grows] of groups) {
        const v = [], w = [];
        const binRows = Array.from({ length: k }, () => []);
        grows.forEach((r) => {
          const x = col.values[r.__i];
          if (typeof x === "number" && isFinite(x)) {
            v.push(x);
            const wt = ctx.freqW(r);
            w.push(wt);
            if (wt > 0) {
              let bi = Math.floor((x - lo) / binW2);
              bi = bi < 0 ? 0 : bi >= k ? k - 1 : bi;
              binRows[bi].push(r);
            }
          }
        });
        binsPer.set(gk, Stats.histBins(v, w, lo, hi, k));
        rowsPer.set(gk, binRows);
      }
      if (stacked) for (let i = 0; i < k; i++) for (const [, bins] of binsPer) totals[i] += bins[i].count;
      let maxCount = 0;
      for (let i = 0; i < k; i++) maxCount = Math.max(maxCount, stacked ? totals[i] : Math.max(...Array.from(binsPer.values()).map((b) => b[i].count)));
      // 若計數軸沒有對應變數，用 scales[countAxis]（app 端已建為計數尺度）
      const vS = scales[valueAxis], cS = scales[countAxis];
      const cDomainHi = cS.domain ? Math.max(...cS.domain()) : maxCount;
      const scaleCount = (count) => cS(stacked || !opt.density ? count : count);

      let stackBase = new Array(k).fill(0);
      for (const [gk, bins] of binsPer) {
        const c = color(gk);
        bins.forEach((b, i) => {
          const count = stacked ? totals[i] : b.count;
          if (!(count > 0)) return;
          const v0 = vS(b.x0), v1 = vS(b.x0 + binW);
          let rect;
          if (valueAxis === "x") {
            const yTop = cS(stacked ? stackBase[i] + count : count);
            const yBase = cS(stacked ? stackBase[i] : 0);
            rect = g.append("rect").attr("x", Math.min(v0, v1) + 0.5).attr("y", Math.min(yTop, yBase))
              .attr("width", Math.max(1, Math.abs(v1 - v0) - 1)).attr("height", Math.max(1, Math.abs(yBase - yTop)));
          } else {
            const xEnd = cS(stacked ? stackBase[i] + count : count);
            const xBase = cS(stacked ? stackBase[i] : 0);
            rect = g.append("rect").attr("x", Math.min(xBase, xEnd)).attr("y", Math.min(v0, v1) + 0.5)
              .attr("width", Math.max(1, Math.abs(xEnd - xBase))).attr("height", Math.max(1, Math.abs(v1 - v0) - 1));
          }
          rect.attr("fill", c)
            .attr("fill-opacity", !stacked && groups.size > 1 ? 0.42 : opt.fillOpacity)
            .attr("stroke", d3.color(c).darker(0.6).toString()).attr("stroke-width", 0.55)
            .on("mousemove", (ev) => ctx.tip(ev, `[${fmt(b.x0)}, ${fmt(b.x0 + binW)})\n${gk === "__all__" ? "全部" : cfg.color + "：" + gk}\n次數 = ${fmt(count)}`))
            .on("mouseleave", ctx.tipOff);
          const binRows = stacked
            ? Array.from(rowsPer.values()).reduce((a, br) => a.concat(br[i] || []), [])
            : (rowsPer.get(gk)[i] || []);
          ctx.sel(rect, binRows, { kind: "area", anchor: valueAxis === "x" ? "bottom" : "left" });
          if (stacked) stackBase[i] += b.count;
        });
        if (opt.density) {
          const grows = groups.get(gk);
          const v = [], w = [];
          grows.forEach((r) => { const x = col.values[r.__i]; if (typeof x === "number" && isFinite(x)) { v.push(x); w.push(ctx.freqW(r)); } });
          if (v.length < 4) continue;
          const sd = Stats.wvariance(v, w).sd || 1;
          const nEff = Math.max(2, Stats.wsum(v.map((a, i) => [a, w[i]])));
          const bwv = Math.max(1e-9, 1.06 * sd * Math.pow(nEff, -0.2)) * (opt.densityBandwidth || 1);
          const evals = d3.range(90).map((i) => lo + (hi - lo) * i / 89);
          const dens = evals.map((x) => {
            let s = 0;
            for (let i = 0; i < v.length; i++) s += w[i] * Math.exp(-0.5 * Math.pow((x - v[i]) / bwv, 2));
            return [x, s / (nEff * bwv * SQRT2PI)];
          });
          const maxD = Math.max(...dens.map((d) => d[1])) || 1;
          // 把密度曲線縮放到「最大分箱計數」，可與直方圖直接比較
          const pts = dens.map((d) => [d[0], (d[1] / maxD) * maxCount]);
          ctx.sel(g.append("path")
            .attr("d", valueAxis === "x"
              ? d3.line().x((d) => vS(d[0])).y((d) => cS(d[1])).curve(d3.curveMonotoneX)(pts)
              : d3.line().x((d) => cS(d[1])).y((d) => vS(d[0])).curve(d3.curveMonotoneX)(pts))
            .attr("fill", "none").attr("stroke", d3.color(c).darker(1).toString()).attr("stroke-width", 2), grows, { lit: false });
        }
      }
      if (!ctx.small) {
        const ruleNames = { sturges: "Sturges", fd: "Freedman–Diaconis", sqrt: "平方根", manual: "自訂", auto: "自動 (F–D)" };
        g.append("text").attr("class", "fit-note-text").attr("x", valueAxis === "x" ? 4 : inner.w - 4)
          .attr("y", 12).attr("text-anchor", valueAxis === "x" ? "start" : "end")
          .text(`分箱數 ${k}（${ruleNames[opt.binRule] || opt.binRule}），箱寬 ${fmt(binW)}`);
      }
    }
  };

  defs.heatmap = {
    label: "熱圖", short: "Heatmap",
    defaults: { statistic: "n", showValues: true, colorMap: "YlOrRd", nx: 20, ny: 16 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!xCol || !yCol) { if (!ctx.small) note(g, inner, "熱圖需要兩個變數（X 與 Y）"); return; }
      let bothDisc;
      const stat = statFn(opt.statistic === "n" ? "n" : opt.statistic);
      const interp = { YlOrRd: d3.interpolateYlOrRd, Viridis: d3.interpolateViridis, Blues: d3.interpolateBlues, Turbo: d3.interpolateTurbo, RdYlGn: d3.interpolateRdYlGn }[opt.colorMap] || d3.interpolateYlOrRd;
      const cells = [];
      let fx, fy, fw, fh, tipKind = "disc";
      const kHint = (v, dflt) => Math.max(2, Math.min(16, Math.round(v || dflt)));
      const bandLabel = (dom, i, k) => `${fmt(dom[0] + i * (dom[1] - dom[0]) / k, 1)}–${fmt(dom[0] + (i + 1) * (dom[1] - dom[0]) / k, 1)}`;

      const xBand = !!scales.x.__cats, yBand = !!scales.y.__cats;
      if (xBand || yBand || (xCol.type !== "continuous") || (yCol.type !== "continuous")) {
        // 至少一軸可分類 → 類別 × 類別（連續軸自動分帶）
        bothDisc = true;
        const kx = kHint(opt.nx, 12), ky = kHint(opt.ny, 10);
        const xdom = xBand ? null : scales.x.domain(), ydom = yBand ? null : scales.y.domain();
        const xk = xBand ? scales.x.__cats.slice() : Array.from({ length: kx }, (_, i) => bandLabel(xdom, i, kx));
        const yk = yBand ? scales.y.__cats.slice() : Array.from({ length: ky }, (_, i) => bandLabel(ydom, i, ky));
        const keyOf = (which, col, v, dom, k, cats) => {
          if ((which === "x" ? xBand : yBand)) return catForValue(scales, which, v);
          return (typeof v === "number" && isFinite(v)) ? cats[catKeyOfLinear(v, dom, k)] : null;
        };
        const map = new Map();
        for (const r of rows) {
          const ax = keyOf("x", xCol, xCol.values[r.__i], xdom, kx, xk);
          const ay = keyOf("y", yCol, yCol.values[r.__i], ydom, ky, yk);
          if (ax == null || ay == null) continue;
          const key = ax + "\u0001" + ay;
          let cur = map.get(key);
          if (!cur) { cur = { v: [], n: 0, rows: [] }; map.set(key, cur); }
          if (opt.statistic !== "n") { const yv = yCol.values[r.__i]; if (typeof yv === "number") cur.v.push(yv); }
          cur.n += ctx.freqW(r);
          cur.rows.push(r);
        }
        for (const a of xk) for (const b of yk) {
          const cur = map.get(a + "\u0001" + b);
          cells.push({ x: a, y: b, value: cur ? (cur.v.length ? stat(cur.v, cur.v.map(() => 1)) : cur.n) : null, rows: cur ? cur.rows : [] });
        }
        // 回傳該類別在像素上的起點與終點（band、分帶、或線性軸皆可）
        const edges = (which, lab) => {
          const sc = which === "x" ? scales.x : scales.y;
          if (sc.bandwidth) { const a = sc(lab); const b = a + sc.bandwidth(); return [Math.min(a, b), Math.max(a, b)]; }
          const parts = String(lab).split("\u2013");
          const lo = +(parts[0] || NaN), hi = +(parts[1] || NaN);
          const a = sc(lo), b = sc(hi);
          return [Math.min(a, b), Math.max(a, b)];
        };
        const e0 = edges("x", xk[0]); fw = (e0[1] - e0[0]) || inner.w / Math.max(1, xk.length);
        const e1 = edges("y", yk[0]); fh = (e1[1] - e1[0]) || inner.h / Math.max(1, yk.length);
        fx = (d) => edges("x", d.x)[0];
        fy = (d) => edges("y", d.y)[0];
        tipKind = "cats";
      } else {
        // 兩軸皆連續 → 規則網格
        bothDisc = false;
        const nx = kHint(opt.nx, 20), ny = kHint(opt.ny, 16);
        const [xlo, xhi] = scales.x.domain(), [ylo, yhi] = scales.y.domain();
        const wx = (xhi - xlo) / nx, wy = (yhi - ylo) / ny;
        const grid = Array.from({ length: ny }, () => Array.from({ length: nx }, () => ({ v: [], n: 0, rows: [] })));
        for (const r of rows) {
          const xv = xCol.values[r.__i], yv = yCol.values[r.__i];
          if (typeof xv !== "number" || typeof yv !== "number") continue;
          const ix = Math.min(nx - 1, Math.max(0, Math.floor((xv - xlo) / wx)));
          const iy = Math.min(ny - 1, Math.max(0, Math.floor((yv - ylo) / wy)));
          const cell = grid[iy][ix];
          cell.n += ctx.freqW(r);
          cell.rows.push(r);
          if (opt.statistic !== "n") cell.v.push(yv);
        }
        for (let iy = 0; iy < ny; iy++) for (let ix = 0; ix < nx; ix++) {
          const cell = grid[iy][ix];
          cells.push({ ix, iy, value: cell.n > 0 ? (opt.statistic === "n" ? cell.n : stat(cell.v, cell.v.map(() => 1))) : null,
                       bx0: xlo + ix * wx, by0: ylo + iy * wy, bx1: xlo + (ix + 1) * wx, by1: ylo + (iy + 1) * wy, rows: cell.rows });
        }
        fw = inner.w / nx; fh = inner.h / ny;
        fx = (d) => d.ix * fw; fy = (d) => inner.h - (d.iy + 1) * fh;
        tipKind = "grid";
      }

      const vals = cells.map((d) => d.value).filter((v) => v != null && isFinite(v));
      const dmin = vals.length ? Stats.min(vals) : 0, dmax = vals.length ? Stats.max(vals) : 1;
      const sc = d3.scaleSequential(interp).domain(dmin === dmax ? [0, dmax || 1] : [dmin, dmax]);
      const layer = g.append("g");
      layer.selectAll("rect").data(cells.filter((d) => d.value != null)).join("rect")
        .attr("x", (d) => fx(d)).attr("y", (d) => fy(d)).attr("width", Math.max(1, fw - 0.5)).attr("height", Math.max(1, fh - 0.5))
        .attr("fill", (d) => sc(d.value)).attr("stroke", "#fff").attr("stroke-width", bothDisc ? 0.6 : 0)
        .on("mousemove", (ev, d) => ctx.tip(ev, tipKind === "cats"
          ? `${cfg.x}：${d.x}\n${cfg.y}：${d.y}\n${opt.statistic === "n" ? "次數" : STAT_NAMES[opt.statistic]} = ${fmt(d.value)}`
          : `${cfg.x} ∈ [${fmt(d.bx0)}, ${fmt(d.bx1)})\n${cfg.y} ∈ [${fmt(d.by0)}, ${fmt(d.by1)})\n${opt.statistic === "n" ? "次數" : STAT_NAMES[opt.statistic]} = ${fmt(d.value)}`))
        .on("mouseleave", ctx.tipOff)
        .each(function (d) { ctx.sel(this, d.rows, { kind: "area", anchor: "bottom" }); });
      if (opt.showValues && bothDisc && fw > 26 && fh > 15) {
        layer.selectAll("text").data(cells.filter((d) => d.value != null)).join("text")
          .attr("class", "cell-label").attr("x", (d) => fx(d) + fw / 2).attr("y", (d) => fy(d) + fh / 2 + 3)
          .attr("text-anchor", "middle").attr("fill", (d) => (d.value - dmin) / ((dmax - dmin) || 1) > 0.62 ? "#fff" : "#222")
          .text((d) => fmt(d.value, 2))
          .each(function (d) { ctx.sel(this, d.rows, { lit: false }); });
      }
      if (!ctx.small) {
        const lw = 130, lh = 9;
        const gid = "hm_grad_" + Math.random().toString(36).slice(2, 7);
        const lg = g.append("defs").append("linearGradient").attr("id", gid);
        d3.range(0, 1.001, 0.1).forEach((t) => lg.append("stop").attr("offset", t * 100 + "%").attr("stop-color", sc(dmin + t * (dmax - dmin))));
        const lgG = g.append("g").attr("transform", `translate(6,14)`);
        lgG.append("rect").attr("width", lw).attr("height", lh).attr("fill", `url(#${gid})`).attr("stroke", "#c3c8d0");
        lgG.append("text").attr("class", "legend-text").attr("y", -3).text(fmt(dmin, 2));
        lgG.append("text").attr("class", "legend-text").attr("x", lw).attr("y", -3).attr("text-anchor", "end").text(fmt(dmax, 2));
      }
    }
  };

  defs.contour = {
    label: "等高線圖", short: "Contour",
    defaults: { levels: 7, fill: true, fillOpacity: 0.32, bandwidth: 1, showPoints: true, grid: 44 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!xCol || !yCol || xCol.type !== "continuous" || yCol.type !== "continuous") {
        if (!ctx.small) note(g, inner, "等高線圖需要兩個連續變數（X 與 Y）");
        return;
      }
      const p = ctx.pairs(rows, xCol, yCol);
      if (p.xs.length < 8) { if (!ctx.small) note(g, inner, "資料點太少，無法估計密度"); return; }
      const [xlo, xhi] = scales.x.domain(), [ylo, yhi] = scales.y.domain();
      const gx = +opt.grid, gy = Math.max(12, Math.round(+opt.grid * inner.h / inner.w));
      const sdX = Stats.wvariance(p.xs, p.ws).sd || 1, sdY = Stats.wvariance(p.ys, p.ws).sd || 1;
      const nEff = Math.max(4, Stats.wsum(p.xs.map((a, i) => [a, p.ws[i]])));
      const mult = +opt.bandwidth || 1;
      const grid = Stats.kde2d(p.xs, p.ys, p.ws, [xlo, xhi], [ylo, yhi], gx, gy,
        [Math.max(1e-9, mult * 1.06 * sdX * Math.pow(nEff, -0.2)), Math.max(1e-9, mult * 1.06 * sdY * Math.pow(nEff, -0.2))]);
      if (!grid) return;
      const projection = d3.geoIdentity().reflectY(true)
        .fitExtent([[0, 0], [inner.w, inner.h]], { type: "Polygon", coordinates: [[[xlo, ylo], [xhi, ylo], [xhi, yhi], [xlo, yhi], [xlo, ylo]]] });
      const path = d3.geoPath(projection);
      const thresholds = d3.range(1, +opt.levels).map((i) => i / +opt.levels);
      const polys = d3.contours().size([gx, gy]).thresholds(thresholds)(grid.values);
      const fill = d3.scaleSequential(d3.interpolateViridis).domain([0, 1]);
      const layer = g.append("g");
      if (opt.fill) layer.selectAll("path.f").data(polys).join("path").attr("class", "f")
        .attr("d", path).attr("fill", (d, i) => fill((i + 1) / (polys.length + 1)))
        .attr("fill-opacity", opt.fillOpacity).attr("stroke", "none")
        .each(function () { ctx.sel(this, [], { decor: true, lit: false }); });
      layer.selectAll("path.l").data(polys).join("path").attr("class", "l")
        .attr("d", path).attr("fill", "none").attr("stroke", opt.fill ? "#2b3a48" : "#33506b")
        .attr("stroke-width", 0.9).attr("stroke-opacity", 0.7)
        .on("mousemove", (ev, d) => ctx.tip(ev, `等高線：相對密度 ≈ ${fmt(d.value, 2)}`))
        .on("mouseleave", ctx.tipOff)
        .each(function () { ctx.sel(this, [], { decor: true, lit: false }); });
      if (opt.showPoints) layer.selectAll("circle").data(rows).join("circle")
        .attr("cx", (r) => scales.x(xCol.values[r.__i])).attr("cy", (r) => scales.y(yCol.values[r.__i]))
        .attr("r", 1.5).attr("fill", "#0d1b2a").attr("fill-opacity", 0.4)
        .each(function (r) { ctx.sel(this, r, { kind: "point" }); });
      if (!ctx.small) note(g, Object.assign({}, inner, { w: 4, h: 0 }), `核密度等高線（${gx}×${gy} 網格，頻寬倍數 ${mult}）`);
    }
  };

  defs.time = {
    label: "時間序列", short: "Time Series",
    defaults: { width: 1.9, rolling: 0, bandRange: false, showPoints: true },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales, color } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!yCol || yCol.type !== "continuous") { if (!ctx.small) note(g, inner, "時間序列需要連續變數在 Y 軸"); return; }
      if (!ctx.xTime) { if (!ctx.small) note(g, inner, "請把日期/時間欄放到 X 軸（變數右鍵可改為日期時間）"); return; }
      for (const [gk, grows] of ctx.groups(rows)) {
        const pts = grows.map((r) => ({ t: xCol.values[r.__i], y: yCol.values[r.__i], w: ctx.freqW(r), row: r }))
          .filter((d) => d.t instanceof Date && typeof d.y === "number" && isFinite(d.y))
          .sort((a, b) => a.t - b.t);
        if (!pts.length) continue;
        const c = color(gk);
        if (opt.bandRange && pts.length > 4) {
          const nBins = Math.max(6, Math.min(40, Math.round(pts.length / 5)));
          const t0 = +pts[0].t, t1 = +pts[pts.length - 1].t;
          const bins = d3.range(nBins).map(() => []);
          pts.forEach((p) => bins[Math.min(nBins - 1, Math.floor(((+p.t - t0) / ((t1 - t0) || 1)) * nBins))].push(p.y));
          const bd = bins.map((arr, i) => arr.length ? { t: new Date(t0 + ((i + 0.5) / nBins) * (t1 - t0)), lo: Stats.min(arr), hi: Stats.max(arr) } : null).filter(Boolean);
          if (bd.length > 1) ctx.sel(g.append("path").attr("d", d3.area().x((d) => scales.x(d.t)).y0((d) => scales.y(d.lo)).y1((d) => scales.y(d.hi))(bd))
            .attr("class", "decor").attr("fill", c).attr("fill-opacity", 0.12), [], { decor: true, lit: false });
        }
        if (pts.length > 1) ctx.sel(g.append("path")
          .attr("d", d3.line().x((d) => scales.x(d.t)).y((d) => scales.y(d.y)).curve(opt.connect === "step" ? d3.curveStepAfter : d3.curveMonotoneX)(pts))
          .attr("fill", "none").attr("stroke", c).attr("stroke-width", opt.width), grows, { lit: false });
        const roll = +opt.rolling;
        if (roll > 1) {
          const sm = pts.map((p, i) => {
            const win = pts.slice(Math.max(0, i - roll + 1), i + 1);
            return { t: p.t, y: Stats.wmean(win.map((q) => q.y), win.map((q) => q.w)) };
          });
          ctx.sel(g.append("path").attr("d", d3.line().x((d) => scales.x(d.t)).y((d) => scales.y(d.y)).curve(d3.curveMonotoneX)(sm))
            .attr("fill", "none").attr("stroke", d3.color(c).darker(1.1).toString()).attr("stroke-width", 2.2).attr("stroke-dasharray", "6 3"),
            [], { decor: true, lit: false });
        }
        if (opt.showPoints) g.selectAll(null).data(pts).join("circle")
          .attr("cx", (d) => scales.x(d.t)).attr("cy", (d) => scales.y(d.y)).attr("r", 2.3)
          .attr("fill", c).attr("stroke", "#fff").attr("stroke-width", 0.5)
          .on("mousemove", (ev, d) => ctx.tip(ev, `${fmtDate(d.t)}${gk === "__all__" ? "" : " · " + cfg.color + "：" + gk}\n${cfg.y} = ${fmt(d.y)}`))
          .on("mouseleave", ctx.tipOff)
          .each(function (d) { ctx.sel(this, d.row, { kind: "point" }); });
        else for (const p of pts) ctx.sel(null, p.row, { kind: "point", x: scales.x(p.t), y: scales.y(p.y), r: 4, space: g, hitOnly: true });
      }
    }
  };

  defs.mosaic = {
    label: "馬賽克圖", short: "Mosaic",
    defaults: { labels: true, bins: 4 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales } = ctx;
      const xCol = cfg.xCol, yCol = cfg.yCol;
      if (!xCol || !yCol) { if (!ctx.small) note(g, inner, "馬賽克圖需要兩個變數（X 與 Y）"); return; }
      const binK = Math.max(2, Math.min(10, +opt.bins || 4));
      const mk = (which, col) => {
        const sc = scales[which];
        if (sc.__cats) return { cats: sc.__cats.slice(), keyOf: (v) => catForValue(scales, which, v) };
        if (!sc.ticks) return { cats: [], keyOf: () => null };
        const dom = sc.domain();
        const cats = [];
        for (let i = 0; i < binK; i++) cats.push(`${fmt(dom[0] + i * (dom[1] - dom[0]) / binK, 1)}–${fmt(dom[0] + (i + 1) * (dom[1] - dom[0]) / binK, 1)}`);
        return { cats, keyOf: (v) => (typeof v === "number" && isFinite(v) ? cats[catKeyOfLinear(v, dom, binK)] : null) };
      };
      const AX = mk("x", xCol), AY = mk("y", yCol);
      const xk = AX.cats, yk = AY.cats.slice().reverse();
      if (!xk.length || !yk.length) { if (!ctx.small) note(g, inner, "馬賽克圖需要兩個可分類的變數"); return; }
      const third = cfg.color ? cfg.colMap.get(cfg.color) : null;
      const tk = third ? uniqueStrings(third.values.filter((v) => v != null)) : [];
      const counts = yk.map(() => xk.map(() => 0));
      const cube = yk.map(() => xk.map(() => tk.map(() => 0)));
      const cellRows = yk.map(() => xk.map(() => []));      // 每格含哪些資料列（跨圖框選用）
      const cubeRows = yk.map(() => xk.map(() => tk.map(() => [])));
      for (const r of rows) {
        const ix = xk.indexOf(AX.keyOf(xCol.values[r.__i])), iy = yk.indexOf(AY.keyOf(yCol.values[r.__i]));
        if (ix < 0 || iy < 0) continue;
        const w = ctx.freqW(r);
        counts[iy][ix] += w;
        cellRows[iy][ix].push(r);
        if (third) {
          const iz = tk.indexOf(String(third.values[r.__i]));
          if (iz >= 0) { cube[iy][ix][iz] += w; cubeRows[iy][ix][iz].push(r); }
        }
      }
      const layout = Stats.mosaicLayout(counts, xk, yk);
      const colScale = tk.length > 1 ? d3.scaleOrdinal(tk.map(String), d3.quantize((t) => d3.hsl((200 + 300 * t) % 360, 0.5, 0.58), Math.max(3, tk.length))) : () => "#4c78a8";
      const layer = g.append("g");
      layout.rects.forEach((rc) => {
        let acc = 0;
        for (let iz = 0; iz < Math.max(1, tk.length); iz++) {
          const v = tk.length > 1 ? cube[rc.iz][rc.ix][iz] : counts[rc.iz][rc.ix];
          if (!(v > 0)) continue;
          const sliceW = rc.w * (v / (counts[rc.iz][rc.ix] || 1));
          const x = (rc.x + acc) * inner.w, y = (1 - rc.y - rc.h) * inner.h;
          acc += sliceW;
          const cellRowsHere = third ? (cubeRows[rc.iz][rc.ix][iz] || []) : (cellRows[rc.iz][rc.ix] || []);
          ctx.sel(layer.append("rect").attr("x", x).attr("y", y).attr("width", Math.max(1, sliceW * inner.w - 1)).attr("height", Math.max(1, rc.h * inner.h - 1))
            .attr("fill", colScale(tk[iz] == null ? null : String(tk[iz]))).attr("fill-opacity", 0.85)
            .attr("stroke", "#fff").attr("stroke-width", 1.3)
            .on("mousemove", (ev) => ctx.tip(ev,
              `${xCol.key} = ${xk[rc.ix]}\n${yCol.key} = ${yk[rc.iz]}${tk[iz] != null ? "\n" + cfg.color + " = " + tk[iz] : ""}\n次數 = ${fmt(v)}   總體佔比 = ${(rc.share * 100).toFixed(1)}%   欄內佔比 = ${((v / (counts[rc.iz][rc.ix] || 1)) * 100).toFixed(1)}%`))
            .on("mouseleave", ctx.tipOff), cellRowsHere, { kind: "area", anchor: "bottom" });
          if (opt.labels && sliceW * inner.w > 30 && rc.h * inner.h > 16) {
            ctx.sel(layer.append("text").attr("class", "cell-label").attr("x", x + sliceW * inner.w / 2).attr("y", y + rc.h * inner.h / 2 + 3)
              .attr("text-anchor", "middle").attr("fill", "#fff").attr("font-weight", 600).text((rc.share * 100).toFixed(0) + "%"), cellRowsHere, { lit: false });
          }
        }
      });
      const grand = counts.flat().reduce((a, b) => a + b, 0) || 1;
      const colTot = xk.map((_, ix) => counts.reduce((a, row) => a + row[ix], 0));
      let xa = 0;
      xk.forEach((k, ix) => {
        const w = colTot[ix] / grand;
        g.append("text").attr("class", "cat-label").attr("x", (xa + w / 2) * inner.w).attr("y", inner.h + 15).attr("text-anchor", "middle").text(k);
        g.append("line").attr("x1", xa * inner.w).attr("x2", xa * inner.w).attr("y1", 0).attr("y2", inner.h).attr("stroke", "#98a1ad").attr("stroke-width", xa === 0 ? 1 : 0.6);
        xa += w;
      });
      const rowTot = yk.map((_, iy) => counts[iy].reduce((a, b) => a + b, 0));
      let ya = 0;
      yk.forEach((k, iy) => {
        const h = rowTot[iy] / grand;
        g.append("text").attr("class", "cat-label").attr("x", -7).attr("y", (1 - ya - h / 2) * inner.h + 4).attr("text-anchor", "end").text(k);
        ya += h;
      });
      g.append("text").attr("class", "axis-title").attr("x", inner.w / 2).attr("y", inner.h + 34).attr("text-anchor", "middle")
        .text(xCol.key + (cfg.binnedAxis === "x" ? `（分 ${binK} 帶）` : ""));
      g.append("text").attr("class", "axis-title").attr("transform", `translate(-44,${inner.h / 2}) rotate(-90)`).attr("text-anchor", "middle")
        .text(yCol.key + (cfg.binnedAxis === "y" ? `（分 ${binK} 帶）` : ""));
    }
  };

  defs.map = {
    label: "互動式地圖", short: "Map",
    defaults: { size: 6, maxSize: 20, bubbles: true },
    async render(ctx) {
      const { g, inner, rows, cfg, opt, scales, color } = ctx;
      const latCol = cfg.latCol, lonCol = cfg.lonCol;
      if (!latCol || !lonCol) { if (!ctx.small) note(g, inner, "地圖需要經度/緯度欄位（自動偵測 lat/lon，或手動指定）"); return; }
      const topo = await ctx.topo();
      const sphere = { type: "Polygon", coordinates: [[[-180, -85], [180, -85], [180, 85], [-180, 85], [-180, -85]]] };
      const projection = d3.geoNaturalEarth1().fitExtent([[4, 4], [inner.w - 4, inner.h - 4]], sphere);
      const path = d3.geoPath(projection);
      const world = g.append("g").attr("class", "world");
      world.append("path").attr("d", path(sphere)).attr("fill", "#f7fafc").attr("stroke", "#dbe1e8");
      if (topo) {
        const feats = topojson.feature(topo, topo.objects.countries).features;
        world.selectAll("path.c").data(feats).join("path").attr("class", "c")
          .attr("d", path).attr("fill", "#e9edf2").attr("stroke", "#cbd2da").attr("stroke-width", 0.45);
      }
      world.append("path").attr("d", path(d3.geoGraticule10())).attr("fill", "none").attr("stroke", "#e4e8ee").attr("stroke-width", 0.4);

      const sizeCol = sizeColumnOf(cfg);
      const sizeVals = sizeCol ? ctx.numsOf(rows, sizeCol) : null;
      const sizeScale = sizeVals && sizeVals.length > 1 ? d3.scaleSqrt().domain(d3.extent(sizeVals)).range([2.5, +opt.maxSize || 20]) : null;
      const colorCol = cfg.colorCol;
      const colorIsNum = colorCol && colorCol.type === "continuous";
      const contColor = colorIsNum ? d3.scaleSequential(d3.interpolateYlOrRd).domain(d3.extent(ctx.numsOf(rows, colorCol))) : null;
      const discColor = colorCol && !colorIsNum ? colorScale(uniqueStrings(colorCol.values.filter((v) => v != null))) : null;

      const ptsLayer = g.append("g");
      const data = [];
      for (const r of rows) {
        const lat = +latCol.values[r.__i], lon = +lonCol.values[r.__i];
        if (!isFinite(lat) || !isFinite(lon)) continue;
        const p = projection([lon, lat]);
        if (!p || !isFinite(p[0]) || !isFinite(p[1])) continue;
        data.push({ r, p, row: r });
      }
      const circles = ptsLayer.selectAll("circle").data(data).join("circle")
        .attr("cx", (d) => d.p[0]).attr("cy", (d) => d.p[1])
        .attr("r", (d) => {
          if (sizeScale) { const v = +sizeCol.values[d.r.__i]; return isFinite(v) ? sizeScale(v) : 4; }
          return +opt.size || 6;
        })
        .attr("fill", (d) => colorCol ? (colorIsNum ? contColor(+colorCol.values[d.r.__i]) : discColor(String(colorCol.values[d.r.__i]))) : color(null))
        .attr("fill-opacity", (d) => ctx.isExcluded(d.r) ? 0.25 : 0.62)
        .attr("stroke", "#5a6572").attr("stroke-width", 0.5)
        .style("cursor", "pointer")
        .on("mousemove", (ev, d) => ctx.tip(ev, ctx.rowTip(d.r)))
        .on("mouseleave", ctx.tipOff)
        .on("click", (ev, d) => { ev.stopPropagation(); ctx.toggleExclude(d.r.__i); })
        .each(function (d) { ctx.sel(this, d.r, { kind: "point" }); });

      if (opt.graticule === false) world.selectAll(".grid").remove();
      // 拖曳留給「框選」：平移改用 Ctrl/⌘ + 拖曳（滾輪縮放、雙擊還原、觸控手勢不變）
      const zoom = d3.zoom().scaleExtent([1, 14]).translateExtent([[0, 0], [inner.w, inner.h]])
        .filter((ev) => ev.type === "wheel" || ev.type === "touchstart" ? true : !ev.button && (ev.ctrlKey || ev.metaKey))
        .on("zoom", (ev) => {
          world.attr("transform", ev.transform);
          ptsLayer.attr("transform", ev.transform);
          ptsLayer.selectAll("circle").attr("stroke-width", 0.5 / Math.sqrt(ev.transform.k))
            .attr("r", function (d) {
              const base = sizeScale ? (sizeScale(+sizeCol.values[d.r.__i]) || 4) : (+opt.size || 6);
              return base / Math.pow(ev.transform.k, 0.5);
            });
        });
      ctx.svg.call(zoom).on("dblclick.zoom", () => ctx.svg.transition().duration(400).call(zoom.transform, d3.zoomIdentity));
    }
  };

  defs.pie = {
    label: "圓餅圖", short: "Pie",
    defaults: { statistic: "share", hole: 0, sort: "desc", labels: true, decimals: 1 },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales } = ctx;
      const catCol = (cfg.xCol && cfg.xCol.type !== "continuous") ? cfg.xCol
        : (cfg.yCol && cfg.yCol.type !== "continuous") ? cfg.yCol
        : (cfg.colorCol || null);
      if (!catCol) { if (!ctx.small) note(g, inner, "圓餅圖需要一個類別變數（放到 X 或 Color）"); return; }
      const which = catCol === cfg.xCol ? "x" : (catCol === cfg.yCol ? "y" : "color");
      const valCol = (cfg.xCol === catCol ? cfg.yCol : cfg.xCol);
      const useVal = valCol && valCol.type === "continuous" && opt.statistic !== "count";
      const stat = statFn(opt.statistic === "share" ? "sum" : opt.statistic);

      const byCat = new Map();
      for (const r of rows) {
        const k = which === "color" ? (catCol.values[r.__i] == null ? "(缺失)" : String(catCol.values[r.__i]))
          : (catForValue(scales, which, catCol.values[r.__i]) ?? "(缺失)");
        let cur = byCat.get(k);
        if (!cur) { cur = { v: [], w: [], n: 0, rows: [] }; byCat.set(k, cur); }
        cur.n += ctx.freqW(r);
        cur.rows.push(r);
        if (useVal) { const yv = valCol.values[r.__i]; if (typeof yv === "number" && isFinite(yv)) { cur.v.push(yv); cur.w.push(ctx.freqW(r)); } }
      }
      let data = Array.from(byCat, ([key, cell]) => ({
        key,
        value: useVal && cell.v.length ? (stat(cell.v, cell.w) ?? 0) : cell.n,
        n: cell.n,
        rows: cell.rows
      })).filter((d) => d.value > 0 && isFinite(d.value));
      if (!data.length) { if (!ctx.small) note(g, inner, "沒有可用的數值（全部被排除或缺失）"); return; }
      if (opt.sort === "desc") data.sort((a, b) => b.value - a.value);
      else if (opt.sort === "asc") data.sort((a, b) => a.value - b.value);
      const total = data.reduce((a, d) => a + d.value, 0);
      data.forEach((d) => d.share = d.value / total);

      const cx = inner.w / 2, cy = inner.h / 2;
      const R = Math.max(40, Math.min(inner.w, inner.h) / 2 - 46);
      const hole = Math.max(0, Math.min(0.85, +opt.hole || 0));
      const color = colorScale(data.map((d) => d.key));
      const arc = d3.arc().innerRadius(R * hole).outerRadius(R).cornerRadius(hole ? 2 : 0).padAngle(0.008);
      const labelArc = d3.arc().innerRadius(R * 0.72).outerRadius(R * 0.72);
      const layer = g.append("g").attr("transform", `translate(${cx},${cy})`);
      const pieGen = d3.pie().sort(null).value((d) => d.value)(data);

      layer.selectAll("path.slice").data(pieGen).join("path").attr("class", "slice")
        .attr("d", arc)
        .attr("fill", (d) => color(d.data.key)).attr("fill-opacity", 0.88)
        .attr("stroke", "#fff").attr("stroke-width", 1.4)
        .style("cursor", "pointer")
        .on("mousemove", (ev, d) => ctx.tip(ev,
          `${catCol.key}：${d.data.key}\n${useVal ? (STAT_NAMES[opt.statistic] || "總和") : "次數"} = ${fmt(d.data.value)}   佔比 = ${(d.data.share * 100).toFixed(1)}%\nn = ${fmt(d.data.n)}${useVal ? "" : "（含 Freq 加權）"}`))
        .on("mouseleave", ctx.tipOff)
        .on("click", (ev, d) => { ev.stopPropagation(); ctx.toggleRows(d.data.rows); })
        .each(function (d) { ctx.sel(this, d.data.rows, { kind: "path" }); });

      if (opt.labels) {
        pieGen.forEach((d) => {
          if (d.endAngle - d.startAngle < 0.06) return;
          const [lx, ly] = labelArc.centroid(d);
          const span = d.endAngle - d.startAngle;
          const inside = span > 0.34;
          const pct = (d.data.share * 100).toFixed(Math.max(0, Math.min(3, +opt.decimals || 1)));
          const ang = (d.startAngle + d.endAngle) / 2 - Math.PI / 2;
          const ox = Math.cos(ang), oy = Math.sin(ang);
          const label = inside && span < 0.75 ? `${pct}%` : `${d.data.key} ${pct}%`;
          const tx = inside ? lx : ox * (R + 12), ty = inside ? ly : oy * (R + 12);
          ctx.sel(layer.append("text").attr("class", "pie-label").attr("x", tx).attr("y", ty)
            .attr("text-anchor", inside ? "middle" : (ox >= 0 ? "start" : "end"))
            .attr("dominant-baseline", "middle")
            .attr("fill", inside ? "#ffffff" : "#37434f")
            .attr("font-size", inside ? 11.5 : 11)
            .attr("stroke", inside ? "rgba(0,0,0,.25)" : "none").attr("stroke-width", inside ? 2 : 0)
            .attr("paint-order", "stroke").attr("font-weight", 600)
            .text(label), d.data.rows, { lit: false });
          if (!inside) ctx.sel(layer.append("line").attr("class", "decor")
            .attr("x1", ox * R * (hole || 0.96)).attr("y1", oy * R * (hole || 0.96))
            .attr("x2", ox * (R + 6)).attr("y2", oy * (R + 6))
            .attr("stroke", "#b9c2cc").attr("stroke-width", 1), d.data.rows, { lit: false });
        });
      }
      if (hole > 0 && !ctx.small) {
        const locative = useVal && ["mean", "median", "stddev", "stderr", "min", "max"].includes(opt.statistic);
        let centerVal = total, centerLabel = useVal ? (STAT_NAMES[opt.statistic] || "總和") : "總次數";
        if (locative) {
          const av = [], aw = [];
          rows.forEach((r) => { const yv = valCol.values[r.__i]; if (typeof yv === "number" && isFinite(yv)) { av.push(yv); aw.push(ctx.freqW(r)); } });
          centerVal = statFn(opt.statistic)(av, aw);
          centerLabel = `整體${STAT_NAMES[opt.statistic]}`;
        } else if (useVal && opt.statistic === "share") {
          centerLabel = "總和";
        }
        layer.append("text").attr("class", "pie-center").attr("text-anchor", "middle").attr("y", -4).text(fmt(centerVal, 2));
        layer.append("text").attr("class", "pie-center-sub").attr("text-anchor", "middle").attr("y", 16).text(centerLabel);
      }
      if (!ctx.small) g.append("text").attr("class", "axis-title").attr("x", inner.w / 2).attr("y", inner.h + 34)
        .attr("text-anchor", "middle").text(`${catCol.key}（${useVal ? valCol.key + " 的" + (STAT_NAMES[opt.statistic] || "總和") : "次數佔比"}）`);
    }
  };

  // 節點調色盤：金色角（137.508°）旋轉 → 任意數量都彼此分明且飽和度適中
  function sankeyPalette(count) {
    const n = Math.max(1, count || 1);
    const out = [];
    for (let i = 0; i < n; i++) {
      const hue = (i * 137.507764 + 18) % 360;
      const sat = 0.40 + 0.20 * ((i % 3) / 2);
      const light = 0.58 - 0.10 * ((i % 2));
      const c = d3.hsl(hue, sat, light);
      out.push(c.formatHex ? c.formatHex() : c.toString());
    }
    return out;
  }

  defs.sankey = {
    label: "桑基圖", short: "Sankey",
    defaults: { nodeWidth: 16, gap: 14, labels: true, values: true, curvature: 0.5, opacity: 0.42, gradient: true, colorMode: "node" },
    render(ctx) {
      const { g, inner, rows, cfg, opt, scales } = ctx;
      const mode = cfg.sankeyMode;
      if (!mode) { if (!ctx.small) note(g, inner, "桑基圖需要：X=來源類別 + Y=多個數值欄（寬表），或 X/Y 兩個類別欄並指定 Size/Freq/Color 為流量"); return; }

      // ---- 建立邊界清單（含資料列索引，供排除互動）----
      const edges = [];   // {source, target, value, rows:[]}
      // 權重欄若就是 Freq 欄，freqW() 已經乘過，避免重複相乘
      const weightIsFreq = !!(mode.weightCol && cfg.freq && mode.weightCol === cfg.freq);
      if (mode.kind === "wide") {
        const cats = (scales.x.__cats) || [];
        for (const r of rows) {
          const src = catForValue(scales, "x", cfg.xCol.values[r.__i]);
          if (src == null) continue;
          for (const key of mode.cols) {
            const col = cfg.colMap.get(key);
            const v = col ? +col.values[r.__i] : NaN;
            if (!isFinite(v) || v <= 0) continue;
            const w = weightIsFreq ? v : v * ctx.freqW(r);
            const e = edges.find((x) => x.source === src && x.target === key);
            if (e) { e.value += w; e.rows.push(r); } else edges.push({ source: src, target: key, value: w, rows: [r] });
          }
        }
      } else {
        const wCol = mode.weightCol ? cfg.colMap.get(mode.weightCol) : null;
        for (const r of rows) {
          const a = catForValue(scales, "x", cfg.xCol.values[r.__i]);
          const b = catForValue(scales, "y", cfg.yCol.values[r.__i]);
          if (a == null || b == null) continue;
          let w = 1;
          if (wCol) { const vv = +wCol.values[r.__i]; if (!isFinite(vv) || vv <= 0) continue; w = vv; }
          if (!weightIsFreq) w *= ctx.freqW(r);
          const e = edges.find((x) => x.source === a && x.target === b);
          if (e) { e.value += w; e.rows.push(r); } else edges.push({ source: a, target: b, value: w, rows: [r] });
        }
      }
      if (!edges.length) { if (!ctx.small) note(g, inner, "沒有可用的流量（數值需 > 0，或資料列被排除）"); return; }

      // ---- 節點與層 ----
      const nodes = new Map();
      const ensure = (name, layer) => {
        let n = nodes.get(name);
        if (!n) { n = { name, layer, in: 0, out: 0, rows: [] }; nodes.set(name, n); }
        if (layer != null) n.layer = Math.max(n.layer == null ? layer : n.layer, layer);
        return n;
      };
      edges.forEach((e) => {
        const a = ensure(e.source, 0), b = ensure(e.target, 1);
        a.out += e.value; b.in += e.value;
        a.rows.push(...e.rows); b.rows.push(...e.rows);
      });
      // 寬表模式：數值欄全部放在同一層
      if (mode.kind === "wide") Array.from(nodes.values()).forEach((n) => { if (mode.cols.includes(n.name)) n.layer = 1; });
      // 迭代修正層（處理回饋環）
      for (let iter = 0; iter < 24; iter++) {
        let changed = false;
        for (const e of edges) {
          const a = nodes.get(e.source), b = nodes.get(e.target);
          if (b.layer <= a.layer) { b.layer = a.layer + 1; changed = true; }
        }
        if (!changed) break;
      }
      const maxLayer = Math.max.apply(null, Array.from(nodes.values()).map((n) => n.layer || 0));
      const byLayer = new Map();
      Array.from(nodes.values()).forEach((n) => {
        const k = n.layer || 0;
        if (!byLayer.has(k)) byLayer.set(k, []);
        byLayer.get(k).push(n);
      });
      // 同層排序：先依流量大排，再用重心法調整一次（減少交叉）
      Array.from(byLayer.values()).forEach((list) => list.sort((a, b) => Math.max(b.in, b.out) - Math.max(a.in, a.out)));
      Array.from(byLayer.keys()).sort((a, b) => a - b).forEach((k) => {
        if (k === 0) return;
        const prev = byLayer.get(k - 1) || [];
        const posOf = new Map(prev.map((n, i) => [n.name, i]));
        byLayer.get(k).forEach((n) => {
          const refs = edges.filter((e) => e.target === n.name).map((e) => posOf.get(e.source)).filter((v) => v != null);
          n.__bary = refs.length ? d3.mean(refs) : 1e9;
        });
        byLayer.get(k).sort((a, b) => (a.__bary - b.__bary) || (Math.max(b.in, b.out) - Math.max(a.in, a.out)));
      });

      // ---- 幾何 ----
      const nodeWidth = Math.max(6, +opt.nodeWidth || 16);
      const gap = Math.max(2, +opt.gap || 14);
      const layers = Array.from(byLayer.values());
      const padL = 6, padR = 6;
      const totalW = Math.max(60, inner.w - padL - padR);
      const xFor = (layer) => maxLayer === 0 ? 0 : (layer / maxLayer) * (totalW - nodeWidth);
      let scale = Infinity;
      layers.forEach((list) => {
        const sum = list.reduce((a, n) => a + Math.max(n.in, n.out), 0);
        const avail = inner.h - gap * Math.max(0, list.length - 1);
        if (sum > 0) scale = Math.min(scale, avail / sum);
      });
      if (!isFinite(scale) || scale <= 0) scale = 1;
      layers.forEach((list) => {
        let y = 0;
        const stackH = list.reduce((a, n) => a + Math.max(n.in, n.out) * scale, 0) + gap * Math.max(0, list.length - 1);
        y = (inner.h - stackH) / 2;
        list.forEach((n) => {
          n.x0 = xFor(n.layer) + padL; n.x1 = n.x0 + nodeWidth;
          n.h = Math.max(1.5, Math.max(n.in, n.out) * scale);
          n.y0 = y; n.y1 = y + n.h; n.cy = y + n.h / 2;
          y += n.h + gap;
        });
      });
      // 邊依兩端位置排序，決定進出節點的堆疊偏移
      const outOff = new Map(), inOff = new Map();
      Array.from(nodes.values()).forEach((n) => { outOff.set(n.name, 0); inOff.set(n.name, 0); });
      const sorted = edges.slice().sort((a, b) => {
        const A = nodes.get(a.source), B = nodes.get(b.source);
        return (A.y0 - B.y0) || (nodes.get(a.target).y0 - nodes.get(b.target).y0);
      });
      // 節點配色：金色角旋轉取色，任意節點數量都彼此分明（可依層或依節點）
      const orderedNodes = Array.from(nodes.values()).sort((a, b) => (a.layer - b.layer) || (a.y0 - b.y0));
      const nodeColorMap = new Map();
      if ((opt.colorMode || "node") === "layer") {
        const layerCols = sankeyPalette(maxLayer + 1);
        orderedNodes.forEach((n) => nodeColorMap.set(n.name, layerCols[Math.min(layerCols.length - 1, n.layer)]));
      } else {
        const cols = sankeyPalette(orderedNodes.length);
        orderedNodes.forEach((n, i) => nodeColorMap.set(n.name, cols[i % cols.length]));
      }
      const color = (name) => nodeColorMap.get(name) || "#8a97a8";
      const defsEl = g.append("defs");
      const gradSeq = `sk${Math.random().toString(36).slice(2, 7)}`;
      let gradCount = 0;
      const linkLayer = g.append("g"), nodeLayer = g.append("g"), labelLayer = g.append("g");

      sorted.forEach((e) => {
        const a = nodes.get(e.source), b = nodes.get(e.target);
        const wdt = Math.max(1, e.value * scale);
        const y0 = a.y0 + outOff.get(a.name) + wdt / 2; outOff.set(a.name, outOff.get(a.name) + wdt);
        const y1 = b.y0 + inOff.get(b.name) + wdt / 2; inOff.set(b.name, inOff.get(b.name) + wdt);
        const x0 = a.x1, x1 = b.x0;
        const c = Math.max(0, Math.min(1, +opt.curvature == null ? 0.5 : +opt.curvature));
        const mx = x0 + (x1 - x0) * c;
        const path = `M${x0},${y0}C${mx},${y0} ${x1 - (x1 - x0) * c},${y1} ${x1},${y1}`;
        let stroke = color(a.name);
        if (opt.gradient !== false && x1 > x0) {
          const gid = `${gradSeq}_${gradCount++}`;
          const lg = defsEl.append("linearGradient").attr("id", gid)
            .attr("gradientUnits", "userSpaceOnUse").attr("x1", x0).attr("x2", x1).attr("y1", y0).attr("y2", y1);
          lg.append("stop").attr("offset", "0%").attr("stop-color", color(a.name));
          lg.append("stop").attr("offset", "100%").attr("stop-color", color(b.name));
          stroke = `url(#${gid})`;
        }
        ctx.sel(linkLayer.append("path").attr("class", "sankey-link")
          .attr("d", path).attr("fill", "none")
          .attr("stroke", stroke).attr("stroke-width", wdt)
          .attr("stroke-opacity", opt.opacity == null ? 0.42 : opt.opacity)
          .style("cursor", "pointer")
          .on("mousemove", (ev) => ctx.tip(ev, `${a.name} → ${b.name}\n流量 = ${fmt(e.value)}   佔比 = ${(e.value / edges.reduce((s, x) => s + x.value, 0) * 100).toFixed(1)}%\n資料列 = ${e.rows.length}`))
          .on("mouseleave", ctx.tipOff)
          .on("click", (ev) => { ev.stopPropagation(); ctx.toggleRows(e.rows); })
          .on("mouseover", function () { d3.select(this).attr("stroke-opacity", Math.min(0.85, (opt.opacity || 0.42) + 0.3)); })
          .on("mouseout", function () { d3.select(this).attr("stroke-opacity", opt.opacity == null ? 0.42 : opt.opacity); }),
          e.rows, { kind: "path", lit: false });
      });

      Array.from(nodes.values()).forEach((n) => {
        ctx.sel(nodeLayer.append("rect").attr("x", n.x0).attr("y", n.y0).attr("width", nodeWidth).attr("height", n.h)
          .attr("fill", color(n.name)).attr("stroke", d3.color(color(n.name)).darker(0.9).toString()).attr("stroke-width", 0.8)
          .style("cursor", "pointer")
          .on("mousemove", (ev) => ctx.tip(ev, `${n.name}\n流入 = ${fmt(n.in)}   流出 = ${fmt(n.out)}\n關聯資料列 = ${new Set(n.rows.map((r) => r.__i)).size}`))
          .on("mouseleave", ctx.tipOff), n.rows, { kind: "area", anchor: "bottom" });
        if (!opt.labels) return;
        n.__labelY = n.cy;
      });
      // 標籤防碰撞：同層依序往下推，避免小節點的名稱被疊在一起
      const lineH = 12.5;
      Array.from(byLayer.values()).forEach((list) => {
        const sorted = list.slice().sort((a, b) => a.__labelY - b.__labelY);
        let last = -Infinity;
        sorted.forEach((n) => {
          if (n.__labelY < last + lineH) n.__labelY = last + lineH;
          last = n.__labelY;
        });
        // 超出畫面就整層往回挪
        const overflow = last - (inner.h - 4);
        if (overflow > 0) sorted.forEach((n) => { n.__labelY = Math.max(9, n.__labelY - overflow); });
      });
      Array.from(nodes.values()).forEach((n) => {
        const right = n.layer <= maxLayer / 2 || maxLayer === 0;
        const lx = right ? n.x1 + 6 : n.x0 - 6;
        const leader = Math.abs(n.__labelY - n.cy) > 2.5;
        if (leader) ctx.sel(labelLayer.append("line").attr("class", "decor")
          .attr("x1", right ? n.x1 : n.x0).attr("y1", n.cy)
          .attr("x2", lx + (right ? -2 : 2)).attr("y2", n.__labelY)
          .attr("stroke", "#aeb7c2").attr("stroke-width", 0.7), n.rows, { lit: false });
        const t = labelLayer.append("text").attr("class", "sankey-label")
          .attr("x", lx).attr("y", n.__labelY).attr("dy", "0.32em")
          .attr("text-anchor", right ? "start" : "end")
          .attr("stroke", "rgba(255,255,255,.85)").attr("stroke-width", 3).attr("paint-order", "stroke")
          .text(n.name);
        if (opt.values) t.append("tspan").attr("class", "sankey-value").attr("dx", 4)
          .text(fmt(Math.max(n.in, n.out), 2));
        ctx.sel(t, n.rows, { lit: false });
      });
      if (!ctx.small) g.append("text").attr("class", "fit-note-text").attr("x", 4).attr("y", -8)
        .text(mode.kind === "wide" ? `寬表流量：${cfg.x} → ${mode.cols.join("、")}` : `流量加權：${mode.weightCol || "列數（每列 = 1）"}`);
    }
  };

  const order = ["points", "line", "smoother", "box", "bar", "histogram", "heatmap", "contour", "time", "map", "mosaic", "pie", "sankey"];

  // ==================== 主繪製 ====================
  function activeRows(ds) {
    return ds.rows.map((r, i) => {
      const o = Object.create(r);
      o.__i = i; o.__excluded = ds.excluded.has(i);
      return o;
    });
  }

  function binnedColorColumn(col, kMax) {
    const vals = col.values.filter((v) => typeof v === "number" && isFinite(v));
    if (!vals.length) return col;
    const k = Math.max(2, Math.min(kMax || 8, new Set(vals.map(String)).size));
    const [lo, hi] = d3.extent(vals);
    const w = (hi - lo) / k || 1;
    const c = Object.create(col);
    c.values = col.values.map((v) => {
      if (typeof v !== "number" || !isFinite(v)) return null;
      const i = Math.min(k - 1, Math.max(0, Math.floor((v - lo) / w)));
      return `${fmt(lo + i * w, 1)}–${fmt(lo + (i + 1) * w, 1)}`;
    });
    c.type = "ordinal";
    c.distinct = new Set(c.values.filter(Boolean)).size;
    c.binnedFrom = col.key;
    return c;
  }

  // Size 區塊的欄位（可能是欄位物件或 key，兩種都要能吃）
  function sizeColumnOf(cfg) {
    const sc = cfg.sizeCol;
    if (sc && typeof sc === "object") return sc;
    const key = typeof sc === "string" ? sc : cfg.size;
    return key ? cfg.colMap.get(key) : null;
  }

  // 依 X/Y 變數與已開啟的圖元，推算這個面板的座標軸性質
  function applyAxisKinds(c) {
    const els = c.elements || [];
    const colMap = c.colMap;
    c.histOn = null;
    if (els.includes("histogram")) {
      const solo = els.length === 1;
      const hasX = !!c.xCol, hasY = !!c.yCol;
      const xCont = hasX && c.xCol.type === "continuous";
      const yCont = hasY && c.yCol.type === "continuous";
      if (solo) {
        if (xCont) c.histOn = "x";
        else if (yCont) c.histOn = "y";
        else if (c.xCol && c.xCol.type === "ordinal") c.histOn = "x";
        else if (hasX) c.histOn = "x";
        else if (hasY) c.histOn = "y";
      } else if (hasX && !hasY && (xCont || c.xCol.type === "ordinal")) c.histOn = "x";
      else if (hasY && !hasX && (yCont || c.yCol.type === "ordinal")) c.histOn = "y";
    }
    c.histSuppressed = els.includes("histogram") && !c.histOn;

    c.mapMode = !!c.mapWanted && !!c.latCol && !!c.lonCol;
    c.xTime = !c.mapMode && !c.mosaicWanted && !!c.xCol && c.xCol.hasDate && c.xCol.type === "continuous" && c.histOn !== "x";
    c.xDisc = !c.mapMode && !c.xTime && !!c.xCol && isDisc(c.xCol) && c.histOn !== "x";
    c.yDisc = !c.mapMode && !!c.yCol && isDisc(c.yCol) && c.histOn !== "y";
    c.xContinuous = !!c.xCol && c.xCol.type === "continuous" && !c.xDisc;
    c.yContinuous = !!c.yCol && c.yCol.type === "continuous" && !c.yDisc;

    // 流量型圖元（圓餅/桑基）：類別軸一律用 band
    c.flowEls = els.filter((e) => e === "pie" || e === "sankey");
    c.flowMode = c.flowEls.length > 0;
    if (c.flowMode) {
      c.xDisc = !!c.xCol && c.xCol.type !== "continuous";
      c.yDisc = !!c.yCol && c.yCol.type !== "continuous";
    }
    c.sankeyMode = null;
    if (els.includes("sankey")) {
      const yList = (c.yKeys && c.yKeys.length ? c.yKeys : (c.y ? [c.y] : []));
      const numCols = yList.slice(1).filter((k) => { const col = colMap.get(k); return col && col.type === "continuous"; });
      if (numCols.length) {
        c.sankeyMode = { kind: "wide", cols: [yList[0]].concat(numCols) };
      } else if (c.xCol && c.yCol && c.xCol.type !== "continuous" && c.yCol.type !== "continuous") {
        const sizeC = c.size ? colMap.get(c.size) : null;
        let weight = null;
        if (sizeC && sizeC.type === "continuous") weight = sizeC.key;
        else if (c.freq) weight = c.freq;
        c.sankeyMode = { kind: "pairs", weightCol: weight };
      }
      c.xDisc = !!c.xCol && c.xCol.type !== "continuous";
      c.yDisc = !!c.yCol && c.yCol.type !== "continuous";
    }
    c.barCountMode = !c.histOn && !c.flowMode && els.includes("bar") && !!c.xCol && isDisc(c.xCol) && (!c.yCol || c.yCol.type !== "continuous");

    // 兩個連續變數 + 需要兩個類別軸的圖元 → 自動把 X 分帶
    c.binnedAxis = null;
    const bothCont = c.xCol && c.yCol && c.xCol.type === "continuous" && c.yCol.type === "continuous";
    if (!c.histOn && bothCont && (els.includes("mosaic") || els.includes("heatmap") || els.includes("box"))) {
      c.binnedAxis = "x";
      c.xDisc = true;
    }
    c.binnedBins = els.includes("heatmap")
      ? Math.max(3, Math.min(14, Math.round(((c.elOpts && c.elOpts.heatmap || {}).nx || 12) / 2)))
      : 4;
    c.histValueName = c.histOn === "x" ? c.x : (c.histOn === "y" ? c.y : null);
    return c;
  }

  const PANEL_KEYS = ["colMap", "elements", "elOpts", "color", "colorCol", "overlay", "groupX", "groupY", "wrapX",
    "wrapCol", "freq", "freqCol", "size", "sizeCol", "sizeKeys", "shape", "label", "latCol", "lonCol",
    "xKeys", "yKeys", "grouping", "legend", "height", "mapWanted", "mosaicWanted", "xTimeWanted",
    "multiVar", "stackX", "stackY"];
  // 多個 X / Y 變數時，每個面板用自己的變數重新推算軸型
  function panelCfg(base, xKey, yKey) {
    const c = {};
    PANEL_KEYS.forEach((k) => { c[k] = base[k]; });
    c.x = xKey || null; c.y = yKey || null;
    c.xCol = c.x ? base.colMap.get(c.x) : null;
    c.yCol = c.y ? base.colMap.get(c.y) : null;
    return applyAxisKinds(c);
  }

  function buildSpec(spec, ds) {
    const colMap = new Map(ds.columns.map((c) => [c.key, c]));
    const cfg = { colMap };
    cfg.xKeys = (spec.zones.X || []).slice();
    cfg.yKeys = (spec.zones.Y || []).slice();
    cfg.x = cfg.xKeys[0] || null; cfg.y = cfg.yKeys[0] || null;
    cfg.xCol = cfg.x ? colMap.get(cfg.x) : null;
    cfg.yCol = cfg.y ? colMap.get(cfg.y) : null;
    cfg.color = spec.zones.Color[0] || null;
    cfg.colorCol = cfg.color ? colMap.get(cfg.color) : null;
    if (cfg.colorCol && cfg.colorCol.type === "continuous") cfg.colorCol = binnedColorColumn(cfg.colorCol);
    cfg.overlay = spec.zones.Overlay[0] || null;
    cfg.groupX = spec.zones["Group X"][0] || null;
    cfg.groupY = spec.zones["Group Y"][0] || null;
    cfg.wrapX = spec.zones.Wrap[0] || null;
    cfg.wrapY = spec.zones["Wrap Y"] || null;
    cfg.freq = spec.freq || spec.zones.Freq[0] || null;
    cfg.freqCol = cfg.freq ? colMap.get(cfg.freq) : null;
    cfg.sizeKeys = (spec.zones.Size || []).slice();
    cfg.size = cfg.sizeKeys[0] || null;
    cfg.sizeCol = cfg.size ? colMap.get(cfg.size) : null;
    cfg.shape = spec.zones.Shape[0] || null;
    cfg.label = spec.label || (ds.columns.find((c) => c.role === "label") || {}).key || null;

    // 地圖用的經緯度
    const lat = ds.columns.find((c) => c.role === "lat") || null;
    const lon = ds.columns.find((c) => c.role === "lon") || null;
    cfg.latCol = lat; cfg.lonCol = lon;

    let els = Object.keys(spec.elements || {}).filter((k) => spec.elements[k] && spec.elements[k].on);
    // 堆疊順序：spec.paintOrder 由下而上（最後一個畫在最上面）
    if (Array.isArray(spec.paintOrder) && spec.paintOrder.length) {
      const rank = new Map(spec.paintOrder.map((k, i) => [k, i]));
      els = els.slice().sort((a, b) => {
        const ra = rank.has(a) ? rank.get(a) : Number.POSITIVE_INFINITY;
        const rb = rank.has(b) ? rank.get(b) : Number.POSITIVE_INFINITY;
        return (ra - rb) || (order.indexOf(a) - order.indexOf(b));
      });
    }

    cfg.elements = els;
    cfg.elOpts = spec.elements;
    cfg.xTimeWanted = els.includes("time");
    cfg.mosaicWanted = els.includes("mosaic");
    cfg.mapWanted = els.includes("map");
    cfg.grouping = spec.grouping || "side";
    cfg.legend = spec.legend !== false;
    cfg.height = spec.height || 460;
    cfg.wrapCol = cfg.wrapX ? colMap.get(cfg.wrapX) : (cfg.groupX ? colMap.get(cfg.groupX) : null);   // 欄位物件（不是 key）

    applyAxisKinds(cfg);

    // ---- 多變數軸：X / Y 區塊內的擺放順序＝面板由左而右 / 由上而下 ===
    const sankeyWide = !!(cfg.sankeyMode && cfg.sankeyMode.kind === "wide");
    const onlyFlow = els.length > 0 && els.every((e) => e === "pie" || e === "sankey" || e === "map");
    cfg.stackY = (sankeyWide || onlyFlow || cfg.mapMode) ? [cfg.y || null] : (cfg.yKeys.length ? cfg.yKeys.slice() : [null]);
    cfg.stackX = (onlyFlow || cfg.mapMode) ? [cfg.x || null] : (cfg.xKeys.length ? cfg.xKeys.slice() : [null]);
    cfg.multiVar = cfg.stackX.length > 1 || cfg.stackY.length > 1;
    return cfg;
  }

  function isDisc(col, wantTime) {
    if (!col) return false;
    if (col.type === "continuous") return false;
    return true;
  }

  function catsInOrder(col, rows) {
    const seen = new Map();
    col.values.forEach((v, i) => {
      const k = v == null || v === "" ? "(缺失)" : String(v);
      if (!seen.has(k)) seen.set(k, 0);
      seen.set(k, seen.get(k) + 1);
    });
    let keys = Array.from(seen.keys());
    if (col.type === "ordinal" || (col.type === "continuous")) keys.sort((a, b) => (Number(a) - Number(a) === 0 ? String(a).localeCompare(String(b), "zh") : Number(a) - Number(b)));
    else keys.sort((a, b) => a.localeCompare(b, "zh"));
    return keys;
  }

  function makeScales(cfg, rows, panelW, panelH, xDomOv, yDomOv) {
    const scales = {};
    const xCol = cfg.xCol, yCol = cfg.yCol;
    const R = [0, panelW], RY = [panelH, 0];

    if (cfg.mapMode) {
      scales.x = d3.scaleLinear().domain([-180, 180]).range(R);
      scales.y = d3.scaleLinear().domain([-85, 85]).range(RY);
      scales.hideAxes = true;
      scales.xBandWidth = 0; scales.yBandWidth = 0;
      return scales;
    }

    const valCol = cfg.histOn === "x" ? xCol : (cfg.histOn === "y" ? yCol : null);
    const countAxis = cfg.histOn === "x" ? "y" : (cfg.histOn === "y" ? "x" : null);
    const countX = countAxis === "x";   // 橫式直方圖：計數在 X
    const countY = countAxis === "y";
    const maxCount = (countAxis || cfg.barCountMode) ? computeMaxCount(cfg, rows) : 1;

    // ---------- X ----------
    if (countX) scales.x = d3.scaleLinear().domain([0, maxCount]).range(R).nice();
    else if (cfg.histOn === "x") scales.x = linearScaleFor(valCol, xDomOv, R);
    else if (cfg.xDisc) scales.x = (cfg.binnedAxis === "x" ? binnedBandScale(xCol, R, cfg.binnedBins || 5) : bandScaleFor(xCol, R));
    else if (cfg.xTime) scales.x = timeScaleFor(xCol, xDomOv, R);
    else scales.x = linearScaleFor(xCol, xDomOv, R);

    // ---------- Y ----------
    if (countY) scales.y = d3.scaleLinear().domain([0, maxCount]).range(RY).nice();
    else if (cfg.histOn === "y") scales.y = linearScaleFor(valCol, yDomOv, RY);
    else if (cfg.yDisc) scales.y = (cfg.binnedAxis === "y" ? binnedBandScale(yCol, RY, cfg.binnedBins || 5) : bandScaleFor(yCol, RY));
    else scales.y = linearScaleFor(yCol, yDomOv, RY);

    scales.xBandWidth = scales.x.bandwidth ? scales.x.bandwidth() : 0;
    scales.yBandWidth = scales.y.bandwidth ? scales.y.bandwidth() : 0;
    // 馬賽克圖自己繪製分類軸與標題，避免重複標註
    if (cfg.elements.length === 1 && (cfg.elements[0] === "mosaic" || cfg.elements[0] === "pie" || cfg.elements[0] === "sankey")) scales.hideAxes = true;
    else if (cfg.flowMode && cfg.elements.length === 1) scales.hideAxes = true;
    return scales;
  }

  function bandScaleFor(col, range) {
    const cats = col ? catsInOrder(col, []) : [];
    const s = d3.scaleBand().domain(cats).range(range).paddingInner(0.24).paddingOuter(0.14);
    s.__cats = cats;
    return s;
  }

  // 連續變數 → 等寬分帶（標籤取bin 中心）
  function binnedBandScale(col, range, k) {
    const vals = col.values.filter((v) => typeof v === "number" && isFinite(v));
    if (!vals.length) return bandScaleFor(null, range);
    const [lo, hi] = d3.extent(vals);
    const w = (hi - lo) / k || 1;
    const cats = [];
    for (let i = 0; i < k; i++) {
      const a = lo + i * w, b = a + w;
      cats.push(i === k - 1 ? `${fmt(a, 1)}–${fmt(b, 1)}` : `≤${fmt(b, 1)}`);
    }
    const s = d3.scaleBand().domain(cats).range(range).paddingInner(0.24).paddingOuter(0.14);
    s.__cats = cats;
    s.__bin = { lo, w, k };
    s.__catOf = (v) => (typeof v !== "number" || !isFinite(v) ? null : cats[Math.min(k - 1, Math.max(0, Math.floor((v - lo) / w)))]);
    return s;
  }
  function catForValue(scales, which, v) {
    const sc = scales[which];
    if (sc.__catOf) return sc.__catOf(v);
    if (sc.__cats || !sc.ticks || typeof v !== "number" || !isFinite(v)) {
      if (v == null) return null;
      const k = v instanceof Date ? fmtDate(v) : String(v);
      return sc.__cats && !sc.__cats.includes(k) ? null : k;
    }
    // 線性軸上的連續變數 → 依視覺宽度分箱（馬賽克/熱圖混合情境）
    const px = Math.abs(sc(v + 1e-9) - sc(v)) || 1;
    const k = Math.max(2, Math.min(12, Math.floor(Math.abs(sc.range()[1] - sc.range()[0]) / (px * 14))));
    const dom = sc.domain();
    const w = (dom[1] - dom[0]) / k;
    const idx = Math.min(k - 1, Math.max(0, Math.floor((v - dom[0]) / w)));
    return `≤${fmt(dom[0] + (idx + 1) * w, 1)}`;
  }

  // 取得某軸上的類別清單（band 或即時分箱）
  function axisCats(scales, which, kHint) {
    const sc = scales[which];
    if (sc.__cats) return sc.__cats.slice();
    if (!sc.ticks) return [];
    const dom = sc.domain();
    const k = Math.max(2, Math.min(12, kHint || 4));
    const w = (dom[1] - dom[0]) / k;
    const out = [];
    for (let i = 0; i < k; i++) out.push(`≤${fmt(dom[0] + (i + 1) * w, 1)}`);
    return out;
  }
  function catKeyOfLinear(v, domain, k) {
    const w = (domain[1] - domain[0]) / k;
    return Math.min(k - 1, Math.max(0, Math.floor((v - domain[0]) / w)));
  }
  function timeScaleFor(col, domOv, range) {
    const vals = col ? col.values.filter((v) => v instanceof Date).map((v) => +v) : [];
    const dom = vals.length ? d3.extent(vals) : [Date.now() - 86400000, Date.now()];
    return d3.scaleTime().domain(domOv || [new Date(dom[0]), new Date(dom[1])]).range(range).nice();
  }
  function linearScaleFor(col, domOv, range) {
    const vals = col ? col.values.filter((v) => typeof v === "number" && isFinite(v)) : [];
    if (!vals.length) return d3.scaleLinear().domain(domOv || [0, 1]).range(range).nice();
    const dom = d3.extent(vals);
    const pad = (dom[1] - dom[0]) * 0.05 || Math.abs(dom[0] || 1) * 0.05 || 1;
    return d3.scaleLinear().domain(domOv || [dom[0] - pad, dom[1] + pad]).range(range).nice();
  }

  function computeMaxCount(cfg, rows) {
    const col = cfg.histOn === "y" ? cfg.yCol : cfg.xCol;
    if (!col && cfg.barCountMode && cfg.xCol) return countCats(cfg.xCol);
    if (!col) {
      // 只有 Y 連續、histOn 由外部決定時，退回全資料最大分箱
      return 1;
    }
    const all = [];
    const includeExcluded = true;
    for (const r of rows) { const v = col.values[r.__i]; if (typeof v === "number" && isFinite(v)) all.push(v); }
    if (!all.length) return 1;
    if (col.type === "continuous") {
      const [lo, hi] = d3.extent(all);
      const rule = (cfg.elOpts && cfg.elOpts.histogram && cfg.elOpts.histogram.binRule) || "sturges";
      const manual = cfg.elOpts && cfg.elOpts.histogram && cfg.elOpts.histogram.bins;
      const k = manual > 0 ? +manual : Math.max(3, Stats.binCount(all, null, rule === "auto" ? "fd" : rule));
      const bins = Stats.histBins(all, null, lo, hi, k);
      return Math.max(1, Math.max.apply(null, bins.map((b) => b.count)));
    }
    const counts = new Map();
    col.values.forEach((v) => { const k2 = String(v); counts.set(k2, (counts.get(k2) || 0) + 1); });
    return Math.max(1, Math.max.apply(null, Array.from(counts.values())));
  }

  function countCats(col) {
    const counts = new Map();
    col.values.forEach((v) => { const k = String(v); counts.set(k, (counts.get(k) || 0) + 1); });
    return Math.max(1, Math.max.apply(null, Array.from(counts.values())));
  }

  // 完全是「衍生圖形」的圖元（擬合線/密度等高線）：框選時整體變淡，讓被選到的資料突顯出來
  const DECOR_ELS = { smoother: true };

  async function draw(svgEl, ds, spec) {
    const svg = d3.select(svgEl);
    svg.selectAll("*").remove();
    if (global.GBSelect) global.GBSelect.beginMarks(svgEl);
    const box = svgEl.getBoundingClientRect();
    const W = Math.max(360, Math.round(box.width || spec.width || 900));
    const cfgAll = buildSpec(spec, ds);
    const els = cfgAll.elements;
    const mapMode = cfgAll.mapMode;

    const multiVar = !!cfgAll.multiVar;
    const stackX = cfgAll.stackX && cfgAll.stackX.length ? cfgAll.stackX : [cfgAll.x || null];
    const stackY = cfgAll.stackY && cfgAll.stackY.length ? cfgAll.stackY : [cfgAll.y || null];
    const wrapCol = cfgAll.wrapCol || null;
    const wrapCats = wrapCol ? catsInOrder(wrapCol, []) : [null];
    const margin = { top: 46, right: 118, bottom: 62, left: 70 };
    cfgAll.margin = margin;

    // 面板矩陣：X 的擺放順序＝由左而右，Y 的擺放順序＝由上而下（Wrap 再疊在 Y 方向）
    const cells = [];
    wrapCats.forEach((wrapVal, wi) => stackY.forEach((yk, yi) => stackX.forEach((xk, xi) => {
      cells.push({ wrapVal, xKey: xk, yKey: yk, row: multiVar ? wi * stackY.length + yi : 0, col: xi, wi, yi, xi });
    })));
    let cols, rows;
    if (multiVar) { cols = stackX.length; rows = stackY.length * wrapCats.length; }
    else { cols = Math.min(wrapCats.length, Math.max(1, Math.floor((W - margin.left - margin.right) / (mapMode ? 420 : 330)))); rows = Math.ceil(wrapCats.length / cols); }
    cells.forEach((c, i) => { if (!multiVar) { c.col = i % cols; c.row = Math.floor(i / cols); } });
    const rowGap = 26;
    const panelW = Math.max(220, (W - margin.left - margin.right) / cols);
    const panelH = mapMode
      ? Math.max(220, Math.min(420, panelW * 0.55))
      : multiVar
        ? Math.max(172, Math.min(420, (spec.height || 420) / rows))
        : Math.max(200, (spec.height || 420) / rows);
    const H = margin.top + panelH * rows + margin.bottom + (rows > 1 ? (rows - 1) * rowGap : 0);
    svg.attr("viewBox", `0 0 ${W} ${H}`).attr("width", W).attr("height", H);

    // 共用：以全資料決定座標域，讓同一組變數的各面板可比
    const allRows = activeRows(ds).filter((r) => !r.__excluded);
    const domCache = new Map();
    function domainsFor(pcfg) {
      const key = (pcfg.x || "") + "\u0000" + (pcfg.y || "");
      if (!domCache.has(key)) {
        const sc = makeScales(pcfg, allRows, panelW, panelH);
        domCache.set(key, { xd: sc.x.domain ? sc.x.domain() : null, yd: sc.y.domain ? sc.y.domain() : null });
      }
      return domCache.get(key);
    }
    const baseDomains = domainsFor(cfgAll);

    // 圖例群組（Color）
    const colorCol = cfgAll.colorCol;
    const colorCats = colorCol ? uniqueStrings(allRows.map((r) => colorCol.values[r.__i])) : [];
    if (colorCol && colorCol.type === "continuous") cfgAll.colorCol = null, cfgAll.color = cfgAll.color; // 連續色由圖元自行處理
    const colorFinal = cfgAll.colorCol ? cfgAll.colMap.get(cfgAll.color) : null;
    const colorKeys = colorFinal ? uniqueStrings(allRows.map((r) => colorFinal.values[r.__i])) : [];
    const color = colorScale(colorKeys.length ? colorKeys : ["__all__"]);
    const gkeys = colorKeys.length ? colorKeys : ["__all__"];

    const host = spec.host || (typeof window !== "undefined" && window.GBApp) || {};
    const tip = makeTip();
    const jobs = [];

    cells.forEach((cell) => {
      const cx = margin.left + cell.col * panelW;
      const cy = margin.top + cell.row * (panelH + (rows > 1 ? rowGap : 0));
      const wrapVal = cell.wrapVal;
      const pcfg = multiVar ? panelCfg(cfgAll, cell.xKey, cell.yKey) : cfgAll;
      const dom = multiVar ? domainsFor(pcfg) : baseDomains;
      const panelRows = wrapVal == null ? allRows : allRows.filter((r) => String(wrapCol.values[r.__i]) === String(wrapVal));
      const panel = svg.append("g").attr("class", "panel").attr("transform", `translate(${cx},${cy})`);
      panel.append("rect").attr("class", "panel-bg").attr("width", panelW).attr("height", panelH);
      const innerG = panel.append("g");
      const scales = makeScales(pcfg, allRows, panelW, panelH, dom.xd, dom.yd);
      const ctx = makeContext({ panel, innerG, scales, cfgAll: pcfg, ds, allRows: panelRows, color, gkeys, tip, panelW, panelH, host, small: wrapCats.length > 1 || rows > 2 });
      ctx.showXTitle = !multiVar || cell.row === rows - 1;   // X 軸標題只畫在最底一排
      ctx.showYTitle = true;
      if (!mapMode) drawAxes(innerG, ctx);
      // 由下而上繪製；每個圖元包在獨立的圖層 <g>，可單獨調透明度
      for (const el of els) {
        const def = defs[el];
        if (!def) continue;
        const opt = Object.assign({}, def.defaults, cfgAll.elOpts[el] || {});
        const alpha = opt.alpha == null ? 1 : Math.max(0, Math.min(1, +opt.alpha));
        const layerG = innerG.append("g").attr("class", "el-layer").attr("data-el", el);
        if (alpha < 1) layerG.attr("opacity", alpha);
        try {
          const ectx = ctx.withOpt(el, opt);
          ectx.g = layerG;
          const out = def.render(ectx);
          if (out && out.then) jobs.push(out);
        } catch (err) { console.warn("element render failed:", el, err); }
        if (DECOR_ELS[el]) ctx.sel(layerG, [], { decor: true, lit: false });   // 整層都是擬合/衍生圖形
      }
      if (wrapVal != null) {
        panel.append("text").attr("class", "panel-title").attr("x", 0).attr("y", -10).text(`${wrapCol.key} = ${wrapVal}`);
      }
    });

    await Promise.all(jobs);

    // 標題
    const titleNode = svg.append("text").attr("class", "chart-title").attr("x", W / 2).attr("y", 24)
      .text(spec.title || titleFor(cfgAll, els));
    fitTitle(titleNode, W - 20);

    // 圖例
    if (cfgAll.legend && colorFinal && colorKeys.length && colorKeys.length <= 24) {
      const lg = svg.append("g").attr("class", "legend")
        .attr("transform", `translate(${W - margin.right + 18},${margin.top + 4})`);
      lg.append("text").attr("class", "legend-title").text(colorFinal.key);
      colorKeys.forEach((k, i) => {
        const item = lg.append("g").attr("transform", `translate(0,${16 + i * 17})`).style("cursor", "pointer");
        item.append("rect").attr("width", 11).attr("height", 11).attr("rx", 2).attr("fill", color(k));
        item.append("text").attr("class", "legend-text").attr("x", 16).attr("y", 9.5).text(k);
        item.on("click", () => host.toggleHiddenGroup && host.toggleHiddenGroup(k));
        if (host.hiddenGroups && host.hiddenGroups.has(k)) item.style("opacity", 0.32);
      });
    }
    if (!allRows.length) {
      svg.append("text").attr("class", "fit-note-text").attr("x", W / 2).attr("y", H / 2).attr("text-anchor", "middle")
        .text("沒有可用的資料列（全部被排除，或變數資料缺失）");
    }
    // 跨圖連動框選：綁定拖曳框選 + 重新套用目前的框選狀態
    if (global.GBSelect) {
      global.GBSelect.attach(svgEl, {
        chartId: spec.chartId || "main",
        label: spec.chartLabel || spec.title || titleFor(cfgAll, els)
      });
    }
    return { W, H };
  }

  // 標題太長時先縮小字級，還是不行就用省略號（避免超出畫布）
  function fitTitle(node, maxWidth) {
    let el = node.node();
    if (!el) return;
    let size = 14.5;
    try {
      while (el.getBBox().width > maxWidth && size > 11) {
        size -= 0.75;
        node.style("font-size", size.toFixed(1) + "px");   // 用 inline style：CSS 樣式表會蓋掉 presentation attribute
      }
      let txt = node.text();
      while (txt.length > 6 && el.getBBox().width > maxWidth) {
        txt = txt.slice(0, Math.max(6, txt.length - 3)) + "…";
        node.text(txt);
      }
    } catch (e) { /* getBBox 在離線/隐藏時可能失敗，忽略 */ }
  }

  function titleFor(cfg, els) {
    const names = els.map((e) => defs[e] ? defs[e].label : e).join(" + ");
    if (els.length === 1 && els[0] === "sankey") {
      const m = cfg.sankeyMode;
      const tgt = m && m.kind === "wide" ? m.cols.slice(1).join("、") : (cfg.y || "目標");
      return `桑基圖：${cfg.x || "來源"} → ${tgt}`;
    }
    if (els.length === 1 && els[0] === "pie") return `圓餅圖：${cfg.x || cfg.y || cfg.color || "變數"}`;
    // 多個 X / Y 變數：用 JMP 的寫法「Y1 & Y2 對 X1 & X2」（順序＝區塊擺放順序）
    const yList = (cfg.yKeys && cfg.yKeys.length ? cfg.yKeys : (cfg.y ? [cfg.y] : [])).slice();
    const xList = (cfg.xKeys && cfg.xKeys.length ? cfg.xKeys : (cfg.x ? [cfg.x] : [])).slice();
    const ys = yList.join(" & "), xs = xList.join(" & ");
    return `${ys ? ys + " 對 " : ""}${xs || "變數"}  ${names ? "（" + names + "）" : ""}`;
  }

  // 往上找最近的「框選註記」（由 GBSelect 寫在圖元節點上）
  function selNoteOf(node) {
    let n = node;
    while (n && n.nodeType === 1) {
      if (n.__gbSelNote) return n.__gbSelNote;
      if (n.tagName === "svg") break;
      n = n.parentNode;
    }
    return null;
  }

  function makeTip() {
    let el = document.getElementById("gb-tip");
    if (!el) {
      el = document.createElement("div");
      el.id = "gb-tip";
      document.body.appendChild(el);
    }
    return {
      show(ev, text) {
        if (!text) return;
        if (global.GBSelect && global.GBSelect.brushing()) return;   // 拖曳框選中不彈提示框
        const note = selNoteOf(ev && ev.target);
        if (note) text = text + "\n" + note;
        el.innerHTML = String(text).split("\n").map((l, i) => (i === 0 ? `<b>${esc(l)}</b>` : esc(l))).join("<br>");
        el.style.opacity = 1;
        const pad = 14;
        const w = el.offsetWidth, h = el.offsetHeight;
        let x = ev.clientX + pad, y = ev.clientY + pad;
        if (x + w > window.innerWidth - 8) x = ev.clientX - w - pad;
        if (y + h > window.innerHeight - 8) y = ev.clientY - h - pad;
        el.style.left = x + "px"; el.style.top = y + "px";
      },
      hide() { el.style.opacity = 0; }
    };
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  function makeContext(o) {
    const { panel, innerG, scales, cfgAll, ds, allRows, color, gkeys, tip, panelW, panelH, small, host = {} } = o;
    const ctx = {
      svg: d3.select(panel.node().ownerSVGElement),
      panel, g: innerG, scales, cfg: cfgAll, rows: allRows, color, gkeys, tip,
      inner: { w: panelW, h: panelH },
      small,
      xDisc: cfgAll.xDisc, yDisc: cfgAll.yDisc, xTime: cfgAll.xTime,
      xContinuous: cfgAll.xContinuous,
      yContinuous: cfgAll.yContinuous,
      yHasZero: true,
      xCats: scales.x.__cats || (scales.x.domain ? scales.x.domain().map(String) : []),
      yCats: scales.y.__cats || (scales.y.domain ? scales.y.domain().map(String) : []),
      opt: {},
      isExcluded: (r) => r.__excluded,
      toggleExclude: (i) => {
        if (ds.excluded.has(i)) ds.excluded.delete(i); else ds.excluded.add(i);
        host.rerenderSoon && host.rerenderSoon(0);
        host.updateStatus && host.updateStatus();
      },
      freqW(r) {
        if (!cfgAll.freqCol) return 1;
        const v = +cfgAll.freqCol.values[r.__i];
        return isFinite(v) && v > 0 ? v : 0;
      },
      groups(rows) {
        const col = cfgAll.colorCol;
        const out = new Map();
        if (!col) { out.set("__all__", rows); return out; }
        for (const r of rows) {
          const k = col.values[r.__i] == null ? "(缺失)" : String(col.values[r.__i]);
          if (host.hiddenGroups && host.hiddenGroups.has(k)) continue;
          if (!out.has(k)) out.set(k, []);
          out.get(k).push(r);
        }
        return out;
      },
      numsOf(rows, col) {
        const out = [];
        for (const r of rows) { const v = col.values[r.__i]; if (typeof v === "number" && isFinite(v)) out.push(v); }
        return out;
      },
      pairs(rows, xCol, yCol) {
        const xs = [], ys = [], ws = [];
        for (const r of rows) {
          let x = xCol.values[r.__i]; const y = yCol.values[r.__i];
          if (x instanceof Date) x = +x;
          if (typeof x !== "number" || typeof y !== "number" || !isFinite(x) || !isFinite(y)) continue;
          const w = ctx.freqW(r);
          if (!(w > 0)) continue;
          xs.push(x); ys.push(y); ws.push(w);
        }
        return { xs, ys, ws };
      },
      catsOf(col) { return uniqueStrings(col.values.filter((v) => v != null)); },
      colByKey(k) { return cfgAll.colMap.get(k); },
      rowTip(r) {
        const keys = [];
        for (const k of [cfgAll.x, cfgAll.y, cfgAll.color, cfgAll.size, cfgAll.label, cfgAll.freq]) {
          if (k && !keys.includes(k)) keys.push(k);
        }
        const lines = [];
        for (const k of keys) {
          const c = cfgAll.colMap.get(k);
          if (!c) continue;
          const v = c.values[r.__i];
          if (v == null) continue;
          lines.push(`${k}：${v instanceof Date ? fmtDate(v) : (typeof v === "number" ? fmt(v) : v)}`);
        }
        lines.push(`列 #${r.__i + 1}${r.__excluded ? "（已排除）" : ""}`);
        return lines.join("\n");
      },
      tipOn(ev, text) { tip.show(ev, text); },
      tip: null,
      tipOff() { tip.hide(); },
      highlightCategory(key, value) { host.flashFilter && host.flashFilter(key, value); },
      toggleRows(list) {
        if (!list || !list.length) return;
        const on = list.some((r) => !ds.excluded.has(r.__i));
        for (const r of list) { if (on) ds.excluded.add(r.__i); else ds.excluded.delete(r.__i); }
        host.rerenderSoon && host.rerenderSoon(0);
        host.updateStatus && host.updateStatus();
      },
      // ---- 跨圖框選：登記「這個圖元代表哪些資料列」（GBSelect 用它做框選與連動淡出）----
      // target: d3 selection 或 DOM 節點（null＝只做命中測試的合成點，需給 space）
      // rows:   單列 / 列陣列 / 索引陣列；o.kind: point|area|path|null（null＝只淡出不參與命中）
      sel(target, rows, o) {
        const S = global.GBSelect;
        if (!S) return;
        o = o || {};
        const node = target && typeof target.node === "function" ? target.node() : target;
        const list = rows == null ? [] : (Array.isArray(rows) ? rows : [rows]);
        const idx = [];
        const seen = new Set();
        for (const r of list) {
          const i = (r && typeof r === "object") ? r.__i : r;
          if (typeof i !== "number" || seen.has(i)) continue;
          seen.add(i); idx.push(i);
        }
        if (!idx.length && !o.decor) return;
        const vnode = o.hitOnly ? null : (node || null);
        const space = o.space ? (typeof o.space.node === "function" ? o.space.node() : o.space)
          : (vnode ? vnode.parentNode : panel.node());
        let x = o.x, y = o.y, w = o.w, h = o.h, rad = o.r;
        if (vnode && x == null) {
          if (o.kind === "point") {
            x = parseFloat(vnode.getAttribute("cx"));
            y = parseFloat(vnode.getAttribute("cy"));
            rad = parseFloat(vnode.getAttribute("r")) || 3;
          } else {
            try { const bb = vnode.getBBox(); x = bb.x; y = bb.y; w = bb.width; h = bb.height; } catch (e) { x = null; }
          }
        }
        if (idx.length && !isFinite(x) && o.kind) return;
        S.register(panel.node().ownerSVGElement, {
          node: vnode, parent: space, rows: idx, kind: o.kind || null,
          decor: !!o.decor, lit: o.lit, anchor: o.anchor || null,
          x, y, w, h, r: rad
        });
      },
      topo: async () => {
        if (window.__gbTopo !== undefined) return window.__gbTopo;
        try {
          const res = await fetch("assets/world-110m.json");
          window.__gbTopo = res.ok ? await res.json() : null;
        } catch (e) { window.__gbTopo = null; }
        return window.__gbTopo;
      },
      dodge: cfgAll.grouping === "side",
      withOpt(el, opt) {
        const c = Object.create(ctx);
        c.opt = opt;
        c.el = el;
        return c;
      }
    };
    ctx.tip = (ev, text) => tip.show(ev, text);
    ctx.dodge = cfgAll.grouping === "side" && gkeys.length > 1;
    return ctx;
  }

  function drawAxes(g, ctx) {
    const { inner, scales, cfg } = ctx;
    const { w, h } = inner;
    if (scales.hideAxes) return;
    const yTicks = Math.max(3, Math.min(8, Math.round(h / 52)));
    const xTicks = Math.max(3, Math.min(9, Math.round(w / 92)));
    const gridY = g.append("g").attr("class", "grid");
    const yDom = scales.y.bandwidth ? scales.y.domain() : scales.y.ticks(yTicks);
    gridY.selectAll("line").data(yDom).join("line")
      .attr("x1", 0).attr("x2", w).attr("y1", (d) => lineY(d)).attr("y2", (d) => lineY(d));
    function lineY(d) { return scales.y.bandwidth ? scales.y(d) + scales.yBandWidth / 2 : scales.y(d); }
    function lineX(d) { return scales.x.bandwidth ? scales.x(d) + scales.xBandWidth / 2 : scales.x(d); }
    const gridX = g.append("g").attr("class", "grid");
    const xDom = scales.x.bandwidth ? scales.x.domain() : scales.x.ticks(xTicks);
    gridX.selectAll("line").data(xDom).join("line")
      .attr("y1", 0).attr("y2", h).attr("x1", (d) => lineX(d)).attr("x2", (d) => lineX(d));

    const ax = d3.axisBottom(scales.x).tickSizeOuter(0);
    if (!scales.x.bandwidth) ax.ticks(xTicks);
    if (ctx.xTime) ax.tickFormat((d) => d3.timeFormat(smartTimeFmt(scales.x.domain()))(d));
    g.append("g").attr("class", "axis").attr("transform", `translate(0,${h})`).call(ax)
      .selectAll("text").each(function (d) {
        const t = d3.select(this);
        if (scales.x.bandwidth && String(d).length > 7) t.attr("transform", "rotate(-32)").style("text-anchor", "end").attr("dx", "-0.4em").attr("dy", "0.5em");
      });
    const ay = d3.axisLeft(scales.y).tickSizeOuter(0);
    if (!scales.y.bandwidth) ay.ticks(yTicks);
    g.append("g").attr("class", "axis").call(ay);

    // 計數軸（直方圖／次數長條）與其對面的值軸標題
    const countIsY = cfg.histOn === "x" || cfg.barCountMode;
    const countIsX = cfg.histOn === "y";
    let xTitle, yTitle;
    if (countIsY) { xTitle = cfg.histValueName || cfg.x || ""; yTitle = "次數"; }
    else if (countIsX) { xTitle = "次數"; yTitle = cfg.histValueName || cfg.y || ""; }
    else { xTitle = cfg.x || ""; yTitle = cfg.y || ""; }
    // 多個 X / Y 變數時，軸標題帶上面板順序（與區塊內的擺放順序一致）
    if (cfg.multiVar && cfg.stackY && cfg.stackY.length > 1 && yTitle) {
      const i = cfg.stackY.indexOf(cfg.y);
      yTitle = `${i + 1}. ${yTitle}`;
    }
    if (cfg.multiVar && cfg.stackX && cfg.stackX.length > 1 && xTitle) {
      const i = cfg.stackX.indexOf(cfg.x);
      xTitle = `${i + 1}. ${xTitle}`;
    }
    if (ctx && ctx.showXTitle === false) xTitle = "";
    if (xTitle) g.append("text").attr("class", "axis-title").attr("x", w / 2).attr("y", h + 38).attr("text-anchor", "middle").text(xTitle);
    if (yTitle) g.append("text").attr("class", "axis-title").attr("transform", `translate(${-48},${h / 2}) rotate(-90)`).attr("text-anchor", "middle").text(yTitle);
  }
  function smartTimeFmt(domain) {
    const span = Math.abs(+domain[1] - +domain[0]) / 86400000;
    if (span > 700) return "%Y";
    if (span > 60) return "%Y-%m";
    if (span > 2) return "%m-%d";
    return "%m-%d %H:%M";
  }

  global.GBElements = { defs, order, colorScale, fmt, fmtDate, statFn, STAT_NAMES, draw, uniqueStrings, catsInOrder };
})(typeof window !== "undefined" ? window : globalThis);
