/* Graph Builder — 統計工具（加權、分位數、LOESS、平滑樣條、等高線密度、馬賽克配置） */
(function (global) {
  "use strict";

  // ---------- 基本加權統計 ----------
  function expand(rows, freqKey) {
    // freq 權重：不回傳展開後的陣列，而是回傳 (value, weight) 對
    const out = [];
    for (const r of rows) {
      const w = freqKey ? +r[freqKey] : 1;
      if (isFinite(w) && w > 0) out.push([r, w]);
    }
    return out;
  }

  function wsum(pairs) {
    return pairs.reduce((a, p) => a + p[1], 0);
  }

  function wmean(values, weights) {
    let n = 0, s = 0;
    for (let i = 0; i < values.length; i++) {
      const v = values[i], w = weights ? weights[i] : 1;
      if (v == null || !isFinite(v) || w <= 0) continue;
      n += w; s += w * v;
    }
    return n > 0 ? s / n : null;
  }

  function wquantile(values, weights, q) {
    const pts = [];
    let n = 0;
    for (let i = 0; i < values.length; i++) {
      const v = values[i], w = weights ? weights[i] : 1;
      if (v == null || !isFinite(v) || w <= 0) continue;
      pts.push([v, w]); n += w;
    }
    if (!n) return null;
    pts.sort((a, b) => a[0] - b[0]);
    const target = q * (n - 1) + 0.5; // 加權中位數式位置
    let acc = 0;
    for (let i = 0; i < pts.length; i++) {
      acc += pts[i][1];
      if (acc >= target) return pts[i][0];
    }
    return pts[pts.length - 1][0];
  }

  function wvariance(values, weights) {
    const m = wmean(values, weights);
    if (m == null) return { var: null, sd: null, n: 0 };
    let n = 0, ss = 0;
    for (let i = 0; i < values.length; i++) {
      const v = values[i], w = weights ? weights[i] : 1;
      if (v == null || !isFinite(v) || w <= 0) continue;
      n += w; ss += w * (v - m) * (v - m);
    }
    const variance = n > 1 ? ss / (n - 1) : null;
    return { var: variance, sd: variance == null ? null : Math.sqrt(variance), n };
  }

  // 單尾 t 臨界值（Welch–Askey 近似，足夠給信賴區間用）
  function tCrit(df, alpha2) {
    if (!isFinite(df) || df <= 0) return NaN;
    const p = 1 - alpha2;
    // 正態近似（取正值上側臨界值）
    const norm = Math.abs(qnorm(p));
    if (df > 200) return norm;
    // Cornish–Fisher 修正
    const g1 = (norm ** 3 + norm) / 4;
    const g2 = (5 * norm ** 5 + 16 * norm ** 3 + 3 * norm) / 96;
    const g3 = (3 * norm ** 7 + 19 * norm ** 5 + 17 * norm ** 3 - 15 * norm) / 384;
    const g4 = (79 * norm ** 9 + 776 * norm ** 7 + 1482 * norm ** 5 - 1920 * norm ** 3 - 945 * norm) / 92160;
    const inv = 1 / df;
    return norm + g1 * inv + g2 * inv ** 2 + g3 * inv ** 3 + g4 * inv ** 4;
  }

  function qnorm(p) {
    // Acklam 逆常態
    const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
    const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
    const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
    const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
    const pl = 0.02425, ph = 1 - pl;
    let q, r;
    if (p < pl) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    if (p > ph) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    q = p - 0.5; r = q * q;
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }

  // 平均數信賴區間（t 分配）
  function meanCI(values, weights, level) {
    const { var: v, n } = wvariance(values, weights);
    const m = wmean(values, weights);
    if (m == null || v == null || n < 2) return { mean: m, lo: null, hi: null, n };
    const se = Math.sqrt(v / n);
    const t = tCrit(n - 1, (1 + level) / 2);
    return { mean: m, lo: m - t * se, hi: m + t * se, se, n };
  }

  // ---------- 直方圖分箱 ----------
  function binCount(values, weights, rule) {
    const v = values.filter((x) => isFinite(x));
    const n = weights ? wsum(values.map((x, i) => [x, weights[i]]).filter((p) => isFinite(p[0]))) : v.length;
    if (!v.length) return 10;
    if (rule === "sturges") return Math.max(1, Math.ceil(Math.log2(n) + 1));
    if (rule === "fd") {
      const q1 = wquantile(values, weights, 0.25), q3 = wquantile(values, weights, 0.75);
      const iqr = q3 - q1;
      const h = 2 * iqr * Math.pow(n, -1 / 3);
      if (h > 0) return Math.max(1, Math.min(200, Math.ceil((d3max(v) - d3min(v)) / h)));
    }
    if (rule === "sqrt") return Math.max(1, Math.ceil(Math.sqrt(n)));
    return 10;
  }
  const d3max = (a) => a.reduce((x, y) => (y > x ? y : x), -Infinity);
  const d3min = (a) => a.reduce((x, y) => (y < x ? y : x), Infinity);

  function histBins(values, weights, lo, hi, k) {
    const bins = [];
    const w = (hi - lo) / k || 1;
    for (let i = 0; i < k; i++) bins.push({ x0: lo + i * w, x1: lo + (i + 1) * w, count: 0, values: [] });
    for (let i = 0; i < values.length; i++) {
      const v = values[i], wt = weights ? weights[i] : 1;
      if (!isFinite(v) || wt <= 0) continue;
      let idx = Math.floor((v - lo) / w);
      if (idx < 0) idx = 0;
      if (idx >= k) idx = k - 1;
      bins[idx].count += wt;
      bins[idx].values.push(v);
    }
    return bins;
  }

  // ---------- 線性回歸 ----------
  function linreg(xs, ys, ws) {
    let n = 0, sx = 0, sy = 0, sxx = 0, sxy = 0, syy = 0;
    for (let i = 0; i < xs.length; i++) {
      const w = ws ? ws[i] : 1;
      const x = xs[i], y = ys[i];
      if (!isFinite(x) || !isFinite(y) || w <= 0) continue;
      n += w; sx += w * x; sy += w * y; sxx += w * x * x; sxy += w * x * y; syy += w * y * y;
    }
    if (n < 2) return null;
    const den = n * sxx - sx * sx;
    if (!isFinite(den) || den === 0) return null;
    const slope = (n * sxy - sx * sy) / den;
    const intercept = (sy - slope * sx) / n;
    const sse = syy - 2 * slope * sxy - 2 * intercept * sy + slope * slope * sxx + 2 * slope * intercept * sx + n * intercept * intercept;
    const sst = syy - (sy * sy) / n;
    const df = n - 2;
    const mse = df > 0 ? sse / df : null;
    const seSlope = mse != null && den > 0 ? Math.sqrt(mse * (n / den)) : null;
    return { slope, intercept, r2: sst > 0 ? 1 - sse / sst : null, n, mse, seSlope, df };
  }

  // ---------- 線性代數（對稱正定求解 + 求逆） ----------
  function solveSPD(A, b) {
    const n = b.length;
    const M = A.map((row, i) => row.slice().concat([b[i]]));
    for (let c = 0; c < n; c++) {
      let piv = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
      if (Math.abs(M[piv][c]) < 1e-14) M[c][c] += 1e-8; // 微弱脊化
      if (piv !== c) { const t = M[c]; M[c] = M[piv]; M[piv] = t; }
      const d = M[c][c];
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const f = M[r][c] / d;
        if (!f) continue;
        for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
      }
    }
    return M.map((row, i) => row[n] / row[i]);
  }

  function inverseSPD(A) {
    const n = A.length;
    const cols = [];
    for (let j = 0; j < n; j++) {
      const e = new Array(n).fill(0); e[j] = 1;
      cols.push(solveSPD(A, e));
    }
    // cols[j][i] = (A^-1)[i][j]
    const out = A.map((_, i) => cols.map((c) => c[i]));
    return out;
  }

  // ---------- LOESS ----------
  function loess(xs, ys, ws, span, degree, evaluateAt) {
    const n = xs.length;
    if (n < 3) return null;
    const idx = xs.map((x, i) => i).filter((i) => isFinite(xs[i]) && isFinite(ys[i]) && (!ws || (isFinite(ws[i]) && ws[i] > 0)));
    if (idx.length < 3) return null;
    const xv = idx.map((i) => xs[i]);
    const yv = idx.map((i) => ys[i]);
    const wv = idx.map((i) => (ws ? ws[i] : 1));
    const sorted = xv.slice().sort((a, b) => a - b);
    const h = Math.max(2, Math.min(idx.length, Math.floor(span * idx.length)));
    const out = [];
    for (const x0 of evaluateAt) {
      // 取 h 個最近邻
      const order = xv.map((x, i) => [Math.abs(x - x0), i]).sort((a, b) => a[0] - b[0]).slice(0, h);
      const dmax = order[order.length - 1][0] || 1e-9;
      const tri = (u) => Math.pow(1 - Math.pow(u, 3), 3);
      let sumW = 0;
      const rows = [], rhs = [];
      const p = degree + 1;
      const A = Array.from({ length: p }, () => new Array(p).fill(0));
      const b = new Array(p).fill(0);
      const used = [];
      for (const [dist, i] of order) {
        const k = tri(dist / dmax) * wv[i];
        if (!(k > 1e-12)) continue;
        used.push([i, k]);
        sumW += k;
      }
      if (used.length < p + 1) continue;
      for (const [i, k] of used) {
        const u = xv[i] - x0, y = yv[i];
        const z = [1];
        for (let j = 1; j < p; j++) z.push(Math.pow(u, j));
        for (let r = 0; r < p; r++) {
          b[r] += k * z[r] * y;
          for (let c = 0; c < p; c++) A[r][c] += k * z[r] * z[c];
        }
      }
      let beta;
      try { beta = solveSPD(A, b); } catch (e) { continue; }
      const yhat = beta[0];
      // 殘差與有效樣本量（tricube 加權）
      let rss = 0, wtot = 0, wss = 0;
      for (const [i, k] of used) {
        const u = xv[i] - x0;
        let f = beta[0];
        for (let j = 1; j < p; j++) f += beta[j] * Math.pow(u, j);
        rss += k * (yv[i] - f) * (yv[i] - f);
        wtot += k; wss += k * k;
      }
      const neff = wss > 0 ? (wtot * wtot) / wss : used.length;
      const s2v = neff > 2 ? rss / (neff - 2) : null;
      let se = null;
      if (s2v != null) {
        try {
          const Ainv = inverseSPD(A);
          se = Math.sqrt(Math.max(0, s2v * Ainv[0][0]));
        } catch (e) { se = null; }
      }
      out.push({ x: x0, y: yhat, se, nEff: neff });
    }
    return out.length ? out : null;
  }

  // ---------- 立方平滑樣條（懲罰回歸樣條） ----------
  function smoothingSpline(xs, ys, ws, lambda, knots, evaluateAt) {
    const idx = xs.map((x, i) => i).filter((i) => isFinite(xs[i]) && isFinite(ys[i]) && (!ws || (isFinite(ws[i]) && ws[i] > 0)));
    if (idx.length < 4) return null;
    const xv = idx.map((i) => xs[i]), yv = idx.map((i) => ys[i]), wv = idx.map((i) => (ws ? ws[i] : 1));
    const K = knots.length;
    const basis = (x) => {
      const b = [1, x];
      for (let k = 0; k < K; k++) { const d = Math.max(0, x - knots[k]); b.push(d * d * d); }
      return b;
    };
    const p = 2 + K;
    // 二階導數懲罰矩陣（對多項式部分為 0）
    const S = Array.from({ length: p }, () => new Array(p).fill(0));
    for (let i = 0; i < K; i++) {
      for (let j = 0; j < K; j++) {
        const a = knots[i], bq = knots[j], m = Math.max(a, bq);
        const val = a * bq - (a + bq) * m + m * m; // ∫ (x-a)_+ (x-b)_+ 的二階導內積 = 6* 上式
        S[2 + i][2 + j] = 6 * val;
      }
    }
    const A = Array.from({ length: p }, () => new Array(p).fill(0));
    const b = new Array(p).fill(0);
    let sw = 0;
    for (let i = 0; i < xv.length; i++) {
      const z = basis(xv[i]), w = wv[i];
      sw += w;
      for (let r = 0; r < p; r++) {
        b[r] += w * z[r] * yv[i];
        for (let c = 0; c < p; c++) A[r][c] += w * z[r] * z[c];
      }
    }
    // lambda 相對縮放：乘以樣本量讓 span 直覺化
    const scale = sw;
    for (let r = 0; r < p; r++) for (let c = 0; c < p; c++) A[r][c] += lambda * scale * S[r][c];
    let beta;
    try { beta = solveSPD(A, b); } catch (e) { return null; }
    let rss = 0;
    for (let i = 0; i < xv.length; i++) {
      const z = basis(xv[i]);
      let f = 0; for (let r = 0; r < p; r++) f += beta[r] * z[r];
      rss += wv[i] * (yv[i] - f) ** 2;
    }
    const df = p; // 近似有效自由度
    const s2v = xv.length > df ? rss / (xv.length - df) : null;
    let Ainv = null;
    if (s2v != null) { try { Ainv = inverseSPD(A); } catch (e) { Ainv = null; } }
    return evaluateAt.map((x0) => {
      const z = basis(x0);
      let f = 0; for (let r = 0; r < p; r++) f += beta[r] * z[r];
      let se = null;
      if (Ainv) { let v = 0; for (let r = 0; r < p; r++) for (let c = 0; c < p; c++) v += z[r] * Ainv[r][c] * z[c]; se = Math.sqrt(Math.max(0, s2v * v)); }
      return { x: x0, y: f, se };
    });
  }

  // ---------- 2D 核密度 + 等高線 ----------
  function kde2d(xs, ys, ws, xDomain, yDomain, nx, ny, bandwidth) {
    const n = xs.length;
    if (!n) return null;
    const sx = bandwidth[0], sy = bandwidth[1];
    const [x0, x1] = xDomain, [y0, y1] = yDomain;
    const dx = (x1 - x0) / (nx - 1), dy = (y1 - y0) / (ny - 1);
    const pts = [];
    for (let i = 0; i < n; i++) {
      const w = ws ? ws[i] : 1;
      if (isFinite(xs[i]) && isFinite(ys[i]) && w > 0) pts.push([xs[i], ys[i], w]);
    }
    if (!pts.length) return null;
    const grid = [];
    for (let j = 0; j < ny; j++) {
      const row = new Array(nx).fill(0);
      const gy = y0 + j * dy;
      for (const [px, py, w] of pts) {
        const vy = Math.exp(-0.5 * Math.pow((gy - py) / sy, 2));
        if (vy < 1e-6) continue;
        const gx0 = Math.max(0, Math.floor((px - 3 * sx - x0) / dx));
        const gx1 = Math.min(nx - 1, Math.ceil((px + 3 * sx - x0) / dx));
        for (let i = gx0; i <= gx1; i++) {
          row[i] += w * vy * Math.exp(-0.5 * Math.pow((x0 + i * dx - px) / sx, 2));
        }
      }
      grid.push(row);
    }
    // 正規化到 0..1
    let max = 0;
    for (const row of grid) for (const v of row) if (v > max) max = v;
    if (max > 0) for (const row of grid) for (let i = 0; i < row.length; i++) row[i] /= max;
    return { values: grid, nx, ny, x0, x1, y0, y1 };
  }

  // ---------- 馬賽克配置 ----------
  function mosaicLayout(counts, levelsX, levelsY) {
    // counts[iz][ix]，回傳矩形（x、y 皆 0..1）
    const X = levelsX.length, Y = levelsY.length;
    const colTotals = new Array(X).fill(0);
    let grand = 0;
    for (let iz = 0; iz < Y; iz++) for (let ix = 0; ix < X; ix++) {
      const v = counts[iz] && counts[iz][ix] ? counts[iz][ix] : 0;
      colTotals[ix] += v; grand += v;
    }
    if (!grand) return { rects: [], grand: 0 };
    const rects = [];
    let x = 0;
    for (let ix = 0; ix < X; ix++) {
      const w = colTotals[ix] / grand;
      let y = 0;
      for (let iz = 0; iz < Y; iz++) {
        const v = counts[iz] && counts[iz][ix] ? counts[iz][ix] : 0;
        const h = colTotals[ix] > 0 ? v / colTotals[ix] : 0;
        if (v > 0) rects.push({ ix, iz, x, y, w, h, count: v, share: v / grand });
        y += h;
      }
      x += w;
    }
    return { rects, grand };
  }

  global.Stats = {
    expand, wsum, wmean, wquantile, wvariance, meanCI, tCrit, qnorm,
    binCount, histBins, linreg, loess, smoothingSpline, kde2d, mosaicLayout,
    min: d3min, max: d3max
  };
})(typeof window !== "undefined" ? window : globalThis);
