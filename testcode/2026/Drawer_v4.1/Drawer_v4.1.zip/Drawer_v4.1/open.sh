#!/usr/bin/env bash
# 啟動網頁版 Graph Builder：啟動本機伺服器（本機資源，離線可用）並開啟瀏覽器
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-8848}"

open_url() {
  local url="$1"
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "$url" >/dev/null 2>&1 || true
  elif command -v open >/dev/null 2>&1; then open "$url"
  else echo "請手動開啓：$url"
  fi
}

if curl -s -o /dev/null --max-time 1 "http://127.0.0.1:${PORT}/index.html"; then
  echo "Graph Builder 已在執行：http://127.0.0.1:${PORT}/"
else
  echo "啟動本機伺服器（埠 ${PORT}，僅綁定 127.0.0.1）…"
  nohup python3 -m http.server "${PORT}" --bind 127.0.0.1 >"/tmp/graph-builder-${PORT}.log" 2>&1 &
  sleep 1
  echo "已啟動：http://127.0.0.1:${PORT}/"
fi
open_url "http://127.0.0.1:${PORT}/index.html"
