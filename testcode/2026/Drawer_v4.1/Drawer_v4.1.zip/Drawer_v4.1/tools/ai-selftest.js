#!/usr/bin/env node
/* AI 自動分析引擎的自我檢驗：不需要瀏覽器，直接跑所有內建資料 + 邊界情況。
   用法：  node tools/ai-selftest.js            （看每張資料找到哪些圖）
           node tools/ai-selftest.js --json     （只輸出機器可讀的摘要）           */
const path = require("path");
const DIR = path.join(__dirname, "..", "assets");
require(path.join(DIR, "stats.js"));
require(path.join(DIR, "data.js"));
require(path.join(DIR, "insight.js"));

const { GBData, GBInsight } = globalThis;
const asJson = process.argv.indexOf("--json") >= 0;
let fails = 0;

function check(cond, msg) { if (!cond) { fails++; if (!asJson) console.error("  ✗ " + msg); } }

function run(name) {
  const ds = GBData.SAMPLES[name]();
  const res = GBInsight.analyze(ds, { freqKey: GBData.autoKeys(ds.columns).freq[0] || null });
  check(res.cards.length >= 1, name + "：一張都沒找到");
  res.cards.forEach((c) => {
    check(!!c.spec && !!c.spec.zones && Object.keys(c.spec.elements).length > 0, name + "：" + c.title + " 缺少圖形規格");
    check(c.tags.length > 0 && c.detail.length > 20, name + "：" + c.title + " 缺少證據文字");
    Object.values(c.spec.zones).flat().forEach((k) => {
      check(ds.columns.some((col) => col.key === k), name + "：" + c.title + " 引用了不存在的欄位 " + k);
    });
  });
  if (asJson) {
    console.log(JSON.stringify({
      data: name, rows: ds.rows.length, cols: ds.columns.length, ms: res.ms,
      cards: res.cards.map((c) => ({ kind: c.kind, score: +c.score.toFixed(2), title: c.title, tags: c.tags }))
    }));
    return;
  }
  console.log("\n══════ " + name + " ══════ " + ds.rows.length + " 列 × " + ds.columns.length + " 欄（" + res.ms + " ms）");
  res.cards.forEach((c, i) => {
    console.log(`  [${i + 1}] ${c.kind} · 強度 ${c.score.toFixed(2)}  ${c.title}`);
    console.log(`      ${c.tags.join(" · ")}`);
  });
  if (res.notes.length) console.log("  NOTE: " + res.notes.join(" / "));
}

Object.keys(GBData.SAMPLES).forEach(run);

// ---- 邊界情況：不該丟錯、不該硬湊圖 ----
const cases = [
  ["空表", GBData.buildDataset("e", []), 0],
  ["單欄", GBData.buildDataset("o", GBData.parseCSV("a\n1\n2\n3\n4\n5")), 0],
  ["一列", GBData.buildDataset("one", [{ A: 1, B: 2 }]), 0],
  ["含全缺失欄", GBData.buildDataset("m", GBData.parseCSV("a,b,c\n1,,x\n2,,x\n3,,y\n1,,x\n2,,y\n3,,x\n4,,x\n5,,y")), 0]
];
cases.forEach(([label, ds, expectMax]) => {
  let res = null, err = null;
  try { res = GBInsight.analyze(ds, {}); } catch (e) { err = e; }
  check(!err, label + "：拋出例外 " + (err && err.message));
  check(res && res.cards.length <= expectMax, label + `：應該 ≤ ${expectMax} 張，實際 ${res && res.cards.length}`);
  if (!asJson) console.log(`\n邊界 ${label}: ${res ? res.cards.length + " 張卡" : "失敗"} ${res && res.notes.length ? "· " + res.notes.join(" / ") : ""}`);
});

// ---- 純隨機資料：不該聲稱找到顯著關係 ----
let seed = 7;
const rnd = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648; };
const noise = GBData.buildDataset("noise", Array.from({ length: 400 }, () => ({
  x: rnd() * 10, y: rnd() * 10, z: rnd() * 10, g: ["a", "b", "c"][Math.floor(rnd() * 3)]
})));
const rn = GBInsight.analyze(noise, {});
check(rn.cards.filter((c) => ["correlation", "groupdiff", "trend", "association"].indexOf(c.kind) >= 0).length === 0,
  "純隨機資料不該產生顯著性宣稱：" + rn.cards.map((c) => c.kind).join(","));
if (!asJson) console.log(`\n邊界 純隨機 400 列: ${rn.cards.length} 張卡（${rn.cards.map((c) => c.kind).join(",") || "無，正確"}）`);

// ---- 已知答案：線性關係要找到高相關 ----
const lin = GBData.buildDataset("lin", Array.from({ length: 120 }, (_, i) => ({ a: i, b: 3 * i + 5 + (i % 7) * 0.4, g: i % 2 ? "x" : "y" })));
const lr = GBInsight.analyze(lin, {});
const corr = lr.cards.find((c) => c.kind === "correlation");
check(corr && /0\.9\d|1/.test(corr.tags.join()), "已知線性關係應該回報 r≈1，實際：" + (corr ? corr.tags.join() : "沒有相關卡"));
if (!asJson) console.log(`\n已知線性（b = 3a + 5）: ${corr ? corr.title + " · " + corr.tags.join(" · ") : "✗ 沒找到"}`);

if (!asJson) console.log(fails ? `\n✗ ${fails} 項不合格` : "\n✓ 全部通過");
else console.log(JSON.stringify({ fails }));
process.exit(fails ? 1 : 0);
